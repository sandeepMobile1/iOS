package com.wellconnected.bean;

public class ForgotBase {

	private LoginBean response;

	public LoginBean getResponse() {
		return response;
	}

	public void setResponse(LoginBean response) {
		this.response = response;
	}
	
}
