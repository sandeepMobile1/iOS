package com.wellconnected.bean;

public class NotificationBase {

	private NotificationstatusBean response;

	public NotificationstatusBean getResponse() {
		return response;
	}

	public void setResponse(NotificationstatusBean response) {
		this.response = response;
	}
	
}
