//
//  NSData+Hex.h
//  IdeaScale
//
//  Created by Jeremy Przasnyski on 2/24/10.
//  Copyright 2010 Cavoort, LLC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (Hex)
- (NSString*) hexString;
@end
