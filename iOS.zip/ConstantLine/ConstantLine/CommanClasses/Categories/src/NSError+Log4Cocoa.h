//
//  NSError+Log4Cocoa.h
//  SurveyAnalytics
//
//  Created by Jeremy Przasnyski on 10/21/10.
//  Copyright 2010 Cavoort, LLC. All rights reserved.
//

@interface NSError (Log4Cocoa)
-(void)log4Error;
@end
