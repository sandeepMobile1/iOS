package com.wellconnected.bean;

public class AboutUsBase {

	private AboutUsBean Home;

	public AboutUsBean getHome() {
		return Home;
	}

	public void setHome(AboutUsBean Home) {
		this.Home = Home;
	}

	
	
}
