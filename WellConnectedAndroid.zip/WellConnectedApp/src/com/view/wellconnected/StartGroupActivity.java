package com.view.wellconnected;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Random;
import java.util.UUID;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.wellconnected.utills.JsonPostRequest1;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

public class StartGroupActivity extends Activity implements OnClickListener {
	private LinearLayout ll_upload,ll_back;
	private EditText ed_title,ed_about;
	private Button btn_member,btn_detail,btn_done;
	private String imageFilePath,imageType,user_id,
	group_title,random_Number,periodType="Monthly",subscriptionPeriod="0 month",subscriptionCharge="1",groupIntro;
	private Bitmap bitmap;
	private ImageView img_pic_1;
	private   AlertDialog.Builder builder_1;
		@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.startgroup_screen_activity);
		
		WellconnectedConstant.ScreenName="";
		ll_back=(LinearLayout) findViewById(R.id.ll_back);
		ll_back.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				InputMethodManager imm = (InputMethodManager)getSystemService(
					     StartGroupActivity.this.INPUT_METHOD_SERVICE);
					imm.hideSoftInputFromWindow(arg0.getWindowToken(), 0);		

				finish();
			}
		});
		img_pic_1=(ImageView) findViewById(R.id.img_pic_1);
		
		
	SharedPreferences	pref = this.getSharedPreferences("LoginInfo", this.MODE_WORLD_READABLE);
		
	user_id=pref.getString("User_id", "");
	
	
		ll_upload=(LinearLayout) findViewById(R.id.ll_upload);
		ll_upload.setOnClickListener(this);
		
		ed_title=(EditText) findViewById(R.id.ed_title);
		
		ed_about=(EditText) findViewById(R.id.ed_about);
		
		btn_member=(Button) findViewById(R.id.btn_member);
		btn_member.setOnClickListener(this);
		
		btn_detail=(Button) findViewById(R.id.btn_detail);
		btn_detail.setOnClickListener(this);
		builder_1 = new AlertDialog.Builder(this);
		builder_1.setTitle("Make your selection");
		
		btn_done=(Button) findViewById(R.id.btn_done);
		btn_done.setOnClickListener(this);
		
				 random_Number=getRandomNumber();
				
				System.out.println("Number"+random_Number);
	     
		}
		
		public String getRandomNumber()
		{
			
			char[] chars = "abcdefghijklmnopqrstuvwxyz0123456789".toCharArray();
			StringBuilder sb = new StringBuilder();
			Random random = new Random();
			for (int i = 0; i < 40; i++) {
			    char c = chars[random.nextInt(chars.length)];
			    sb.append(c);
			}
			String output = sb.toString();
			System.out.println(output);
			return output;
		}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId())
		{
		case R.id.btn_done:
			
			 group_title=ed_title.getText().toString();
			 groupIntro=ed_about.getText().toString();
			
			if(group_title.equals(""))
			{
				WellconnectedUtills.customDialog(StartGroupActivity.this, "Please enter group title");
				
			}
			else if(group_title.length()<4)
			{
				WellconnectedUtills.customDialog(StartGroupActivity.this, "Group title should be at least 4 Characters and maximum 40 Characters");
				
			}
			else if(group_title.length()>40)
			{
				WellconnectedUtills.customDialog(StartGroupActivity.this, "Group title should be at least 4 Characters and maximum 40 Characters");
				
			}
			else if(groupIntro.equals(""))
			{
				WellconnectedUtills.customDialog(StartGroupActivity.this, "Please enter group intro");
				
			}
			else
			{
				

				if (WellconnectedUtills.isNetworkAvailable(StartGroupActivity.this)) {
					new NewGroupTask().execute();

				} else {
					WellconnectedUtills.customDialog(StartGroupActivity.this, "Internet connection is not available");

				}
			}
			break;
		case R.id.btn_detail:
			
			final Dialog dialog = new Dialog(StartGroupActivity.this);
			dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
			dialog.setContentView(R.layout.detail_popup);

			Button btn_ok = (Button) dialog.findViewById(R.id.btn_ok);
			btn_ok.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					dialog.dismiss();
				}
			});

			Button btn_cancel = (Button) dialog.findViewById(R.id.btn_cancel);
			btn_cancel.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					dialog.dismiss();
					
					subscriptionPeriod="1 Month";
					
					subscriptionCharge="1";
					
					periodType="Monthly";
				}
			});
			
			RelativeLayout rl_amount = (RelativeLayout) dialog
			.findViewById(R.id.rl_amount);
			
			final TextView txt_amount = (TextView) dialog
					.findViewById(R.id.txt_amount);

			rl_amount.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					final String [] items={"$1","$2","$5","$10","$20","$50","$100"};
					final String [] itemss={"1","2","5","10","20","50","100"};
					
					//final CharSequence[] items;
					/*items=new CharSequence[101];
					for(int i=0;i<=100;i++)
					{
						items[i]=i+""+"$";
						
					}*/

					builder_1.setItems(items,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int item) {
									// Do something with the selection
									txt_amount.setText(items[item]);
	                                                                                                                                                    								
									subscriptionCharge=itemss[item].toString();
								}
							});
					AlertDialog alert = builder_1.create();
					alert.show();

				}
			});
			
			final TextView txt_time = (TextView) dialog
					.findViewById(R.id.txt_time);

			RelativeLayout rl_time = (RelativeLayout) dialog
					.findViewById(R.id.rl_time);
			rl_time.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					final CharSequence[] items = { "0 month", "1 month",
							"2 month", "3 month", "4 month", "5 month",
							"6 month", "7 month", "8 month", "9 month",
							"10 month", "11 month", "12 month" };

					builder_1.setItems(items,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int item) {
									// Do something with the selection
									txt_time.setText(items[item]);
									
									subscriptionPeriod=items[item].toString();
								}
							});
					AlertDialog alert = builder_1.create();
					alert.show();

				}
			});
			final TextView txt_type = (TextView) dialog
					.findViewById(R.id.txt_type);

			RelativeLayout rl_type = (RelativeLayout) dialog
					.findViewById(R.id.rl_type);
			rl_type.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					final CharSequence[] items = { "Monthly", "Annual" };

					builder_1.setItems(items,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int item) {
									// Do something with the selection
									txt_type.setText(items[item]);
									periodType=items[item].toString();
								}
							});
					AlertDialog alert = builder_1.create();
					alert.show();

				}
			});

			dialog.show();
			break;
		case R.id.btn_member:
			
			   final CharSequence[] items = {
		                "Paid", "Free"
		        };

		        AlertDialog.Builder builder = new AlertDialog.Builder(this);
		        builder.setTitle("Make your selection");
		        builder.setItems(items, new DialogInterface.OnClickListener() {
		            public void onClick(DialogInterface dialog, int item) {
		                // Do something with the selection
		            	btn_member.setText(items[item]);
		            	if(items[item].equals("Free"))
		            	{
		            		btn_detail.setEnabled(false);
		            	}
		            	else
		            	{
		            		btn_detail.setEnabled(true);
		            	}
		            }
		        });
		        AlertDialog alert = builder.create();
		        alert.show();
			break;
		case R.id.ll_upload:
			showDialog(1);
			InputMethodManager imm = (InputMethodManager)getSystemService(
				     StartGroupActivity.this.INPUT_METHOD_SERVICE);
				imm.hideSoftInputFromWindow(v.getWindowToken(), 0);		

			break;
		}
	}
	
	@Override
	public Dialog onCreateDialog(int id,final Bundle args)
	{
		AlertDialog dialog=null;
		switch(id)
		{					
			case 1:
			{
				String options[];
				               
				options=new String[]{"Gallery","Camera"};
				
				AlertDialog.Builder builder=new AlertDialog.Builder(this);
				builder.setSingleChoiceItems(options,-1, new DialogInterface.OnClickListener() 
				{					
					@Override
					public void onClick(DialogInterface dialog, int which) 
					{
						if(which==0)
						{							
							try 
							{
								Intent i = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI);
								startActivityForResult(i, 1);
							} 
							catch (Exception e) 
							{
								 e.printStackTrace();
							}
						}
						else if(which == 1)
						{														
							try 
							{
								Intent i = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
								startActivityForResult(i, 2);
							}
							catch (Exception e) 
							{
								 e.printStackTrace();
							}
						}						
						removeDialog(1);
					}					
				}).setTitle("Take Image From");
				
				dialog=builder.create();
				break;
			}			
			default:
			{
				break;
			}
		}
		return dialog;
	}
	
	@Override
	protected void onActivityResult(int requestCode,int resultCode,Intent data)
	{				
		super.onActivityResult(requestCode, resultCode, data);
		
		if(resultCode==Activity.RESULT_OK)
		{
			if(requestCode==1) 
			{
				try 
				{				
					Uri selectedimage = data.getData();
					String[] filepathcolumn = {MediaStore.Images.Media.DATA};

					Cursor cursor = getContentResolver().query(selectedimage,filepathcolumn, null, null, null);
					cursor.moveToFirst();

					int columnindex = cursor.getColumnIndex(filepathcolumn[0]);
					
					imageFilePath = cursor.getString(columnindex);				
					
					imageType = imageFilePath.substring(imageFilePath.lastIndexOf(".") + 1);										
					
					cursor.close();
					
					FileInputStream in;
					
					try 
					{
						in = new FileInputStream(imageFilePath);
						
						BitmapFactory.Options options = new BitmapFactory.Options();
						options.inSampleSize = 4;
						bitmap = BitmapFactory.decodeStream(in,null,options);
						
						//img_user_pic.setImageBitmap(bitmap);
						img_pic_1.setImageBitmap(WellconnectedUtills.getRoundedShape(bitmap));
					}
					catch (Exception e) 
					{
						Log.e("Error reading file", e.toString());
						
						if(e instanceof FileNotFoundException)
						{
							Toast.makeText(StartGroupActivity.this,"Network Synchronized Image Does Not Exists", Toast.LENGTH_SHORT).show();
						}
					}				
					
				} 				
				catch (Exception e) 
				{					
					e.printStackTrace();
					
					if(e instanceof FileNotFoundException)
					{
						Toast.makeText(StartGroupActivity.this,"Network Synchronized Image Does Not Exists", Toast.LENGTH_SHORT).show();
					}
				}
			}
			else if (requestCode == 2) 
			{			
				File Imagedirectory = new File(Environment.getExternalStorageDirectory()+ "/MyImage");
				if (!Imagedirectory.exists()) 
				{
					Imagedirectory.mkdir();
				}

				int quality = 5;
				String ssss = UUID.randomUUID().toString();
				File file = new File(Imagedirectory.getPath() + "/" + ssss + ".png");
				
				imageFilePath=file.getPath();
				imageType="png";
				
				try 
				{
					if (data.getExtras() != null) 
					{
						bitmap = (Bitmap) data.getExtras().get("data");

						try 
						{
							file.createNewFile();
							FileOutputStream fileOutputStream = new FileOutputStream(file);
							BufferedOutputStream bos = new BufferedOutputStream(fileOutputStream);
							bitmap.compress(CompressFormat.PNG, quality, bos);
							
							//img_user_pic.setImageBitmap(bitmap);
							img_pic_1.setImageBitmap(WellconnectedUtills.getRoundedShape(bitmap));
									bos.flush();
							bos.close();
						} 
						catch (Exception e) 
						{
							e.printStackTrace();
						}												
					}
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}			
			}			
		}				
	}
	
	public class NewGroupTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		String response;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(StartGroupActivity.this, "", "Please Wait");
			
		}

		@Override
		protected String doInBackground(String... params) {
			
			ArrayList<String> fileArrayList = new ArrayList<String>();
			//image file path name
			
			if(imageFilePath==null||imageFilePath.equals(""))
			{
				imageFilePath="";
			}
			else
			{
				File file = new File(imageFilePath);
				
				fileArrayList.add(file.getPath());
			}
			ArrayList<String[]> dataArrayList = new ArrayList<String[]>();
				String[] c = new String[2];

			c[0] = "userId";
			c[1] = user_id;
			dataArrayList.add(c);

			String[] d = new String[2];

			d[0] = "groupTitle";
			d[1] = group_title ;
			dataArrayList.add(d);

			String[] e = new String[2];

			e[0] = "groupIntro";
			e[1] = groupIntro;
			dataArrayList.add(e);

			String[] f = new String[2];

			f[0] = "subscriptionCharge";
			f[1] = subscriptionCharge;
			dataArrayList.add(f);

			String[] fdevice_type = new String[2];

			fdevice_type[0] = "subscriptionPeriod";
			fdevice_type[1] = subscriptionPeriod;
			dataArrayList.add(fdevice_type);

			System.out.println("subscriptionCharge"+subscriptionCharge);
			
			String[] g = new String[2];

			g[0] = "groupMember";
			g[1] = "";
			dataArrayList.add(g);

			
			String[] h = new String[2];

			h[0] = "threadId";
			h[1] = random_Number;
			dataArrayList.add(h);

			String[] i = new String[2];

			i[0] = "groupType";
			i[1] = "public";
			dataArrayList.add(i);

			
			String[] j = new String[2];

			j[0] = "periodType";
			j[1] = periodType;
			dataArrayList.add(j);
		
			String URL = WellconnectedConstant.WEBSERVICE_URL + "create_group";
			
			//give image name
			
			 response=new JsonPostRequest1().doPostWithFile1(URL, dataArrayList, fileArrayList, "testimage", "png");
			System.out.println("response"+response);
			
				Log.i("gotResponseeeeeeee", response);
			
			
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			
			if(response!=null)
			{
				JSONObject object,object_res = null;
				try {
					object = new JSONObject(response);
					 object_res=object.getJSONObject("response");
					
				} catch (JSONException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				if(object_res.has("success"))
				{
					try {
						
						String group_id=object_res.getString("groupId");
						String groupCode=object_res.getString("groupCode");
						
						WellconnectedUtills.customDialog_2(StartGroupActivity.this,/*object_res.getString("message")*/"Group created successfully",StartGroupActivity.this);
						
						} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
				//	finish();
				}
				else
				{
					
					try {
						WellconnectedUtills.customDialog(StartGroupActivity.this,object_res.getString("error"));
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
			}
			
		}
	}
}
