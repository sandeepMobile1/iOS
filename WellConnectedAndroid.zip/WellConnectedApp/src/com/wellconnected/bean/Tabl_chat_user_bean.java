package com.wellconnected.bean;

public class Tabl_chat_user_bean {
	public String Id;
	public String chatUserId;
	public String chatFriendId;
	public String ZMsgId;
	public String lastMsgId;
	public String getId() {
		return Id;
	}
	public void setId(String id) {
		Id = id;
	}
	public String getChatUserId() {
		return chatUserId;
	}
	public void setChatUserId(String chatUserId) {
		this.chatUserId = chatUserId;
	}
	public String getChatFriendId() {
		return chatFriendId;
	}
	public void setChatFriendId(String chatFriendId) {
		this.chatFriendId = chatFriendId;
	}
	public String getZMsgId() {
		return ZMsgId;
	}
	public void setZMsgId(String zMsgId) {
		ZMsgId = zMsgId;
	}
	public String getLastMsgId() {
		return lastMsgId;
	}
	public void setLastMsgId(String lastMsgId) {
		this.lastMsgId = lastMsgId;
	}

	

}
