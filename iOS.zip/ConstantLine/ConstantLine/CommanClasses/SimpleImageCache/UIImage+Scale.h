//
//  UIImage+Scale.h
//  SmackTalk360
//
//  Created by Vinod Shau on 26/06/13.
//
//

#import <UIKit/UIKit.h>

@interface UIImage (Scale)
-(UIImage*)scaleToSize:(CGSize)size;
@end
