/**
 * Copyright OCTAL INFO SOLUTIONS PVT LTD.  7:00:26 PM  Jun 6, 2013
 */
package com.wellconnected.servercommunication;

import java.io.InputStream;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.json.JSONObject;

import android.util.Log;

import com.wellconnected.utills.WellconnectedUtills;

/**
 * @author Upasna
 *
 */
public class CCRAppServerCommunication {
	
	public static JSONObject callJson(String url, JSONObject parameters) throws Exception
	{
		HttpClient client = new DefaultHttpClient();
		InputStream in = null;
		
		HttpPost post = new HttpPost(url);
		StringEntity se = null;
		HttpResponse response = null;
		JSONObject json = null;
		
		se = new StringEntity(parameters.toString());
		se.setContentType(new BasicHeader(HTTP.CONTENT_TYPE,"application/json"));
		post.setEntity(se);
		response = client.execute(post);
		
		if (response != null) 
		{
			in = response.getEntity().getContent();
		}
		
		String data = WellconnectedUtills.inputSteamToString(in);								
		
		Log.i("JSON_Response",data);

		json = new JSONObject(data);		

		return json;
	}

}
