package com.view.wellconnected;

import java.util.ArrayList;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.wellconnected.bean.ChangePwdBase;
import com.wellconnected.bean.ChatGroupBase;
import com.wellconnected.bean.ContactBase;
import com.wellconnected.bean.ContactBean.contacts;
import com.wellconnected.lazyload.ImageLoader_rounded;
import com.wellconnected.lazyload.ImageLoader_square;
import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.utills.MyApplication;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

public class ContactListFragment extends Fragment{
	private String user_id,search_name,member_id,status,contactId;
	private ArrayList<ChatGroupBase>arr;
	private ArrayList<contacts>arrDetail,arr_temp;
	private ListView list_contacts,list_index;
	private ImageLoader_rounded imgLoader;
	private ImageLoader_square imgLoader_square;
	private ImageView img_menu;
	private EditText ed_search;
	private LinearLayout ll_search,ll_back;
	private ArrayList<String>arr_alpha,temp_arr_alpha;
	private String[] values;
	private TextView txt_noresult;
	private int pending_count=0;
	private SharedPreferences pref;
	private MyApplication appDelegate;

	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
	
		View view = inflater.inflate(R.layout.contact_list, null);
	       
			pref = getActivity().getSharedPreferences("LoginInfo", getActivity().MODE_WORLD_READABLE);
		WellconnectedConstant.ScreenName="";
		
		appDelegate = (MyApplication) getActivity().getApplicationContext();	
		
		appDelegate.setContactRefreshHandler(ContactRefreshHandler);
		
		user_id=pref.getString("User_id", "");
		arr_temp=new ArrayList<contacts>();
		
		ll_search=(LinearLayout) view.findViewById(R.id.ll_search);
		ll_search.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		
		txt_noresult=(TextView) view.findViewById(R.id.txt_noresult);
		list_contacts=(ListView) view.findViewById(R.id.list_contacts);
		
		list_contacts.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				WellconnectedConstant.Group_id="1";
				Intent intent=new Intent(getActivity(),UserInfoActivity.class);
				
				if(arr_temp.isEmpty())
				{
					intent.putExtra("Friend_id", arrDetail.get(arg2).getUser_id());
					
				}
				else 
				{
					intent.putExtra("Friend_id", arr_temp.get(arg2).getUser_id());
					
				}
				intent.putExtra("thread_id","");
				startActivity(intent);
			}
		});

		ed_search=(EditText) view.findViewById(R.id.ed_search);
		ed_search.setOnEditorActionListener(new TextView.OnEditorActionListener() {
		    @Override
		    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
		        if (actionId == EditorInfo.IME_ACTION_SEARCH) {
		        	
		        	 final InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
		        	    imm.hideSoftInputFromWindow(getView().getWindowToken(), 0);
		        	    
		        	
		            return true;
		        }
		        return false;
		    }
		});
		ed_search.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
				// TODO Auto-generated method stub
				
				
				arr_temp=new ArrayList<contacts>();
				if(arrDetail!=null)
				{
					for(int i=0;i<arrDetail.size();i++)
					{
						if(arrDetail.get(i).getUser_name().toLowerCase().contains(arg0.toString().toLowerCase()))
						{
							contacts obj=new contacts();
							obj.setId(arrDetail.get(i).getId());
							obj.setIntro(arrDetail.get(i).getIntro());
							obj.setRequest_status(arrDetail.get(i).getRequest_status());
							obj.setUser_id(arrDetail.get(i).getUser_id());
							obj.setUser_image(arrDetail.get(i).getUser_image());
							obj.setUser_name(arrDetail.get(i).getUser_name());
							arr_temp.add(obj);
						}
					}
				}
				
				if(arg0.equals(""))
				{
					System.out.println("IN SEARCH");
					list_contacts.setAdapter(new ChatAdapter(arrDetail)); 
					
					 list_index.setAdapter(new IndexAdapter(temp_arr_alpha));
				
				}
				else
				{
					if(arr_temp.isEmpty())
					{
						txt_noresult.setVisibility(View.VISIBLE);
						txt_noresult.setGravity(Gravity.CENTER);
						list_contacts.setVisibility(View.INVISIBLE);
						temp_arr_alpha.clear();
						 list_index.setAdapter(new IndexAdapter(temp_arr_alpha));
					
					}
					else
					{
						txt_noresult.setVisibility(View.INVISIBLE);
						list_contacts.setVisibility(View.VISIBLE);
						
						 list_index.setAdapter(new IndexAdapter(arr_alpha));
					}
						
					list_contacts.setAdapter(new ChatAdapter(arr_temp)); 
				}
			}
			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void afterTextChanged(Editable arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		arr_alpha=new ArrayList<String>();
		
			list_index=(ListView) view.findViewById(R.id.list_index);
		list_index.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int position,
					long arg3) {
				
				String letter=arr_alpha.get(position);
				int pos=0;
		for(int i=0;i<arrDetail.size();i++)
		{
			if(arrDetail.get(i).getUser_name().startsWith(letter))
			{
				pos=i;
				break;
			}
			else
			{
				
			}
		}
		list_contacts.setSelection(pos);
			}
		});
		
		return view;
	}
	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
         
		imgLoader=new ImageLoader_rounded(getActivity());
		
		imgLoader_square=new ImageLoader_square(getActivity());
		
		if (WellconnectedUtills.isNetworkAvailable(getActivity())) 
		{
			new ContactListTask().execute();
		}
		else
		{
			WellconnectedUtills.customDialog(getActivity(), "Internet connection is not available");
		}
	}
	
	public class ContactListTask extends AsyncTask<String, Integer, String> {
		ProgressDialog progressDialog;
		JSONObject obj;
		ContactBase chatbase;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(getActivity(), "", "Please Wait");
		}

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub

			chatbase = WellconnectedParse.getContactList(getActivity(), user_id);

			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			
			System.out.println("Print inside ContactListFragment AsyncTask onPostExecute");
			try {
				
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			if (chatbase != null) {
				if (chatbase.getResponse()==null) {
					//WellconnectedUtills.customDialog(ChatActivity.this, chatbase.getResponse().getError());

				} else {
					arr_alpha=new ArrayList<String>();
					temp_arr_alpha=new ArrayList<String>();
					arrDetail=new ArrayList<contacts>();
					arrDetail=chatbase.getResponse().getsuccess().getContacts();
					
					for(int i=0;i<arrDetail.size();i++)
					{
						if(i==0)
						{
							arr_alpha.add(arrDetail.get(i).getUser_name().substring(0, 1).toUpperCase());
							
						}
						else
						{
							if(arrDetail.get(i).getUser_name().substring(0, 1).equalsIgnoreCase((arrDetail.get(i-1).getUser_name().substring(0, 1))))
							{
							}
							else
							{
								arr_alpha.add(arrDetail.get(i).getUser_name().substring(0, 1).toUpperCase());
							}
						}
						if(arrDetail.get(i).getRequest_status().equals("1"))
						{
							//pendinggcc
							pending_count=pending_count+1;
							System.out.println("pending_count"+pending_count);
							
							//save in shared pref and notify
						}
						else
						{
							System.out.println("pending_count"+pending_count);
							
						}
					}
				
					System.out.println("arr_alpha"+arr_alpha.size());
					if(arrDetail.isEmpty())
					{
						txt_noresult.setVisibility(View.VISIBLE);
					}
					else
					{
						txt_noresult.setVisibility(View.INVISIBLE);
					}
				
					System.out.println("Print inside ContactListFragment After Adapter");
					list_contacts.setAdapter(new ChatAdapter(arrDetail)); 
				    list_index.setAdapter(new IndexAdapter(arr_alpha));
				}
			}
			else
			{
				arrDetail=new ArrayList<contacts>();
				list_contacts.setAdapter(new ChatAdapter(arrDetail)); 
			    list_index.setAdapter(new IndexAdapter(arr_alpha));
			    txt_noresult.setVisibility(View.VISIBLE);
			}
		}
	}
	class IndexAdapter extends BaseAdapter implements Filterable
	{
		public ArrayList<String> arr_alpha;
		
		public IndexAdapter(ArrayList<String> arr_alpha) {
			this.arr_alpha=arr_alpha;
			// TODO Auto-generated constructor stub
		}
		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return arr_alpha.size();
		}
		@Override
		public Object getItem(int arg0) {
			// TODO Auto-generated method stub
			return arg0;
		}
		@Override
		public long getItemId(int arg0) {
			// TODO Auto-generated method stub
			return arg0;
		}

		@Override
		public View getView(int arg0, View arg1, ViewGroup arg2) {
			// TODO Auto-generated method stub
			
			View row=View.inflate(getActivity(),R.layout.index, null);
			
			TextView txt_index=(TextView) row.findViewById(R.id.txt_index);
			txt_index.setText(arr_alpha.get(arg0));
			System.out.println("arr_alpha.get(arg0)"+arr_alpha.get(arg0));
			
			return row;
		}

		@Override
		public Filter getFilter() {
			// TODO Auto-generated method stub
			return null;
		}
	}
	class ViewHolder
	{
		ImageView img_contact_image,img_contact_image_square;
		TextView txt_contact_name,txt_header,txt_intro;
		LinearLayout linear_accept;
		Button btn_Accept,btn_reject,btn_delete;
		RelativeLayout relative_rows;
	}
	class ChatAdapter extends BaseAdapter
	{
	private ArrayList<contacts>arrDetail;
		public ChatAdapter(ArrayList<contacts> arrDetail) {
			// TODO Auto-generated constructor stub
			this.arrDetail=arrDetail;
			System.out.println("Print inside chatAdapter Constructor :"+arrDetail.size());
		}
		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return arrDetail.size();
		}
		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return position;
		}
		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
		
			LayoutInflater inflater=getActivity().getLayoutInflater();
			TextView txt_header = null;
			if(position==0)
			{
				convertView=inflater.inflate(R.layout.contact_list_row, null);
				 txt_header=(TextView) convertView.findViewById(R.id.txt_header);
			}
			else
			{
					
					
				if(arrDetail.get(position).getUser_name().substring(0, 1).equalsIgnoreCase(arrDetail.get(position-1).getUser_name().substring(0, 1)))
				{
					convertView=inflater.inflate(R.layout.contact_list_row_1, null);
				}
				else
				{
					convertView=inflater.inflate(R.layout.contact_list_row, null);
					 txt_header=(TextView) convertView.findViewById(R.id.txt_header);
				
				}
			}
			ImageView img_contact_image_square=(ImageView)convertView.findViewById(R.id.img_contact_image_square);
			
			ImageView	img_contact_image=(ImageView)convertView.findViewById(R.id.img_contact_image);
			TextView txt_contact_name=(TextView) convertView.findViewById(R.id.txt_contact_name);
			LinearLayout 	linear_accept=(LinearLayout) convertView.findViewById(R.id.linear_accept);
			Button btn_Accept=(Button) convertView.findViewById(R.id.btn_Accept);
			Button	btn_reject=(Button) convertView.findViewById(R.id.btn_reject);
			Button 	btn_delete=(Button) convertView.findViewById(R.id.btn_delete);
			 	 
			TextView	txt_intro=(TextView) convertView.findViewById(R.id.txt_intro);
				 
			RelativeLayout relative_rows=(RelativeLayout) convertView.findViewById(R.id.relative_rows);
			
		if(position==0)
		{
		txt_header.setText(arrDetail.get(position).getUser_name().substring(0, 1).toUpperCase().trim());
		}
		else 
		{
			if(arrDetail.get(position).getUser_name().substring(0, 1).equalsIgnoreCase(arrDetail.get(position-1).getUser_name().substring(0, 1)))
			{
				
			}
			else
			{
				txt_header.setText(arrDetail.get(position).getUser_name().substring(0, 1).trim());
			}
		}
		if(arrDetail.get(position).getRequest_status().equals("2"))
		{
		relative_rows.setBackgroundResource(0);
		txt_intro.setVisibility(View.GONE);
			System.out.println("friend");
			linear_accept.setVisibility(View.GONE);
			btn_delete.setVisibility(View.VISIBLE);
		}
		else
		{
			txt_intro.setVisibility(View.VISIBLE);
			
			txt_intro.setText(arrDetail.get(position).getIntro().trim());
			relative_rows.setBackgroundColor(getResources().getColor(R.color.grey_color));
			System.out.println("pending");
			linear_accept.setVisibility(View.VISIBLE);
		btn_delete.setVisibility(View.GONE);
		}
		
		btn_Accept.setTag(position);
		btn_Accept.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				int pos=(Integer) arg0.getTag();
				member_id=arrDetail.get(pos).getUser_id();
				status="2";
				contactId=arrDetail.get(pos).getId();
				
				if (WellconnectedUtills.isNetworkAvailable(getActivity())) 
				{
					new Contact_actionTask().execute();
				}
				else
				{
					WellconnectedUtills.customDialog(getActivity(), "Internet connection is not available");
				}
			}
		});
	btn_reject.setTag(position);
		btn_reject.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				int pos=(Integer) arg0.getTag();
				member_id=arrDetail.get(pos).getUser_id();
				status="3";
				contactId=arrDetail.get(pos).getId();
				if (WellconnectedUtills.isNetworkAvailable(getActivity())) 
				{
					new Contact_actionTask().execute();
				}
				else
				{
					WellconnectedUtills.customDialog(getActivity(), "Internet connection is not available");
				}
			}
		});
	btn_delete.setFocusable(false);
		 btn_delete.setTag(position);
		btn_delete.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				int pos=(Integer) arg0.getTag();
				member_id=arrDetail.get(pos).getId();
				if(arrDetail.get(pos).getUser_id().equals("100"))
				{
					WellconnectedUtills.customDialog(getActivity(), "You can't delete this user");
					
				}
				else
				{
					if (WellconnectedUtills.isNetworkAvailable(getActivity())) 
					{
						new DeletePwdTask().execute(member_id);
					}
					else
					{
						WellconnectedUtills.customDialog(getActivity(), "Internet connection is not available");
					}
				}
				
				
			}
		});
		
			 txt_contact_name.setText(arrDetail.get(position).getUser_name().trim());
			 System.out.println("CHAT ADAPTER"+arrDetail.size());
			 
			 if(arrDetail.get(position).getRequest_status().equals("2")&&arrDetail.get(position).getUser_image()!=null)
			 {
				 //round
				// ImageView roundImage = (ImageView)convertView.findViewById(R.id.img_contact_image);
				 imgLoader.DisplayImage(WellconnectedConstant.IMAGE_URL_1+arrDetail.get(position).getUser_image(),img_contact_image);
					
			 }
			 else if(arrDetail.get(position).getRequest_status().equals("1")&&arrDetail.get(position).getUser_image()!=null)
			 {
				 //ImageView roundImage = (ImageView)convertView.findViewById(R.id.img_contact_image);
				 //square
				 imgLoader_square.DisplayImage(WellconnectedConstant.IMAGE_URL_1+arrDetail.get(position).getUser_image(),  img_contact_image_square);
			 }
			 else
			 {
				img_contact_image.setBackgroundResource(R.drawable.phone_pic_bg);
			 }
					return convertView;
		}
	}
	
	public class DeletePwdTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		ChangePwdBase chatbase;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(getActivity(), "", "Please Wait");
		}
		@Override
		protected String doInBackground(String... params) {
			
			// TODO Auto-generated method stub
			chatbase = WellconnectedParse.DeleteContact(getActivity() , params[0]);
				//response=CCRApplicationParse.ChangePwd(ChangePasswordActivity.this, user_id, ed_password.getText().toString(), ed_new_pwd.getText().toString());
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			if (chatbase != null) {
				if (chatbase.getResponse()==null) {
					//WellconnectedUtills.customDialog(ChangePasswordActivity.this, chatbase.getResponse().getError());
				} else {
					
					 new ContactListTask().execute();
				}
			}
		}
	}
	private Handler ContactRefreshHandler = new Handler(){
			
			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				
				System.out.println("ContactListRefresh");
				
				 new ContactListTask().execute();
		
			}
		};
	public class Contact_actionTask extends AsyncTask<String, Integer, String> {
		ProgressDialog progressDialog;
		JSONObject obj;
		String chatbase;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(getActivity(), "", "Please Wait");
		}

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub

			chatbase = WellconnectedParse.getcontactaction(getActivity(), user_id,member_id,status,contactId);

			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			if (chatbase != null) {
				try {
					JSONObject obj=new JSONObject(chatbase);
					JSONObject obj_res=obj.getJSONObject("UserFriend");
					if(obj_res.has("sucess"))
					{
						 AlertDialog dialog;
						 Builder builder = new AlertDialog.Builder(getActivity());
					      builder.setMessage(obj_res.getString("sucess"));
					      builder.setCancelable(true);
					      builder.setPositiveButton("Ok",new DialogInterface.OnClickListener() {
							
							@Override
							public void onClick(DialogInterface dialog, int which) {
								// TODO Auto-generated method stub
								
								int pending=pending_count-1;
								SharedPreferences.Editor editor = pref.edit();
								editor.putString("contactCount",String.valueOf(pending));
								editor.commit();
							
								appDelegate.getChangePic().sendEmptyMessage(11);
								new ContactListTask().execute();
							}
						});
					     
					      dialog = builder.create();
					      dialog.show();
						
					}
					else
					{
						
					}
					
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}
