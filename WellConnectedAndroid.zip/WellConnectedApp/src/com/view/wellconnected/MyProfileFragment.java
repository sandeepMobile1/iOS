package com.view.wellconnected;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.wellconnected.bean.GroupSearchMenuListener;
import com.wellconnected.lazyload.ImageLoader_rounded;
import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.utills.MyApplication;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;


public class MyProfileFragment extends Fragment {
	private SharedPreferences pref;
	private GroupSearchMenuListener mGroupSearchMenuListener;
	@Override
	public void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		img_pic.setImageDrawable(null);
		pref = getActivity().getSharedPreferences("LoginInfo", getActivity().MODE_WORLD_READABLE);
		
		System.out.println("ONSTART");
		WellconnectedConstant.ScreenName="";
		
		mGroupSearchMenuListener = (GroupSearchMenuListener) getActivity();
		if (WellconnectedUtills.isNetworkAvailable(getActivity())) 
		{
			new myprofileTask().execute();
		}
		else
		{
			WellconnectedUtills.customDialog(getActivity(), "Internet connection is not available");
		}
	}

	private TextView txt_name,txt_emaill,txt_contact_email,
	txt_year_birth,txt_gender,txt_edit;
	
	private String user_id;
	private ImageLoader_rounded imgloader;
	private ImageView img_pic;
	private FragmentActivity appDelegate;

	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
         
		View view = inflater.inflate(R.layout.myprofile_fragment, null);
		
		SharedPreferences	pref =getActivity().getSharedPreferences("LoginInfo", getActivity().MODE_WORLD_READABLE);
		
		txt_name=(TextView) view.findViewById(R.id.txt_name);
		txt_emaill=(TextView)  view.findViewById(R.id.txt_emaill);
		txt_contact_email=(TextView) view. findViewById(R.id.txt_contact_email);
		txt_year_birth=(TextView)  view.findViewById(R.id.txt_year_birth);
		txt_gender=(TextView) view. findViewById(R.id.txt_gender);
		user_id=pref.getString("User_id", "");
		
		appDelegate = getActivity();
      imgloader=new ImageLoader_rounded(getActivity());
		
		img_pic=(ImageView)view. findViewById(R.id.img_pic);
		/*
		txt_edit=(TextView)view. findViewById(R.id.txt_edit);
		txt_edit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(getActivity(),EditProfile.class);
				startActivity(intent);
				
			}
		});*/
		
	
        return view;
    }
    
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		
		if (WellconnectedUtills.isNetworkAvailable(getActivity())) 
		{
			new myprofileTask().execute();
		}
		else
		{
			WellconnectedUtills.customDialog(getActivity(), "Internet connection is not available");
		
		}
		
	}
	
	/** about us  task **/
	public class myprofileTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		String chatbase;
;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(getActivity(), "", "Please Wait");
			
		}

		@Override
		protected String doInBackground(String... params) {
			
			// TODO Auto-generated method stub
			chatbase = WellconnectedParse.myProfile(getActivity(),user_id);

				//response=CCRApplicationParse.ChangePwd(ChangePasswordActivity.this, user_id, ed_password.getText().toString(), ed_new_pwd.getText().toString());
			
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			
			if (chatbase != null) {
				
				if(!chatbase.equals(""))
				{
					try {
						JSONObject obj=new JSONObject(chatbase);
						JSONObject obj_res=obj.getJSONObject("response");
						JSONArray arr=obj_res.getJSONArray("success");
						JSONObject objj=arr.getJSONObject(0);
						
						txt_name.setText(objj.getString("display_name"));
						txt_emaill.setText(objj.getString("email"));
						txt_contact_email.setText(objj.getString("contactEmail"));
						txt_year_birth.setText(objj.getString("dob"));
						
						if((objj.getString("gender").equals("male")))
								{
							txt_gender.setText("Male");
							
								}
						else
						{
							txt_gender.setText("Female");
							
						}
						
						System.out.println("URL_myProfile"+WellconnectedConstant.IMAGE_URL_3+objj.getString("user_image"));
						
						SharedPreferences.Editor editor = pref.edit();

						editor.putString("user_image", objj.getString("user_image"));
						editor.commit();
						
						MyApplication.is_edit_profile="1";
						mGroupSearchMenuListener.onMenuClick();
						//appDelegate.getChangePic().sendEmptyMessage(11);
						imgloader.DisplayImage(WellconnectedConstant.IMAGE_URL_3+objj.getString("user_image"), img_pic);
										} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				
			}
		}
	}
}
