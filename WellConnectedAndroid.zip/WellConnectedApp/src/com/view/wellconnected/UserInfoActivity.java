package com.view.wellconnected;

import java.net.URLEncoder;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.gson.JsonArray;
import com.view.wellconnected.WellconnectedUser.addUserTask;
import com.wellconnected.bean.ChangePwdBase;
import com.wellconnected.bean.ProfileBase;
import com.wellconnected.database.DataBaseManager;
import com.wellconnected.database.MatchDataSource;
import com.wellconnected.lazyload.ImageLoader_rounded;
import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

public class UserInfoActivity extends FragmentActivity {
	private String user_id,Friend_id,friend_name,image,thread_id,value;
	private LinearLayout ll_back;
	private TextView txt_name,txt_age,txt_gender,txt_desc;
	private ImageView img_chat,img_pic;
	private ImageLoader_rounded img_loader;
	private ImageButton img_star_1,img_star_2,img_star_3,img_star_4,img_star_5;
	private Button btn_clear_msg;
	private DataBaseManager dbhelper;
	private SQLiteDatabase mySqldb;
	private MatchDataSource datasourse;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		setContentView(R.layout.userinfo);
		SharedPreferences	pref = this.getSharedPreferences("LoginInfo", this.MODE_WORLD_READABLE);
		
		dbhelper=new DataBaseManager(UserInfoActivity.this);
		mySqldb=dbhelper.getReadableDatabase();
		datasourse = new MatchDataSource(UserInfoActivity.this);
		WellconnectedConstant.ScreenName="";
		img_star_1=(ImageButton) findViewById(R.id.img_star_1);
		img_star_2=(ImageButton) findViewById(R.id.img_star_2);
		img_star_3=(ImageButton) findViewById(R.id.img_star_3);
		img_star_4=(ImageButton) findViewById(R.id.img_star_4);
		img_star_5=(ImageButton) findViewById(R.id.img_star_5);
		
		btn_clear_msg=(Button) findViewById(R.id.btn_clear_msg);
		
		img_loader=new ImageLoader_rounded(UserInfoActivity.this);
		
		
		img_pic=(ImageView) findViewById(R.id.img_pic);
		
		
		img_chat=(ImageView) findViewById(R.id.img_chat);
		
		if(WellconnectedConstant.Group_id.equals("0"))
		{
			img_chat.setVisibility(View.INVISIBLE);
			btn_clear_msg.setVisibility(View.VISIBLE);
		}
		else if(WellconnectedConstant.Group_id.equals("2"))
		{
			btn_clear_msg.setBackgroundResource(R.drawable.blue_btn);
			btn_clear_msg.setText("Add To Contact");
		}
		else if(WellconnectedConstant.Group_id.equals("3"))
		{
			btn_clear_msg.setVisibility(View.INVISIBLE);
		}
		else
		{
			img_chat.setVisibility(View.VISIBLE);
			btn_clear_msg.setVisibility(View.INVISIBLE);
			
		}
		
		btn_clear_msg.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if(WellconnectedConstant.Group_id.equals("2"))
				{
					
						// TODO Auto-generated method stub
						final Dialog dialog=new  Dialog(UserInfoActivity.this);
						dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);						dialog.setContentView(R.layout.dialog_layout);
						final EditText ed_popup=(EditText) dialog.findViewById(R.id.ed_popup);
						
						
						Button btn_ok=(Button) dialog.findViewById(R.id.btn_ok);
						btn_ok.setOnClickListener(new OnClickListener() {
							
							@Override
							public void onClick(View arg0) {
								// TODO Auto-generated method stub
								
								 value=URLEncoder.encode(ed_popup.getText().toString()).trim();
									
								if(value.length()>80)
								{
									WellconnectedUtills.customDialog(UserInfoActivity.this, "Maximum 80 char allowed");
									}
								else
								{
									//webservice 
									if(value.length()>0)
									{
										new addUserTask().execute();
										dialog.dismiss();
							
									}
								}
							}
						});
						Button btn_cancel=(Button) dialog.findViewById(R.id.btn_cancel);
						btn_cancel.setOnClickListener(new OnClickListener() {
							
							@Override
							public void onClick(View arg0) {
								// TODO Auto-generated method stub
								dialog.dismiss();
							}
						});
						dialog.show();
					}
				
				else
				{
					AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(UserInfoActivity.this);
					 myAlertDialog.setMessage("Do you want to clear all messges?");
					 myAlertDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {

						  public void onClick(DialogInterface arg0, int arg1) {
						  // do something when the OK button is clicked
								
								if (WellconnectedUtills.isNetworkAvailable(UserInfoActivity.this)) {
									new ClearMessageTask().execute();

								} else {
									WellconnectedUtills.customDialog(UserInfoActivity.this, "Internet connection is not available");

								}
						  }});
						 myAlertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
						       
						  public void onClick(DialogInterface arg0, int arg1) {
						  // do something when the Cancel button is clicked
						  }});
						 myAlertDialog.show();
				}
				
			
			}
		});
		img_chat.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(UserInfoActivity.this,GroupChatActivity.class);
				intent.putExtra("friend_id", Friend_id);
				intent.putExtra("Friend_name", friend_name);
				intent.putExtra("Friend_image", image);
				intent.putExtra("Group_id","0");
				intent.putExtra("Group_type","0");
				
				startActivity(intent);
				}
		});
		
		user_id=pref.getString("User_id", "");
		
		Friend_id=this.getIntent().getStringExtra("Friend_id");
		thread_id=this.getIntent().getStringExtra("thread_id");
		
		System.out.println("thread_id"+thread_id);
		
		txt_name=(TextView) findViewById(R.id.txt_name);
		txt_age=(TextView) findViewById(R.id.txt_age);
		
		
		txt_gender=(TextView) findViewById(R.id.txt_gender);
		txt_desc=(TextView) findViewById(R.id.txt_desc);
		
		
		ll_back=(LinearLayout) findViewById(R.id.ll_back);
		ll_back.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				finish();
			}
		});
		
		
		if (WellconnectedUtills.isNetworkAvailable(UserInfoActivity.this)) {
			new profileTask().execute();

		} else {
			WellconnectedUtills.customDialog(UserInfoActivity.this, "Internet connection is not available");

		}
	}
	/** wellconnected users  task **/
	public class addUserTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		ChangePwdBase chatbase;
;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(UserInfoActivity.this, "", "Please Wait");
			
		}

		@Override
		protected String doInBackground(String... params) {
			
			// TODO Auto-generated method stub
			chatbase = WellconnectedParse.addUser(UserInfoActivity.this, user_id, Friend_id,value);

				//response=CCRApplicationParse.ChangePwd(ChangePasswordActivity.this, user_id, ed_password.getText().toString(), ed_new_pwd.getText().toString());
			
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			
			if (chatbase != null) {
				if (chatbase.getResponse().getError()!=null) {
					
					WellconnectedUtills.customDialog(UserInfoActivity.this, chatbase.getResponse().getError());

				} else {
					
					WellconnectedUtills.customDialog(UserInfoActivity.this, chatbase.getResponse().getSuccess());

				}
			}
		}
		
		
	}
	//** clear all mesg **/
	public class ClearMessageTask extends AsyncTask<String, Integer, String> {
		ProgressDialog progressDialog;
		String response;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(UserInfoActivity.this, "", "Please Wait");

		}

		@Override
		protected String doInBackground(String... params) {

			// TODO Auto-generated method stub

			response = WellconnectedParse.ClearallTAsk(UserInfoActivity.this, Friend_id,user_id);

			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}

			if (response != null) {
				try {
					JSONObject obj=new JSONObject(response);
					JSONObject obj_res=obj.getJSONObject("response");
					
					if(obj_res.has("success"))
					{
						//setResult(10001);
						//finish();
						
						
						//call fragment from activity
						
						WellconnectedConstant.refrence.finish();
						UserInfoActivity.this.finish();
						
						datasourse.open();
						
						datasourse.delete_messages(thread_id);
						
						datasourse.close();
						
						}
					else
					{
						
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
				
			}

		}
	} 
	public class profileTask extends AsyncTask<String, Integer, String> {
		ProgressDialog progressDialog;
		JSONObject obj;
		ProfileBase chatbase;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(UserInfoActivity.this, "", "Please Wait");

		}

		@Override
		protected String doInBackground(String... params) {

			// TODO Auto-generated method stub

			chatbase = WellconnectedParse.getprofile(UserInfoActivity.this, user_id,Friend_id);

			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}

			if (chatbase != null) {
				if (chatbase.getResponse()==null) {
					
					//WellconnectedUtills.customDialog(ChatActivity.this, chatbase.getResponse().getError());

				} else {
					txt_name.setText(chatbase.getResponse().getsuccess().get(0).getDisplay_name());
					txt_age.setText(chatbase.getResponse().getsuccess().get(0).getDob());
					
					if(chatbase.getResponse().getsuccess().get(0).getGender().equals("male"))
					{
						txt_gender.setText("Male");
						
					}
					else if(chatbase.getResponse().getsuccess().get(0).getGender().equals("female"))
					{
						txt_gender.setText("Female");
						
					}
					else
					{
						txt_gender.setText(chatbase.getResponse().getsuccess().get(0).getGender());
						
					}
					if(chatbase.getResponse().getsuccess().get(0).getIntro()!=null)
					{
						if(chatbase.getResponse().getsuccess().get(0).getIntro().equals("null"))
						{
							txt_desc.setText("");
							
						}
						else{
							txt_desc.setText(chatbase.getResponse().getsuccess().get(0).getIntro());
							
						}
					}
					
					
					
					friend_name=chatbase.getResponse().getsuccess().get(0).getDisplay_name();
					
					image=chatbase.getResponse().getsuccess().get(0).getUser_image();
					
					
					
					if(chatbase.getResponse().getsuccess().get(0).getRating().equals("1"))
					{
						img_star_1.setBackgroundResource(R.drawable.grey_star);
						img_star_2.setBackgroundResource(R.drawable.white_star);
						img_star_3.setBackgroundResource(R.drawable.white_star);
						img_star_4.setBackgroundResource(R.drawable.white_star);
						img_star_5.setBackgroundResource(R.drawable.white_star);
						
					}
					else if(chatbase.getResponse().getsuccess().get(0).getRating().equals("2"))
					{
						img_star_1.setBackgroundResource(R.drawable.grey_star);
						img_star_2.setBackgroundResource(R.drawable.grey_star);
						img_star_3.setBackgroundResource(R.drawable.white_star);
						img_star_4.setBackgroundResource(R.drawable.white_star);
						img_star_5.setBackgroundResource(R.drawable.white_star);
				
						
					}
					else if(chatbase.getResponse().getsuccess().get(0).getRating().equals("3"))
					{
						img_star_1.setBackgroundResource(R.drawable.grey_star);
						img_star_2.setBackgroundResource(R.drawable.grey_star);
						img_star_3.setBackgroundResource(R.drawable.grey_star);
						img_star_4.setBackgroundResource(R.drawable.white_star);
						img_star_5.setBackgroundResource(R.drawable.white_star);
				
						
					}
					else if(chatbase.getResponse().getsuccess().get(0).getRating().equals("4"))
					{
						img_star_1.setBackgroundResource(R.drawable.grey_star);
						img_star_2.setBackgroundResource(R.drawable.grey_star);
						img_star_3.setBackgroundResource(R.drawable.grey_star);
						img_star_4.setBackgroundResource(R.drawable.grey_star);
						img_star_5.setBackgroundResource(R.drawable.white_star);
				
						
					}
					else if(chatbase.getResponse().getsuccess().get(0).getRating().equals("5"))
					{
						
						img_star_1.setBackgroundResource(R.drawable.grey_star);
						img_star_2.setBackgroundResource(R.drawable.grey_star);
						img_star_3.setBackgroundResource(R.drawable.grey_star);
						img_star_4.setBackgroundResource(R.drawable.grey_star);
						img_star_5.setBackgroundResource(R.drawable.grey_star);
				
					}
					else if(chatbase.getResponse().getsuccess().get(0).getRating().equals("0"))
					{
						img_star_1.setBackgroundResource(R.drawable.white_star);
						img_star_2.setBackgroundResource(R.drawable.white_star);
						img_star_3.setBackgroundResource(R.drawable.white_star);
						img_star_4.setBackgroundResource(R.drawable.white_star);
						img_star_5.setBackgroundResource(R.drawable.white_star);
				
						
					}
					img_loader.DisplayImage(WellconnectedConstant.IMAGE_URL_1+chatbase.getResponse().getsuccess().get(0).getUser_image(), img_pic);
					
				
				}
			}

		}
	}
}
