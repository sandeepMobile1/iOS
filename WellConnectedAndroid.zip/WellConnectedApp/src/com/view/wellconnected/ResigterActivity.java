package com.view.wellconnected;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.UUID;
import java.util.regex.Pattern;

import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.wellconnected.utills.JsonPostRequest1;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

public class ResigterActivity extends Activity implements OnClickListener{
	private ImageView img_pic;
	private EditText ed_screenname,ed_email,ed_pswd,ed_confirm_pwd;
	private ImageButton img_gender;
	private Button btn_done,img_age;
	private LinearLayout ll_upload,ll_back,linear_male,linear_female,linear_gender;
	private SharedPreferences pref;
	private String screenname,email,password,confirmpwd,imageFilePath,gender="1",
	imageType,Age="";
	public static final Pattern EMAIL_ADDRESS_PATTERN = Pattern.compile("[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}");
  private Bitmap bitmap;
  private boolean is_gender=true;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		 
		setContentView(R.layout.register_screen);
		
		WellconnectedConstant.ScreenName="";
		
		pref = this.getSharedPreferences("LoginInfo", this.MODE_WORLD_READABLE);
		
	linear_male=(LinearLayout) findViewById(R.id.linear_male);
	linear_male.setOnClickListener(this);
	
	linear_gender=(LinearLayout) findViewById(R.id.linear_gender);
	linear_gender.setOnClickListener(this);

	linear_female=(LinearLayout) findViewById(R.id.linear_female);
	linear_female.setOnClickListener(this);
	
		ll_back=(LinearLayout) findViewById(R.id.ll_back)
;		
		ll_back.setOnClickListener(this);
		ll_upload=(LinearLayout) findViewById(R.id.ll_upload);
		ll_upload.setOnClickListener(this);
		
		img_pic=(ImageView) findViewById(R.id.img_pic);
		img_pic.setOnClickListener(this);
		
		/*img_gender=(ImageButton) findViewById(R.id.img_gender);
		img_gender.setOnClickListener(this);
		*/
		img_age=(Button) findViewById(R.id.img_age);
		img_age.setOnClickListener(this);
		
		ed_screenname=(EditText) findViewById(R.id.ed_screenname);
		ed_email=(EditText) findViewById(R.id.ed_email);
		ed_pswd=(EditText) findViewById(R.id.ed_pswd);
		ed_confirm_pwd=(EditText) findViewById(R.id.ed_confirm_pwd);
		
		btn_done=(Button) findViewById(R.id.btn_done);
		btn_done.setOnClickListener(this);
}
	public class ResigtrationTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		String response;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(ResigterActivity.this, "", "Please Wait");
		}
		@Override
		protected String doInBackground(String... params) {
			
			ArrayList<String> fileArrayList = new ArrayList<String>();
			//image file path name
			
			if(imageFilePath==null||imageFilePath.equals(""))
			{
				imageFilePath="";
			}
			else
			{
				File file = new File(imageFilePath);
				fileArrayList.add(file.getPath());
			}
				
			ArrayList<String[]> dataArrayList = new ArrayList<String[]>();
			String[] a = new String[2];

		/*	a[0] = "device_os";
			a[1] = "android";
			dataArrayList.add(a);
*/
			String[] c = new String[2];

			c[0] = "email_id";
			c[1] = email;
			dataArrayList.add(c);

			String[] d = new String[2];

			d[0] = "display_name";
			d[1] = screenname ;
			dataArrayList.add(d);

			String[] e = new String[2];

			e[0] = "password";
			e[1] = password;
			dataArrayList.add(e);

			String[] f = new String[2];

			f[0] = "gender";
			f[1] = gender;
			dataArrayList.add(f);
		
			String[] fdevice_type = new String[2];

			fdevice_type[0] = "dob";
			fdevice_type[1] = Age;
			dataArrayList.add(fdevice_type);
			
			/*String[] fdevice_token = new String[2];

			fdevice_token[0] = "device_token";
			fdevice_token[1] = GCMRegistrar.getRegistrationId(RegisterActivity.this);
			dataArrayList.add(fdevice_token);
*/
			String URL = WellconnectedConstant.WEBSERVICE_URL + "register";
			
			//give image name
			
			 response=new JsonPostRequest1().doPostWithFile1(URL, dataArrayList, fileArrayList, "testimage", "png");
			System.out.println("response"+response);
			
				Log.i("gotResponseeeeeeee", response);
			
			
			return null;
		}
		/* (non-Javadoc)
		 * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
		 */
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			
			if(response!=null)
			{
				JSONObject object,object_res = null;
				try {
					object = new JSONObject(response);
					 object_res=object.getJSONObject("response");
					
				} catch (JSONException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				if(object_res.has("success"))
				{
					String user_id,username,message,profile_image;

					try {
						user_id=object_res.getString("userId");
						
						try {
							profile_image=object_res.getString("userImage");
						} catch (Exception e) {
							// TODO: handle exception
						}
						SharedPreferences.Editor editor = pref.edit();
						
						//editor.putString("User_id", user_id);
						editor.putString("Resigter_email", email);
						editor.commit();
					
						WellconnectedUtills.customDialog_2(ResigterActivity.this,object_res.getString("success"),ResigterActivity.this);
						
						//	Intent intent=new Intent(ResigterActivity.this,MainActivity.class);
						//startActivity(intent);
						//finish();
				
						
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else
				{
					
					try {
						WellconnectedUtills.customDialog(ResigterActivity.this,object_res.getString("error"));
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
			}
		}
	}
	private boolean checkEmail(String email) {
		return EMAIL_ADDRESS_PATTERN.matcher(email).matches();
	}
	
	@Override
	public Dialog onCreateDialog(int id,final Bundle args)
	{
		AlertDialog dialog=null;
		switch(id)
		{					
			/*case 0: 
			{
				return new DatePickerDialog(this, datePickerListener,Integer.parseInt(year), Integer.parseInt(month),Integer.parseInt(day));
			}	*/
			case 1:
			{
				String options[];
				               
				options=new String[]{"Gallery","Camera"};
				
				AlertDialog.Builder builder=new AlertDialog.Builder(this);
				builder.setSingleChoiceItems(options,-1, new DialogInterface.OnClickListener() 
				{					
					@Override
					public void onClick(DialogInterface dialog, int which) 
					{
						if(which==0)
						{							
							try 
							{
								Intent i = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI);
								startActivityForResult(i, 1);
							} 
							catch (Exception e) 
							{
								 e.printStackTrace();
							}
						}
						else if(which == 1)
						{														
							try 
							{
								Intent i = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
								startActivityForResult(i, 2);
							}
							catch (Exception e) 
							{
								 e.printStackTrace();
							}
						}						
						removeDialog(1);
					}					
				}).setTitle("Take Image From");
				
				dialog=builder.create();
				break;
			}			
			default:
			{
				break;
			}
		}
		return dialog;
	}
	
	@Override
	protected void onActivityResult(int requestCode,int resultCode,Intent data)
	{				
		super.onActivityResult(requestCode, resultCode, data);
		
		if(resultCode==Activity.RESULT_OK)
		{
			if(requestCode==1) 
			{
				try 
				{				
					Uri selectedimage = data.getData();
					String[] filepathcolumn = {MediaStore.Images.Media.DATA};

					Cursor cursor = getContentResolver().query(selectedimage,filepathcolumn, null, null, null);
					cursor.moveToFirst();

					int columnindex = cursor.getColumnIndex(filepathcolumn[0]);
					
					imageFilePath = cursor.getString(columnindex);				
					
					imageType = imageFilePath.substring(imageFilePath.lastIndexOf(".") + 1);										
					
					cursor.close();
					
					FileInputStream in;
					
					try 
					{
						in = new FileInputStream(imageFilePath);
						
						BitmapFactory.Options options = new BitmapFactory.Options();
						options.inSampleSize = 4;
						bitmap = BitmapFactory.decodeStream(in,null,options);
						
						//img_user_pic.setImageBitmap(bitmap);
						img_pic.setImageBitmap(WellconnectedUtills.getRoundedBitmap_2(bitmap));
					}
					catch (Exception e) 
					{
						Log.e("Error reading file", e.toString());
						
						if(e instanceof FileNotFoundException)
						{
							Toast.makeText(ResigterActivity.this,"Network Synchronized Image Does Not Exists", Toast.LENGTH_SHORT).show();
						}
					}				
					
				} 				
				catch (Exception e) 
				{					
					e.printStackTrace();
					
					if(e instanceof FileNotFoundException)
					{
						Toast.makeText(ResigterActivity.this,"Network Synchronized Image Does Not Exists", Toast.LENGTH_SHORT).show();
					}
				}
			}
			else if (requestCode == 2) 
			{			
				File Imagedirectory = new File(Environment.getExternalStorageDirectory()+ "/MyImage");
				if (!Imagedirectory.exists()) 
				{
					Imagedirectory.mkdir();
				}

				int quality = 5;
				String ssss = UUID.randomUUID().toString();
				File file = new File(Imagedirectory.getPath() + "/" + ssss + ".png");
				
				imageFilePath=file.getPath();
				imageType="png";
				
				try 
				{
					if (data.getExtras() != null) 
					{
						bitmap = (Bitmap) data.getExtras().get("data");

						try 
						{
							file.createNewFile();
							FileOutputStream fileOutputStream = new FileOutputStream(file);
							BufferedOutputStream bos = new BufferedOutputStream(fileOutputStream);
							bitmap.compress(CompressFormat.PNG, quality, bos);
							
							//img_user_pic.setImageBitmap(bitmap);
							img_pic.setImageBitmap(WellconnectedUtills.getRoundedBitmap_2(bitmap));
									bos.flush();
							bos.close();
						} 
						catch (Exception e) 
						{
							e.printStackTrace();
						}												
					}
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}			
			}			
		}				
	}
	@SuppressLint("NewApi")
	@Override
	public void onClick(View v) {
		
		try {
			switch(v.getId())
			{
			case R.id.ll_back:
				finish();
				break;
			case R.id.linear_female:
				if(is_gender)
				{
					is_gender=false;
					
					int sdk = android.os.Build.VERSION.SDK_INT;
					if(sdk < android.os.Build.VERSION_CODES.JELLY_BEAN) {
					    linear_gender.setBackgroundDrawable(null);
					} else {
						linear_gender.setBackground(null);
					}
					
					
					linear_gender.setBackgroundResource(R.drawable.gender_selection_female);
					gender="2";
				}
				else
				{
					is_gender=true;
					linear_gender.setBackgroundResource(R.drawable.gender_selection_male);
					
					gender="1";
					
				}
				
				break;
			case R.id.linear_male:
				if(is_gender)
				{
					is_gender=false;
					linear_gender.setBackground(null);
					linear_gender.setBackgroundResource(R.drawable.gender_selection_female);
					gender="2";
				}
				else
				{
					is_gender=true;
					linear_gender.setBackgroundResource(R.drawable.gender_selection_male);
					
					gender="male";
					gender="1";
				}
				
				break;
			/*case R.id.img_gender:
				if(is_gender)
				{
					is_gender=false;
					img_gender.setBackground(null);
					img_gender.setImageResource(R.drawable.gender_selection_female);
					gender="female";
				}
				else
				{
					is_gender=true;
					img_gender.setImageResource(R.drawable.gender_selection_male);
					
					gender="male";
					
				}
				
				
				break;*/
			case R.id.ll_upload:
				showDialog(1);
				InputMethodManager imm = (InputMethodManager)getSystemService(
					      ResigterActivity.this.INPUT_METHOD_SERVICE);
					imm.hideSoftInputFromWindow(v.getWindowToken(), 0);		

				break;
			case R.id.img_pic:
				
				break;
				
			case R.id.btn_done:
				
				screenname=ed_screenname.getText().toString();
				email=ed_email.getText().toString();
				password=ed_pswd.getText().toString();
				confirmpwd=ed_confirm_pwd.getText().toString();
					
				if(screenname.equals(""))
				{
					WellconnectedUtills.customDialog(ResigterActivity.this, "Please enter Screen name");
					ed_screenname.requestFocus();
				}
				else if(screenname.length()<3)
				{
					WellconnectedUtills.customDialog(ResigterActivity.this, "Screen name can not be less than 3 character long");
					ed_screenname.requestFocus();
			
				}
				else if(screenname.length()>25)
				{
					WellconnectedUtills.customDialog(ResigterActivity.this, "Screen name can not be greater than 25 character long");
					ed_screenname.requestFocus();
			
				}
				else if(email.equals(""))
				{
					WellconnectedUtills.customDialog(ResigterActivity.this, "Please enter Email id");
					ed_email.requestFocus();
					
				}
					else if (!checkEmail(email)) {

						WellconnectedUtills.customDialog(ResigterActivity.this, "Please Enter Valid Email Id");

						ed_email.requestFocus();
					}
				else if(password.equals(""))
				{
					WellconnectedUtills.customDialog(ResigterActivity.this, "Please enter your password");
					ed_pswd.requestFocus();
					
				}
				else if(password.length()<6)
				{
					WellconnectedUtills.customDialog(ResigterActivity.this, "Password should be at least 6 Characters and maximum 15 Characters");
					ed_pswd.requestFocus();
			
				}
				else if(confirmpwd.equals(""))
				{
					WellconnectedUtills.customDialog(ResigterActivity.this, "Please enter confirm password");
					ed_confirm_pwd.requestFocus();
					
				}
				else if(!password.equals(confirmpwd))
				{
					WellconnectedUtills.customDialog(ResigterActivity.this, "Password and Confirm Password do no match");
					ed_confirm_pwd.requestFocus();
			
				}
				else if(Age.equals(""))
				{
					WellconnectedUtills.customDialog(ResigterActivity.this, "Select date of birth");
				}
				else
				{
					if (WellconnectedUtills.isNetworkAvailable(ResigterActivity.this)) {
						new ResigtrationTask().execute();

					} else {
						WellconnectedUtills.customDialog(ResigterActivity.this, "Internet connection is not available");

					}
					
				}
						break;
						
			case R.id.img_age:
				
				InputMethodManager immm = (InputMethodManager)getSystemService(
					      ResigterActivity.this.INPUT_METHOD_SERVICE);
					immm.hideSoftInputFromWindow(v.getWindowToken(), 0);		

				Calendar calendar = Calendar.getInstance();
				int year = calendar.get(Calendar.YEAR);
				System.out.println("year"+year);
				int tilldate=year-100;
				ArrayList<String>year_arr=new ArrayList<String>();
				final String arr[]=new String[101];
				for(int i=0;i<=100;i++)
				{
					arr[i]=String.valueOf(year);
					year--;
				}
				
				
				  AlertDialog.Builder builder = new AlertDialog.Builder(ResigterActivity.this);
				    builder.setTitle("Select Age")
				           .setItems(arr, new DialogInterface.OnClickListener() {
				               public void onClick(DialogInterface dialog, int which) {
				               // The 'which' argument contains the index position
				               // of the selected item
				            	   
				            	   Age=arr[which];
				            	   
				            	   img_age.setText(Age);
				           }
				    });
				    builder.create();
				    builder.show();
				
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
