//
//  UIImage+Decompress.h
//  MWPhotoBrowser
//
//  Created by Michael Waterfall on 20/10/2010.
//  Copyright 2010 d3i. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UIImage (Decompress)
- (void)decompress;
@end
