package com.wellconnected.utills;

import java.util.ArrayList;

import com.view.wellconnected.GroupChatActivity;
import com.wellconnected.bean.ChatDetailGroupBean;

import android.app.Activity;
import android.graphics.Bitmap;


public class WellconnectedConstant {
	
	public static int id_1=0,id=0,login_id=0;
	public static ArrayList<Activity>array_activity=new ArrayList<Activity>();
	
	
	public static String MONTH_PRODUCT_ID_1 = "1_monthly";
	public static String YEAR_PRODUCT_ID_1 = "1_yearly";
	
	public static String MONTH_PRODUCT_ID_2 = "2_monthly";
	public static String YEAR_PRODUCT_ID_2 = "2_yearly";

	public static String MONTH_PRODUCT_ID_5 = "5_monthly";
	public static String YEAR_PRODUCT_ID_5 = "5_yearly";
	
	public static String MONTH_PRODUCT_ID_10 = "10_monthly";
	public static String YEAR_PRODUCT_ID_10 = "10_yearly";
	
	public static String MONTH_PRODUCT_ID_20 = "20_monthly";
	public static String YEAR_PRODUCT_ID_20 = "20_yearly";
	
	public static String MONTH_PRODUCT_ID_50 = "50_monthly";
	public static String YEAR_PRODUCT_ID_50 = "50_yearly";

	public static String MONTH_PRODUCT_ID_100 = "100_monthly";
	public static String YEAR_PRODUCT_ID_100 = "100_yearly";
	
	public static final String WEBSERVICE_URL ="http://wellconnected.ehealthme.com/web_services/";
	
	public static final String IMAGE_URL ="http://wellconnected.ehealthme.com/uploads/user/thumb/";
	public static final String IMAGE_URL_1 ="http://wellconnected.ehealthme.com/uploads/user/thumb1/";
	public static final String IMAGE_URL_2 ="http://wellconnected.ehealthme.com/uploads/user/large/";
	public static final String IMAGE_URL_3 ="http://wellconnected.ehealthme.com/uploads/user/";
	public static final String IMAGE_URL_4 ="http://wellconnected.ehealthme.com/uploads/groupimages/thumb1/";
	public static final String IMAGE_URL_5 ="http://wellconnected.ehealthme.com/uploads/chat/image/";
	public static final String IMAGE_URL_6 ="http://wellconnected.ehealthme.com/uploads/chat/audio/caf/";
	public static final String IMAGE_URL_7 ="http://wellconnected.ehealthme.com/uploads/chat/audio/mp3/";
	public static final String DEFAULT_GROUP_PIC ="http://wellconnected.ehealthme.com/img/group_pic.png";

	
	
			
	public static final String check_maintenance_mode = "check_maintenance_mode";
	public static final String login = "login";
	public static final String forgot_password = "forgot_password";
	public static final String register_social_media = "register_social_media";
	public static final String landing_page = "landing_page";
	public static final String change_password = "change_password";
	public static final String get_setting = "get_setting";
	public static final String set_setting = "set_setting";
	public static final String new_game = "new_game";
	public static final String get_around_user_list ="get_around_user_list";
	public static final String get_ccr_user_list = "get_ccr_user_list";
	public static final String invite_users = "invite_users";
	public static final String add_guest_users = "add_guest_users";
	public static final String get_game_user_status = "get_game_user_status";
	public static final String get_confirmed_users = "get_confirmed_users";
	public static final String delete_confirmed_users = "delete_confirmed_users";

	public static final String Google_key = "AIzaSyDn_JbHIwd7EPE3G0BsBYSmOGeIynSajNw";


	public static final String add_contact = "add_contact";
	public static final String register = "register";
	public static final String my_account= "myaccount";
	public static final String profile_detail= "profile_detail";
	public static final String contact_list= "contact_list";
	public static final String get_notifications= "get_notifications";
	public static final String delete_contact= "delete_contact";
	public static final String delete_nofification= "delete_nofification";
	
	public static final String update_notification= "update_notification";
	public static final String update_nofification_status= "update_nofification_status";

	public static final String friend_profile_detail= "friend_profile_detail";
	public static final String logout= "logout";
	public static final String get_QRcode= "get_QRcode";
	
	public static final String unsetBedge= "unsetBedge";
	public static final String send_permission_pn= "send_permission_pn";
	
	
	public static final String 
	update_profile_for_android= "update_profile_for_android";
	public static final String OwnerGroupAction = "OwnerGroupAction";

	public static String isButtonScan="";

	public static String notification_count="0";

	public static String isNotification="";

	public static String Request_status="";

	public static String notification_id="";

	public static String lati="";

	public static String lngi="";



	public static String game_id="";



	//public static ArrayList<ConfrimUserData> arr_data=new ArrayList<ConfrimUserData>();



	public static String win_user_name="";



	public static String score_value="";



	public static String win_user_profile_img;



	public static String new_score_value="";



	public static int out_player_pos;



	public static String make_favourite="make_favourite";



	public static String is_remaining_ueser="";



	public static String favourite_list="favourite_list";



	public static String delete_favourite_game="delete_favourite_game";



	public static String is_phone_vibrat="false";



	public static String is_deal_screen="0";



	public static String is_sound_on="";



	public static String pay_bill="pay_bill";



	public static String user_payment_id="";



	public static String Amount="";



	public static String user_name_for_resto="";



	public static String user_id_for_resto="";



	public static String get_profile_detail="get_profile_detail";



	public static String get_global_users="get_global_users";



	public static String get_individual_user_detail="get_individual_user_detail";



	public static String is_landingScreen="0";



	public static String is_individualScreen="0";



	public static String get_friends="get_friends";



	public static String get_favourite_user_list="get_favourite_user_list";



	public static String delete_group_user="delete_group_user";


	public static String favorite_settings="favorite_settings";


	public static String add_app_users_in_group="add_app_users_in_group";

	public static String addGroup_id="";

	public static String adduser_game_id="";

	public static String name_setting="";

	public static String groupid_setting="";

	public static String add_guest_users_in_group="add_guest_users_in_group";

	public static String restaurent_name="";

	public static String start_game="start_game";

	public static String insert_win_user="insert_win_user";

	public static String win_user_id="";

	public static String insert_lose_user="insert_lose_user";

	public static String insert_deal_user="insert_deal_user";

	public static String create_group_name="";

	public static String is_new_group_activity="";

//	public static ArrayList<CreateGroupData> arr_app_data;

	public static String create_group="create_group";

	public static String play_group_game="play_group_game";

	public static String favorite_game_play="";

	public static String favorite_statistics="";

	public static int no_of_player_start_game=0;

	public static String twitterId="";

	public static String twitterName="";

	public static String twitterScreenname="";

	public static String twitterprofile_url="";

	public static String is_twitter_login="";

	public static String latestGroup="latestGroup";

	public static String findGroup="findGroup";

	public static String chat_listing="chat_listing";
	public static boolean is_menu_click=false;
	public static String contact_listing="contact_listing";
	public static String block_list="block_list";
	public static String updateMemberBlock="updateMemberBlock";
	public static String unPaidAmount="unPaidAmount";
	public static String updateNotification="updateNotification";
	public static String home_message="home_message";
	public static String user_listing="user_listing";
	public static String friend_profile="friend_profile";
	public static String chat_detail="chat_detail";
	public static String replace_row_id="";
	public static String send_chat_data="send_chat_data";
	public static String is_group_chat="0";
	public static String Group_id="1";
	public static String clear_individual_message="clear_individual_message";
	public static GroupChatActivity refrence;
	public static int Courser_count;
	public static String user_profile_detail="user_profile_detail";
	public static String send_phone_num="send_phone_num";
	public static String contact_action="contact_action";
	public static String groupInfo="groupInfo";
	public static boolean is_user_block;
	public static String Id;
	public static String user_id;
	public static String Group_Type;
	public static String Join_status;
	public static String clearAllGroupMessage="clearAllGroupMessage";
	public static String groupQuit="groupQuit";
	public static String groupUserListing="groupUserListing";
	public static String groupClose="groupClose";
	public static String isPrevilage="";
	public static String groupPrivailage="groupPrivailage";
	public static String groupKickOut="groupKickOut";
	public static String groupEdit="groupEdit";
	public static String isView_5="0";
	public static String fb_login="fb_login";
	public static String Group_image="";
	public static ArrayList<ChatDetailGroupBean> arr_chat_new=new ArrayList<ChatDetailGroupBean>();
	public static String is_chat_screen="0";
	public static Bitmap groupInfoBitmap=null;
	public static String is_chat_refresh="0";

	public static String is_drawer_closed="0";
	public static String ScreenName="";;
}
