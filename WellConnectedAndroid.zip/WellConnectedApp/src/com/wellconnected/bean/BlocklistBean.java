package com.wellconnected.bean;

import java.util.ArrayList;

public class BlocklistBean {
	public ArrayList<BlockUser>BlockUser;
	
	
	public ArrayList<BlockUser> getBlockUser() {
		return BlockUser;
	}


	public void setBlockUser(ArrayList<BlockUser> blockUser) {
		BlockUser = blockUser;
	}


	public static class BlockUser
	{

		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getImage() {
			return image;
		}
		public void setImage(String image) {
			this.image = image;
		}
		public String getUser_id() {
			return user_id;
		}
		public void setUser_id(String user_id) {
			this.user_id = user_id;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getDisplayName() {
			return displayName;
		}
		public void setDisplayName(String displayName) {
			this.displayName = displayName;
		}
		public String id;
		public String image;
		public String user_id;
		public String username;
		public String displayName;
		
}
}