package com.view.wellconnected;

import java.util.ArrayList;

import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.wellconnected.bean.BlockGroupBase;
import com.wellconnected.bean.BlocklistBean.BlockUser;
import com.wellconnected.bean.ChangePwdBase;
import com.wellconnected.lazyload.ImageLoader_rounded;
import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

public class BlockContactList extends Activity implements OnClickListener{
	private LinearLayout ll_back;
	private String user_id,member_id;
	private ArrayList<BlockUser>arrDetail;	
	private ListView list_block;
	private ImageLoader_rounded imgLoader;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		setContentView(R.layout.block_contact_screen);
		
		WellconnectedConstant.ScreenName="";
		imgLoader=new ImageLoader_rounded(BlockContactList.this);
		
		SharedPreferences	pref = this.getSharedPreferences("LoginInfo", this.MODE_WORLD_READABLE);
		
		user_id=pref.getString("User_id", "");
		
		list_block=(ListView) findViewById(R.id.list_block);
		
		ll_back=(LinearLayout) findViewById(R.id.ll_back);
		ll_back.setOnClickListener(this);
		
		
		if (WellconnectedUtills.isNetworkAvailable(BlockContactList.this)) 
		{
			new BlockLisTask().execute();
		}
		else
		{
			WellconnectedUtills.customDialog(BlockContactList.this, "Internet connection is not available");
			
		
		}

	}
	
	//** unblock list **/
	

	public class UnblockBlockLisTask extends AsyncTask<String, Integer, String> {
		ProgressDialog progressDialog;
		JSONObject obj;
		ChangePwdBase chatbase;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(BlockContactList.this, "", "Please Wait");

		}

		@Override
		protected String doInBackground(String... params) {

			// TODO Auto-generated method stub

			chatbase = WellconnectedParse.updateBlockList(BlockContactList.this, user_id,member_id,"0");

			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}

			if (chatbase != null) {
				if (chatbase.getResponse()==null) {
				//	WellconnectedUtills.customDialog(ChatActivity.this, chatbase.getResponse().getError());

				} else {
					
					 AlertDialog dialog;
					 Builder builder = new AlertDialog.Builder(BlockContactList.this);
				      builder.setMessage(chatbase.getResponse().getSuccess());
				      builder.setCancelable(true);
				      builder.setPositiveButton("Ok",new DialogInterface.OnClickListener() {
						
						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							
							new BlockLisTask().execute();
						}
					});
				     
				      dialog = builder.create();
				      dialog.show();
					
				}
			}

		}
	}

	//** block list **/
	
	
	public class BlockLisTask extends AsyncTask<String, Integer, String> {
		ProgressDialog progressDialog;
		JSONObject obj;
		BlockGroupBase chatbase;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(BlockContactList.this, "", "Please Wait");

		}

		@Override
		protected String doInBackground(String... params) {

			// TODO Auto-generated method stub

			chatbase = WellconnectedParse.getBlockList(BlockContactList.this, user_id);

			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}

			if (chatbase != null) {
				if (chatbase.getResponse()==null) {
					//WellconnectedUtills.customDialog(ChatActivity.this, chatbase.getResponse().getError());

				} else {
					
					arrDetail=new ArrayList<BlockUser>();
					
					arrDetail=chatbase.getResponse().getBlockUser();
					
					System.out.println("arrDetail"+arrDetail.size());
					
					list_block.setAdapter(new BlockAdapter()); 
				}
			}

		}
	}
	
	class ViewHolder
	{
		ImageView img_block_image;
		TextView txt_friend_name;
		
		Button btn_block;
	}
	class BlockAdapter extends BaseAdapter
	{

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return arrDetail.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			
			ViewHolder viewHolder=null;
			if(convertView==null)
			{
				LayoutInflater inflater=BlockContactList.this.getLayoutInflater();
				convertView=inflater.inflate(R.layout.block_row, null);
				  viewHolder = new ViewHolder();
				  viewHolder.img_block_image=(ImageView)convertView.findViewById(R.id.img_block_image);
				  viewHolder.txt_friend_name=(TextView) convertView.findViewById(R.id.txt_friend_name);
				  viewHolder.btn_block=(Button) convertView.findViewById(R.id.btn_block);
				  
				  
				 convertView.setTag(viewHolder);
			}
			else
			{
				viewHolder = (ViewHolder)convertView.getTag();
				
			}
			viewHolder.txt_friend_name.setText(arrDetail.get(position).getDisplayName().trim());
			if(arrDetail.get(position).getImage()!=null)
			{
				
				System.out.println("URL"+arrDetail.get(position).getImage());
				
				imgLoader.DisplayImage(WellconnectedConstant.IMAGE_URL_1+arrDetail.get(position).getImage(),  viewHolder.img_block_image);
				
			}
			else
			{
				viewHolder.img_block_image.setBackgroundResource(R.drawable.phone_pic_bg);
/*
				System.out.println("URL"+arrDetail.get(position).getGroupImage());
				
				imgLoader.DisplayImage(WellconnectedConstant.IMAGE_URL_4+arrDetail.get(position).getGroupImage(),  viewHolder.img_chat_image);
			*/	
			}
			viewHolder.btn_block.setTag(position);
			viewHolder.btn_block.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					int pos=(Integer) arg0.getTag();
					
					member_id=arrDetail.get(pos).getUser_id();
					///////
					
					new UnblockBlockLisTask().execute();
				}
			});
			return convertView;
				
			
			
			
			}
		
		
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId())
		{
		case R.id.ll_back:
			
			finish();
			break;
		}
	}
}
