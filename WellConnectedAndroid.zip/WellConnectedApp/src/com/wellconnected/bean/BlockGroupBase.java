package com.wellconnected.bean;

public class BlockGroupBase {

	private BlocklistBean response;

	public BlocklistBean getResponse() {
		return response;
	}

	public void setResponse(BlocklistBean response) {
		this.response = response;
	}
	
}
