package com.wellconnected.bean;

import java.util.ArrayList;

public class ProfileBean {
	public ArrayList<success>success;
	
	
	
	
	
	
public ArrayList<success> getsuccess() {
		return success;
	}






	public void setArr(ArrayList<success> success) {
		this.success = success;
	}






class success
{
		public String display_name;
		public String user_name;
		public String friend_status;
		public String contactEmail;
		public String email;
		public String phone_no;
		public String dob;
		public String gender;
		public String user_id;
		public String rating;
		public String no_of_groups;
		public String intro;
		public String user_image;
		public String getDisplay_name() {
			return display_name;
		}
		public void setDisplay_name(String display_name) {
			this.display_name = display_name;
		}
		public String getUser_name() {
			return user_name;
		}
		public void setUser_name(String user_name) {
			this.user_name = user_name;
		}
		public String getFriend_status() {
			return friend_status;
		}
		public void setFriend_status(String friend_status) {
			this.friend_status = friend_status;
		}
		public String getContactEmail() {
			return contactEmail;
		}
		public void setContactEmail(String contactEmail) {
			this.contactEmail = contactEmail;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getPhone_no() {
			return phone_no;
		}
		public void setPhone_no(String phone_no) {
			this.phone_no = phone_no;
		}
		public String getDob() {
			return dob;
		}
		public void setDob(String dob) {
			this.dob = dob;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getUser_id() {
			return user_id;
		}
		public void setUser_id(String user_id) {
			this.user_id = user_id;
		}
		public String getRating() {
			return rating;
		}
		public void setRating(String rating) {
			this.rating = rating;
		}
		public String getNo_of_groups() {
			return no_of_groups;
		}
		public void setNo_of_groups(String no_of_groups) {
			this.no_of_groups = no_of_groups;
		}
		public String getIntro() {
			return intro;
		}
		public void setIntro(String intro) {
			this.intro = intro;
		}
		public String getUser_image() {
			return user_image;
		}
		public void setUser_image(String user_image) {
			this.user_image = user_image;
		}
}
}
