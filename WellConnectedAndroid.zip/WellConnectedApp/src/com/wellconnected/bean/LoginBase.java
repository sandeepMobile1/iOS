package com.wellconnected.bean;

public class LoginBase {

	private LoginBean response;

	public LoginBean getResponse() {
		return response;
	}

	public void setResponse(LoginBean response) {
		this.response = response;
	}
	
}
