QSUtilities Library for iOS

This library provides general purposes libraries (string cleanup, net access, etc.) within Objective-C classes.
