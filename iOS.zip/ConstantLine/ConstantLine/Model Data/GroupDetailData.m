//
//  GroupDetailData.m
//  ConstantLine
//
//  Created by octal i-phone2 on 8/13/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "GroupDetailData.h"

@implementation GroupDetailData

@synthesize groupTitle;
@synthesize groupImage;
@synthesize groupRating;
@synthesize groupCreated;
@synthesize groupCharge;
@synthesize groupMember;
@synthesize groupOwner;
@synthesize groupIntro;
@synthesize groupCode;
@synthesize groupPaidStatus;
@synthesize groupType;
@synthesize groupUserRating;
@synthesize groupUserOwnerRating;
@synthesize groupPrivilegeStatus;
@synthesize groupSubscribeStatus;
@synthesize groupTrialPeriod;
@synthesize groupCloseStatus;
@synthesize groupTotalVote;
@synthesize groupParentId;
@synthesize groupSpecialType;
@synthesize groupperiodType;

@end
