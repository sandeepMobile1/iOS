package com.view.wellconnected;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.TimeZone;
import java.util.UUID;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.DownloadManager;
import android.app.DownloadManager.Query;
import android.app.DownloadManager.Request;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.drawable.AnimationDrawable;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.images.HttpImageManager;
import com.wellconnected.bean.ButtonValueBean;
import com.wellconnected.bean.ChangePwdBase;
import com.wellconnected.bean.ChatDetailGroupBean;
import com.wellconnected.bean.MyGroupBase;
import com.wellconnected.bean.Tabl_chat_user_bean;
import com.wellconnected.database.DataBaseManager;
import com.wellconnected.database.MatchDataSource;
import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.utills.JsonPostRequest1;
import com.wellconnected.utills.MyApplication;
import com.wellconnected.utills.ScrollViewExt;
import com.wellconnected.utills.ScrollViewExt.ScrollViewListener;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

public class GroupChatActivity extends Activity implements ScrollViewListener {
	private static final String AUDIO_RECORDER_FILE_EXT_3GP = ".3gp";
	private static final String AUDIO_RECORDER_FILE_EXT_MP4 = ".mp4";
	private static final String AUDIO_RECORDER_FOLDER = "WellconnectedAudios";
	private MediaRecorder recorder = null;
	private int currentFormat = 0;
	private int output_formats[] = { MediaRecorder.OutputFormat.MPEG_4, MediaRecorder.OutputFormat.THREE_GPP };
	private String file_exts[] = { AUDIO_RECORDER_FILE_EXT_MP4, AUDIO_RECORDER_FILE_EXT_3GP };
	private MyApplication application;
	ProgressDialog progressDialog_download;
	private ButtonValueBean previousBeanObj, currentBeanObj;
	private String  status;
	private boolean is_chat_received=false;

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		appDelegate = ((MyApplication) getApplicationContext());
		appDelegate.setmHandler(mHandlerr);
	}

	FileDownloadReceiver fileDownloadReceiver;
	DownloadManager downloadManager;
	private LinearLayout ll_back, linear_chat_box, linear_add, linear_user_info, linear_chat_window, linear_block;
	private ImageView img_write, img_camera, img_audio, img_user_pic;
	private RelativeLayout rl_hold_tlak, rl_hold_to_talk, rlblock;
	private TextView txt_hold, txt_talk, txt_user_name, txt_time, txt_info, txt_block_name;
	private boolean is_long_pressed = false, isPLAYING = false, is_pagging = false, is_user_block = false;;
	private Button button2, gallery_image_btn, camera_image_btn;
	private AnimationDrawable animation;
	private String imageFilePath, imageType, user_id, Friend_id, friend_image, Group_type, random_Number, grouptype, friend_name, type, mesage_id, user_image, thread_id, user_name, chat_type, count, Group_id;
	private Bitmap bitmap;
	private ImageButton btn_arrow, btn_audio_play;
	private ImageButton[] btn_audio_play_arr;
	private ArrayList<ChatDetailGroupBean> arr_chat;
	private MediaPlayer mediaplayer;
	private SeekBar volumebar;
	private SeekBar[] volumebar_arr;
	private int possition = 0, id = 0, crs_id, int_chat_window_size = 0, page = 1, firstLimit = 0, scroll_position, scroll_count = 0;;
	private DataBaseManager dbhelper;
	private SQLiteDatabase mySqldb;
	private MatchDataSource datasourse;

	ArrayList<ChatDetailGroupBean> arr_chat_new;
	MultiDirectionSlidingDrawer drawershere;
	private EditText ed_chat_box, ed_focus;
	private ArrayList<Tabl_chat_user_bean> arr_detail;
	long unixTime;
	ScrollViewExt scroll;
	private View edit_view;
	private SharedPreferences pref;
	private ProgressBar bar;
	private MyApplication appDelegate;
	private static HttpImageManager mHttpImageManager;
	private ProgressBar progressBar;
	private ArrayList<ButtonValueBean> arr_btn_value;
	private int urlCount = 0, downloadCount = 0;
	private SeekBar CurrentvoluBar;
	private TextView txt_header;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		WellconnectedConstant.is_chat_refresh="0";
		downloadManager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);

		random_Number = getRandomNumber();

		mediaplayer = new MediaPlayer();

		arr_btn_value = new ArrayList<ButtonValueBean>();

		setContentView(R.layout.groupchatscren);
		
		txt_header=(TextView) findViewById(R.id.txt_header);

		rlblock = (RelativeLayout) findViewById(R.id.rlblock);

		txt_block_name = (TextView) findViewById(R.id.txt_block_name);

		appDelegate = ((MyApplication) getApplicationContext());
		mHttpImageManager = appDelegate.getHttpImageManagerInstance();

		linear_block = (LinearLayout) findViewById(R.id.linear_block);
		linear_block.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(GroupChatActivity.this);
				
				if (WellconnectedUtills.isNetworkAvailable(GroupChatActivity.this)) {
					//String block = "";
					if (is_user_block) {
						
						 myAlertDialog.setMessage("Unblock this user?");
						 myAlertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {

							  public void onClick(DialogInterface arg0, int arg1) {
							  // do something when the OK button is clicked
								  txt_block_name.setText("Block");
								  String	block = "0";
									is_user_block = false;
									WellconnectedConstant.is_user_block = false;
									System.out.println("is_user_block" + is_user_block);
									if (WellconnectedUtills.isNetworkAvailable(GroupChatActivity.this)) {
										new UnblockBlockLisTask().execute(block);
									} else {
										WellconnectedUtills.customDialog(GroupChatActivity.this, "Internet connection is not available");

									}
							  }});
							 myAlertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
							       
							  public void onClick(DialogInterface arg0, int arg1) {
							  // do something when the Cancel button is clicked
							  }});
							 myAlertDialog.show();
							 
					} else {
					
						 myAlertDialog.setMessage("Block this user?");
						 myAlertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {

							  public void onClick(DialogInterface arg0, int arg1) {
							  // do something when the OK button is clicked
									txt_block_name.setText("Unblock");
								String	block = "1";
									is_user_block = true;
									System.out.println("is_user_block" + is_user_block);
									WellconnectedConstant.is_user_block = true;
									if (WellconnectedUtills.isNetworkAvailable(GroupChatActivity.this)) {
										new UnblockBlockLisTask().execute(block);
									} else {
										WellconnectedUtills.customDialog(GroupChatActivity.this, "Internet connection is not available");

									}
							  }});
							 myAlertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
							       
							  public void onClick(DialogInterface arg0, int arg1) {
							  // do something when the Cancel button is clicked
							  }});
							 myAlertDialog.show();
					}
					
				} else {
					WellconnectedUtills.customDialog(GroupChatActivity.this, "Internet connection is not available");

				}
			}
		});

		bar = (ProgressBar) this.findViewById(R.id.progressBar);
		pref = this.getSharedPreferences("LoginInfo", this.MODE_WORLD_READABLE);

		scroll = (ScrollViewExt) findViewById(R.id.scroll);
		scroll.setScrollViewListener(this);
		progressBar = (ProgressBar) findViewById(R.id.txt_progressBar);
		// progressBar.setVisibility(View.VISIBLE);

		user_image = pref.getString("user_image", "");
		user_id = pref.getString("User_id", "");
		user_name = pref.getString("user_name", "");

		Friend_id = this.getIntent().getStringExtra("friend_id");
		friend_image = this.getIntent().getStringExtra("Friend_image");
		friend_name = this.getIntent().getStringExtra("Friend_name");
		Group_id = this.getIntent().getStringExtra("Group_id");
		Group_type = this.getIntent().getStringExtra("Group_type");

		if (Group_id.equals("0")) {
			grouptype = "0";
			rlblock.setVisibility(View.VISIBLE);

		} else {
			grouptype = "1";

			rlblock.setVisibility(View.GONE);

		}
		System.out.println("grouptype" + grouptype);

		txt_info = (TextView) findViewById(R.id.txt_info);
		txt_info.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if (Group_id.equals("0")) {
					WellconnectedConstant.Group_id = "0";

					Intent intent = new Intent(GroupChatActivity.this, UserInfoActivity.class);
					intent.putExtra("Friend_id", Friend_id);
					intent.putExtra("thread_id", crs_id + "");

					WellconnectedConstant.refrence = GroupChatActivity.this;
					startActivityForResult(intent, 0);

				} else {
					WellconnectedConstant.Group_id = "1";
					Intent intent = new Intent(GroupChatActivity.this, GroupInfoActivity.class);
					intent.putExtra("Friend_id", Friend_id);
					intent.putExtra("thread_id", crs_id + "");
					intent.putExtra("Owner_id", getIntent().getStringExtra("Owner_id"));
					WellconnectedConstant.refrence = GroupChatActivity.this;
					startActivityForResult(intent, 0);

				}
			}
		});

		arr_detail = new ArrayList<Tabl_chat_user_bean>();

		dbhelper = new DataBaseManager(GroupChatActivity.this);
		mySqldb = dbhelper.getReadableDatabase();
		datasourse = new MatchDataSource(GroupChatActivity.this);

		// insert friends detail on table
		datasourse.open();

		int ID_FOR_DB_tbl_user = pref.getInt("ID_FOR_DB_tbl_user", 0);
		WellconnectedConstant.login_id=ID_FOR_DB_tbl_user+1;
		try {
			if (datasourse.getUserId_table_user(Friend_id)) {
				System.out.println("USER_ID_EXISTS");

				datasourse.updatetbl_user(
				/* WellconnectedConstant.login_id++ */Integer.parseInt(WellconnectedConstant.replace_row_id), Friend_id, friend_name, friend_image, friend_name, "", "", "", "", "", "");
			} else {
				datasourse.inserttbl_user(
				 WellconnectedConstant.login_id /*ID_FOR_DB_tbl_user++*/, Friend_id, friend_name, friend_image, friend_name, "", "", "", "", "", "");
			}
		} catch (Exception e) {
			// TODO: handle exception
		}

		SharedPreferences.Editor editor = pref.edit();

		editor.putInt("ID_FOR_DB_tbl_user", WellconnectedConstant.login_id);
		editor.commit();
		// chat_table has data or not
		boolean is_data = datasourse.is_chat_table_empaty();
		if (is_data) {
			System.out.println("Chat table has data");
			type = "old";
			// type old
			// get data from sqlite tbl_chatUser

			arr_detail = datasourse.getTabl_chat_user();
			for (int i = 0; i < arr_detail.size(); i++) {
				if (arr_detail.get(i).getChatUserId().equals(user_id) && arr_detail.get(i).getChatFriendId().equals(Friend_id)) {
					thread_id = arr_detail.get(i).getZMsgId();
					System.out.println("thread_id" + thread_id);
				} else {

				}
				if (arr_detail.get(i).getChatFriendId().equals(Friend_id)) {
					mesage_id = arr_detail.get(i).getLastMsgId();

					System.out.println("mesage_id" + mesage_id);
					type = "old";
					break;
				} else {
					type = "new";
				}

			}
		} else {
			System.out.println("Chat table has No data");
			type = "new";
			mesage_id = "0";
			// type new
		}
		linear_chat_window = (LinearLayout) findViewById(R.id.linear_chat_window);

		// linear_chat_window.setVisibility(View.GONE);
		img_user_pic = (ImageView) findViewById(R.id.img_user_pic);

		Uri uri = Uri.parse(WellconnectedConstant.IMAGE_URL_1 + friend_image);

		if (uri != null && uri.toString().length() > 0&&friend_image!=null) {

			Bitmap bitmap = mHttpImageManager.loadImage(new HttpImageManager.LoadRequest(uri, img_user_pic, progressBar));
			if (bitmap != null) {

				img_user_pic.setImageBitmap((bitmap));
			}
		}
		else
		{
			img_user_pic.setBackgroundResource(R.drawable.default_profile_chat_image);
		}
		System.out.println("IMAGE" + WellconnectedConstant.IMAGE_URL_1 + friend_image);

		txt_user_name = (TextView) findViewById(R.id.txt_user_name);
		txt_user_name.setText(friend_name);
		txt_header.setText(friend_name);
		
		rl_hold_to_talk = (RelativeLayout) findViewById(R.id.rl_hold_to_talk);
		btn_arrow = (ImageButton) findViewById(R.id.btn_arrow);

		linear_add = (LinearLayout) findViewById(R.id.linear_add);
		linear_add.setVisibility(View.GONE);
		linear_add.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				new addUserTask().execute();
			}
		});

		linear_user_info = (LinearLayout) findViewById(R.id.linear_user_info);
		linear_user_info.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(GroupChatActivity.this, UserInfoActivity.class);
				intent.putExtra("Friend_id", Friend_id);
				intent.putExtra("thread_id", crs_id + "");

				WellconnectedConstant.refrence = GroupChatActivity.this;
				startActivityForResult(intent, 0);

			}
		});

		ed_chat_box = (EditText) findViewById(R.id.ed_chat_box);

		linear_chat_box = (LinearLayout) findViewById(R.id.linear_chat_box);
		linear_chat_box.setVisibility(View.GONE);

		drawershere = (MultiDirectionSlidingDrawer) findViewById(R.id.drawershere);
		Button mCancel = (Button) findViewById(R.id.cancel_image_btn_1);

		gallery_image_btn = (Button) findViewById(R.id.gallery_image_btn);
		gallery_image_btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				// gallery imageeeeeee
				Intent i = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI);
				startActivityForResult(i, 1);
				drawershere.animateClose();
			}
		});
		camera_image_btn = (Button) findViewById(R.id.camera_image_btn);
		camera_image_btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent i = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
				startActivityForResult(i, 2);
				drawershere.animateClose();
			}
		});
		mCancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				drawershere.animateClose();
			}
		});
		txt_hold = (TextView) findViewById(R.id.txt_hold);
		txt_talk = (TextView) findViewById(R.id.txt_talk);
		img_audio = (ImageView) findViewById(R.id.img_audio);
		img_audio.setVisibility(View.GONE);

		button2 = (Button) findViewById(R.id.button2);
		rl_hold_tlak = (RelativeLayout) findViewById(R.id.rl_hold_tlak);

		button2.setOnTouchListener(new View.OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:

					txt_hold.setText("RELEASE TO");
					txt_talk.setText("SEND");

					System.out.println("Pressed");
					image_audio_aniation();
					img_audio.setVisibility(View.VISIBLE);

					/** start recoarding **/
					startRecording();

					break;
				case MotionEvent.ACTION_UP:

					txt_hold.setText("HOLD TO");
					txt_talk.setText("TALK");

					animation.stop();
					img_audio.setVisibility(View.GONE);

					System.out.println("UNPressed");

					/** stop recoarding **/
					stopRecording();

					break;
				}
				return false;
			}
		});
		
		ed_chat_box.setOnEditorActionListener(new TextView.OnEditorActionListener() {
		    @Override
		    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
		        if (actionId == EditorInfo.IME_ACTION_SEND) {
		        	
		        	ed_chat_box.clearFocus();
					ed_chat_box.setEnabled(false);
					rl_hold_to_talk.setVisibility(View.VISIBLE);
					linear_chat_box.setVisibility(View.INVISIBLE);

					if (is_user_block) {

					} else {

						// TODO Auto-generated method stub

						String text_1 = Base64.encodeToString(ed_chat_box.getText().toString().getBytes(), Base64.DEFAULT);
						System.out.println("text" + text_1);
						String key = "abcdefghijklm123";

						if (text_1.equals("")) {
						} else {
							unixTime = System.currentTimeMillis() / 1000L;
							System.out.println("unixTime" + unixTime);

							chat_type = "1";
							byte[] data = Base64.decode(text_1, Base64.DEFAULT);
							String text = null;
							try {
								text = new String(data, "UTF-8");

							} catch (UnsupportedEncodingException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							ChatDetailGroupBean bean = new ChatDetailGroupBean();
							bean.setAudio_url("");
							bean.setChat_type(chat_type);// for text
							bean.setDate(String.valueOf(unixTime));
							bean.setFriend_id(user_id);
							bean.setImage(user_image);
							bean.setImage_url("");
							bean.setMessage(text_1);
							bean.setMsg_byte(null);
							bean.setMsgid("");
							bean.setStaticc("");
							bean.setThread_id(thread_id);
							bean.setTimestamp(String.valueOf(unixTime));
							bean.setType("sender");
							bean.setUsername(user_name);
							arr_chat.add(bean);
							arr_chat_new.add(bean);
							if (edit_view != null) {
								linear_chat_window.removeView(edit_view);

							}

							AddoneView(chat_type, user_image, text, user_name, "", user_id, String.valueOf(unixTime), null,0);
							// add in list
							// keyboard hide then call webservice

							type = "1";// for message

							if (WellconnectedUtills.isNetworkAvailable(GroupChatActivity.this)) {

								new SendChatData().execute(text_1, type, "");

							} else {
								WellconnectedUtills.customDialog(GroupChatActivity.this, "Internet connection is not available");

							}
						}
					}
		        	InputMethodManager imm = (InputMethodManager)getSystemService(
		        			GroupChatActivity.this.INPUT_METHOD_SERVICE);
		        		imm.hideSoftInputFromWindow(ed_chat_box.getWindowToken(), 0);
		        		
		        		
		            return true;
		        }
		        return false;
		    }
		});

		btn_arrow.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				ed_chat_box.clearFocus();
				ed_chat_box.setEnabled(false);
				rl_hold_to_talk.setVisibility(View.VISIBLE);
				linear_chat_box.setVisibility(View.INVISIBLE);
			/*	InputMethodManager imm = (InputMethodManager)getSystemService(
					      Context.INPUT_METHOD_SERVICE);
					imm.hideSoftInputFromWindow(ed_chat_box.getWindowToken(), 0);*/
				
				
				// new HiddenAsyntask().execute();
			}
		});
		img_write = (ImageView) findViewById(R.id.img_write);
		img_write.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				ed_chat_box.setEnabled(true);
				ed_chat_box.requestFocus();
				final InputMethodManager inputMethodManager = (InputMethodManager) GroupChatActivity.this.getSystemService(Context.INPUT_METHOD_SERVICE);
				inputMethodManager.showSoftInput(ed_chat_box, InputMethodManager.SHOW_FORCED);
				rl_hold_to_talk.setVisibility(View.GONE);
		
				linear_chat_box.setVisibility(View.VISIBLE);
			
				ed_chat_box.setText("");
				ed_chat_box.requestFocus();
				}
		});

		img_camera = (ImageView) findViewById(R.id.img_camera);
		img_camera.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (!drawershere.isOpened())
					drawershere.animateOpen();
			}
		});
		ll_back = (LinearLayout) findViewById(R.id.ll_back);
		ll_back.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				try {
					if (fileDownloadReceiver != null) {
						unregisterReceiver(fileDownloadReceiver);
					}
				} catch (IllegalArgumentException e) {
					fileDownloadReceiver = null;
				}
				finish();
			}
		});
		if (WellconnectedUtills.isNetworkAvailable(GroupChatActivity.this)) {
			new ChatDetailTask().execute();

		} else {
			WellconnectedUtills.customDialog(GroupChatActivity.this, "Internet connection is not available");

		}
	}

	class OwnerGroupActionAsyntask extends AsyncTask<String, Integer, String>
	{
		ProgressDialog progressDialog;
	  String response;

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog=ProgressDialog.show(GroupChatActivity.this, null, "Loading...");
		}

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			response = WellconnectedParse.Groupownerrequest(GroupChatActivity.this, user_id, params[0], params[1], params[2], params[3]);
			
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			progressDialog.dismiss();
			if(!response.equals("")&&response!=null)
			{
				try {
					JSONObject obj=new JSONObject(response);
					JSONObject objUserFriend=obj.getJSONObject("UserFriend");
					if(objUserFriend.has("sucess"))
					{
						System.out.println("Success"+objUserFriend.getString("sucess"));
						//chat refresh
						type="old";
						new ChatDetailTask().execute();
					}
					else
					{
						System.out.println("Success"+objUserFriend.getString("error"));
						//chat refresh
						type="old";
						new ChatDetailTask().execute();
						
					}
					
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
	}
	@Override
	public void onPause() {
		super.onPause();
		try {
			if (fileDownloadReceiver != null) {
				this.unregisterReceiver(fileDownloadReceiver);
				if(mUpdateTimeTask!=null)
				{
					if(mHandler!=null)
					{
						mHandler.removeCallbacks(mUpdateTimeTask);
						mHandler=null;
					}
				}
			}
		} catch (IllegalArgumentException e) {
			fileDownloadReceiver = null;
		}

	}

	@Override
	public void onDestroy() {
		super.onDestroy();

		try {
			if (fileDownloadReceiver != null) {
				this.unregisterReceiver(fileDownloadReceiver);
				if(mUpdateTimeTask!=null)
				{
					
					mHandler.removeCallbacks(mUpdateTimeTask);
					mHandler=null;
				}
			}
		} catch (IllegalArgumentException e) {
			fileDownloadReceiver = null;
		}
	}

	class FileDownloadReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {
			DownloadManager downloadManager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
			String action = intent.getAction();
			
			if (DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(action)) {
				Log.e("Download Complete", "Download Complete");
				urlCount++;
				
				
				long downloadId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, 0);
				Query query = new Query();
				query.setFilterById(downloadId);
				Cursor c = downloadManager.query(query);
				if (c.moveToFirst()) {
					try {
						int status = c.getInt(c.getColumnIndex(DownloadManager.COLUMN_STATUS));
						if (status == DownloadManager.STATUS_SUCCESSFUL) {
							//downloadCount++;
							
							if(urlCount==arr_chat.size()){
								
								System.out.println("URLLL" + urlCount);
								System.out.println("arr_chat.size()" + arr_chat.size());
								
									getChatViewWithArray(firstLimit);
								
								progressDialog_download.dismiss();
							  	System.out.println("Print the DOWNLOAD COMPLETE");
							}
							
							
							String title = c.getString(c.getColumnIndex(DownloadManager.COLUMN_TITLE));
							System.out.println("urlCount" + urlCount);
							System.out.println("arr_chat.size()" + arr_chat.size());
							
							
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}

				c.close();
			}
		}
	}

	public void Download_single_file(String fileURL, String fileName) {
		try {

			String data = URLDecoder.decode(fileURL, "UTF-8");

			File file1 = new File(Environment.getExternalStorageDirectory() + "/" + /*
																					 * Environment
																					 * .
																					 * DIRECTORY_DOWNLOADS
																					 */AUDIO_RECORDER_FOLDER, fileName);
			// if(!file1.exists())
			// {
			Query query = new Query();
			query.setFilterByStatus(DownloadManager.STATUS_RUNNING);
			Cursor c1 = downloadManager.query(query);

			List<String> titleList = new ArrayList<String>();

			while (c1.moveToNext()) {
				try {
					titleList.add(c1.getString(c1.getColumnIndex(DownloadManager.COLUMN_TITLE)));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			Request request = new Request(Uri.parse(data));
			request.setTitle(data);

			request.setShowRunningNotification(true);
			request.setDestinationInExternalPublicDir(/*
													 * Environment.
													 * DIRECTORY_DOWNLOADS
													 */AUDIO_RECORDER_FOLDER, fileName);
			downloadManager.enqueue(request);

			c1.close();

			// }

		} catch (Exception e) {
			Log.d("Downloader", e.getMessage());
		}
	}

	@SuppressWarnings("deprecation")
	public void DownloadFile(
	/* String fileURL, String fileName */ArrayList<ChatDetailGroupBean> arr_chat) {
		urlCount=0;
		String file_URL = "", fileName = "";
		for (int i = 0; i < arr_chat.size(); i++) {
			if (arr_chat.get(i).getChat_type().equals("2")) {
//				urlCount++;
				file_URL = WellconnectedConstant.IMAGE_URL_5 + arr_chat.get(i).getImage_url();
				fileName = arr_chat.get(i).getImage_url();
				try {

					String data = URLDecoder.decode(file_URL, "UTF-8");

					File file1 = new File(Environment.getExternalStorageDirectory() + "/" + /*
																							 */AUDIO_RECORDER_FOLDER, fileName);
					// if(!file1.exists())
					// {
					Query query = new Query();
					query.setFilterByStatus(DownloadManager.STATUS_RUNNING);
					Cursor c1 = downloadManager.query(query);

					List<String> titleList = new ArrayList<String>();

					while (c1.moveToNext()) {
						try {
							titleList.add(c1.getString(c1.getColumnIndex(DownloadManager.COLUMN_TITLE)));
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
					Request request = new Request(Uri.parse(data));
					request.setTitle(data);

					request.setShowRunningNotification(true);
					request.setDestinationInExternalPublicDir(
					AUDIO_RECORDER_FOLDER, fileName);
					System.out.println("Print the Download Chat type 2");
					downloadManager.enqueue(request);

					c1.close();

					// }
					/*
					 * else { downloadCount++; if(urlCount==downloadCount) {
					 * progressDialog_download.dismiss();
					 * getChatViewWithArray(firstLimit); } }
					 */

				} catch (Exception e) {
					Log.d("Downloader", e.getMessage());
				}
			} else if (arr_chat.get(i).getChat_type().equals("3")) {
//				urlCount++;

				file_URL = WellconnectedConstant.IMAGE_URL_7 + arr_chat.get(i).getAudio_url();
				fileName = arr_chat.get(i).getAudio_url();

				try {

					String data = URLDecoder.decode(file_URL, "UTF-8");

					File file1 = new File(Environment.getExternalStorageDirectory() + "/" + /*
																							 */AUDIO_RECORDER_FOLDER, fileName);
					// if(!file1.exists())
					// {
					Query query = new Query();
					query.setFilterByStatus(DownloadManager.STATUS_RUNNING);
					Cursor c1 = downloadManager.query(query);

					List<String> titleList = new ArrayList<String>();

					while (c1.moveToNext()) {
						try {
							titleList.add(c1.getString(c1.getColumnIndex(DownloadManager.COLUMN_TITLE)));
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
					Request request = new Request(Uri.parse(data));
					request.setTitle(data);

					request.setShowRunningNotification(true);
					request.setDestinationInExternalPublicDir(
					/* Environment.DIRECTORY_DOWNLOADS */AUDIO_RECORDER_FOLDER, fileName);
					downloadManager.enqueue(request);
					System.out.println("Print the Download Chat type 3");
					c1.close();

				} catch (Exception e) {
					Log.d("Downloader", e.getMessage());
				}
			}if(arr_chat.get(i).getChat_type().equals("1")){
			
				urlCount++;
				System.out.println("Print the Download Chat type Text"+urlCount);
				if(urlCount==arr_chat.size()){
					
					System.out.println("Print the Download Completed :"+urlCount);
					progressDialog_download.dismiss();
					try {
						if(WellconnectedConstant.is_chat_refresh.equals("1"))
						{
							String	text="";
							try {
								byte[] data = Base64.decode(arr_chat.get(i).getMessage(), Base64.DEFAULT);
								text = new String(data, "UTF-8");
								
								
							} catch (IllegalArgumentException e) {
								// TODO: handle exception
							} catch (UnsupportedEncodingException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							AddoneView("1", arr_chat.get(i).getImage(), text, arr_chat.get(i).getUsername(), "", arr_chat.get(i).getFriend_id(), arr_chat.get(i).getTimestamp(), null,0);
						}
						else
						{
							getChatViewWithArray(firstLimit);
						}
						
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				  	System.out.println("Print the DOWNLOAD COMPLETE");
				}
			}
		}
		/*if(urlCount==0)
		{
			progressDialog_download.dismiss();
			try {
				getChatViewWithArray(firstLimit);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}*/

	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();

		IntentFilter intentFilter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
		registerReceiver(fileDownloadReceiver, intentFilter);
	}

	/** get audio file name **/
	private String getFilename() {
		String filepath = Environment.getExternalStorageDirectory().getPath();
		String audio_location;
		File file = new File(filepath, AUDIO_RECORDER_FOLDER);

		if (!file.exists()) {
			file.mkdirs();
		}
		audio_location = file.getAbsolutePath() + "/" + System.currentTimeMillis() + file_exts[currentFormat];
		imageFilePath = audio_location;
		return audio_location;
	}

	private void startRecording() {
		recorder = new MediaRecorder();

		recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
		recorder.setOutputFormat(output_formats[currentFormat]);
		recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
		recorder.setOutputFile(getFilename());

		System.out.println("Audio Recording Path :" + imageFilePath);

		recorder.setOnErrorListener(errorListener);
		recorder.setOnInfoListener(infoListener);

		try {
			recorder.prepare();
			recorder.start();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void stopRecording() {
		if (null != recorder) {
			recorder.stop();
			recorder.reset();
			recorder.release();

			recorder = null;
			type = "3";

			unixTime = System.currentTimeMillis() / 1000L;
			System.out.println("unixTime" + unixTime);

			ChatDetailGroupBean bean = new ChatDetailGroupBean();
			bean.setAudio_url("");
			bean.setChat_type(type);// for text
			bean.setDate(String.valueOf(unixTime));
			bean.setFriend_id(user_id);
			bean.setImage(user_image);
			bean.setImage_url("");
			bean.setMessage(imageFilePath);
			bean.setMsg_byte(null);
			bean.setMsgid("");
			bean.setStaticc("");
			bean.setThread_id(thread_id);
			bean.setTimestamp(String.valueOf(unixTime));
			bean.setType("sender");
			bean.setUsername(user_name);
			arr_chat.add(bean);
			arr_chat_new.add(bean);

			// btn_audio_play_arr=new ImageButton[arr_chat.size()];
			// volumebar_arr=new SeekBar[arr_chat.size()];

			if (edit_view != null) {
				linear_chat_window.removeView(edit_view);

			}
			System.out.println("AUDIO_file_playing path :"+imageFilePath);
		
			MediaPlayer player=new MediaPlayer();
			try {
				player.setDataSource(imageFilePath);
//				player.start();
				player.prepare();
				
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalStateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			long totalDuration = player.getDuration();
			
			System.out.println("Print the Total Duration :"+totalDuration);
			float seconds =  (totalDuration / 1000);
		/*	int seconds = (int) (milliseconds / 1000) % 60 ;
			int minutes = (int) ((milliseconds / (1000*60)) % 60);
			int hours   = (int) ((milliseconds / (1000*60*60)) % 24);*/
			System.out.println("SECONDS"+seconds);
			player.stop();
			if(player!=null)
			{
				player=null;
			}
			AddoneView(type, user_image, imageFilePath, user_name, "", user_id, String.valueOf(unixTime), bitmap,seconds);

			if (WellconnectedUtills.isNetworkAvailable(GroupChatActivity.this)) {

				new SendChatAudioFileTask().execute("", type, "");

			} else {
				WellconnectedUtills.customDialog(GroupChatActivity.this, "Internet connection is not available");

			}
		}
	}

	private MediaRecorder.OnErrorListener errorListener = new MediaRecorder.OnErrorListener() {
		@Override
		public void onError(MediaRecorder mr, int what, int extra) {
			Toast.makeText(GroupChatActivity.this, "Error: " + what + ", " + extra, Toast.LENGTH_SHORT).show();
		}
	};

	private MediaRecorder.OnInfoListener infoListener = new MediaRecorder.OnInfoListener() {
		@Override
		public void onInfo(MediaRecorder mr, int what, int extra) {
			Toast.makeText(GroupChatActivity.this, "Warning: " + what + ", " + extra, Toast.LENGTH_SHORT).show();
		}
	};

	public class addUserTask extends AsyncTask<String, Integer, String> {
		ProgressDialog progressDialog;
		JSONObject obj;
		ChangePwdBase chatbase;;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(GroupChatActivity.this, "", "Please Wait");

		}

		@Override
		protected String doInBackground(String... params) {

			// TODO Auto-generated method stub
			chatbase = WellconnectedParse.addUser(GroupChatActivity.this, user_id, Friend_id, "");

			// response=CCRApplicationParse.ChangePwd(ChangePasswordActivity.this,
			// user_id, ed_password.getText().toString(),
			// ed_new_pwd.getText().toString());

			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}

			if (chatbase != null) {
				if (chatbase.getResponse().getError() != null) {

					WellconnectedUtills.customDialog(GroupChatActivity.this, chatbase.getResponse().getError());

				} else {

					WellconnectedUtills.customDialog(GroupChatActivity.this, chatbase.getResponse().getSuccess());

				}
			}
		}

	}

	// block functionalityyyyyyyyyyyyyyyy

	// ** unblock list **/

	public class UnblockBlockLisTask extends AsyncTask<String, Integer, String> {
		ProgressDialog progressDialog;
		JSONObject obj;
		ChangePwdBase chatbase;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(GroupChatActivity.this, "", "Please Wait");

		}

		@Override
		protected String doInBackground(String... params) {

			// TODO Auto-generated method stub

			chatbase = WellconnectedParse.updateBlockList(GroupChatActivity.this, user_id, Friend_id, params[0]);

			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}

			if (chatbase != null) {
				if (chatbase.getResponse() == null) {
					// WellconnectedUtills.customDialog(ChatActivity.this,
					// chatbase.getResponse().getError());

				} else {

					AlertDialog dialog;
					Builder builder = new AlertDialog.Builder(GroupChatActivity.this);
					if (chatbase.getResponse().getSuccess() != null) {
						builder.setMessage(chatbase.getResponse().getSuccess());
						btn_arrow.setEnabled(true);
						btn_arrow.setClickable(true);

					} else {
						builder.setMessage(chatbase.getResponse().getError());
						btn_arrow.setEnabled(false);
						btn_arrow.setClickable(false);
					}
					builder.setCancelable(true);
					builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub

							// new BlockLisTask().execute();
						}
					});

					dialog = builder.create();
					dialog.show();

				}
			}

		}
	}

	private Handler mHandlerr = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
		
			
			 Bundle bundle = msg.getData();
			 String chat_type=bundle.getString("ChatType");
			System.out.println("Messagechat_type"+chat_type);
			if(chat_type.equals("chat"))
			{
				WellconnectedConstant.is_chat_refresh="1";
			if (WellconnectedUtills.isNetworkAvailable(GroupChatActivity.this)) {
				type="old";
				

				System.out.println("Chat table has data");
				type = "old";
				// type old
				// get data from sqlite tbl_chatUser
				arr_detail=new ArrayList<Tabl_chat_user_bean>();
				arr_detail = datasourse.getTabl_chat_user();
				for (int i = 0; i < arr_detail.size(); i++) {
					if (arr_detail.get(i).getChatUserId().equals(user_id) && arr_detail.get(i).getChatFriendId().equals(Friend_id)) {
						thread_id = arr_detail.get(i).getZMsgId();
						System.out.println("thread_id" + thread_id);
					} else {

					}
					if (arr_detail.get(i).getChatFriendId().equals(Friend_id)) {
						mesage_id = arr_detail.get(i).getLastMsgId();

						System.out.println("MESSAGEID" + mesage_id);
						type = "old";
						break;
					} else {
						type = "new";
					}

				}
				urlCount=0;
				new ChatRefreshTask().execute();

			} else {
				WellconnectedUtills.customDialog(GroupChatActivity.this, "Internet connection is not available");

			}
			}
		
			 
		}
	};

	// save imagee to internal storage

	private String saveToInternalSorage(Bitmap bitmapImage, String filename) {
		ContextWrapper cw = new ContextWrapper(getApplicationContext());
		// path to /data/data/yourapp/app_data/imageDir
		File directory = cw.getDir("wellconnected", Context.MODE_PRIVATE);
		// Create imageDir
		File mypath = new File(directory,/* "profile.jpg" */filename);

		FileOutputStream fos = null;
		try {

			fos = new FileOutputStream(mypath);

			// Use the compress method on the BitMap object to write image to
			// the OutputStream
			bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
			fos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return directory.getAbsolutePath();
	}

	public String getRandomNumber() {

		char[] chars = "abcdefghijklmnopqrstuvwxyz0123456789".toCharArray();
		StringBuilder sb = new StringBuilder();
		Random random = new Random();
		for (int i = 0; i < 40; i++) {
			char c = chars[random.nextInt(chars.length)];
			sb.append(c);
		}
		String output = sb.toString();
		System.out.println(output);
		return output;
	}

	private class ProgressTask extends AsyncTask<Void, Void, Void> {
		@Override
		protected void onPreExecute() {
			bar.setVisibility(View.VISIBLE);
		}

		@Override
		protected Void doInBackground(Void... arg0) {

			return null;
			// my stuff is here
		}

		@Override
		protected void onPostExecute(Void result) {

			try {
				getChatViewWithArray(firstLimit);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			bar.setVisibility(View.GONE);
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// return to the App's Home Activity
		// System.out.println("BACKKKKKKK");

		if ((keyCode == KeyEvent.KEYCODE_BACK)) {

			System.out.println("BACKKKKKKK");
			if(drawershere.isOpened())
			{
				drawershere.close();
			}
			else
			{
				finish();
			}
		}
		  return true;  
	}

	/** send chat data **/

	public class SendChatData extends AsyncTask<String, Integer, String> {
		ProgressDialog progressDialog;
		JSONObject obj;
		MyGroupBase mygroup;
		String response, group_id;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			// progressDialog = ProgressDialog.show(GroupChatActivity.this, "",
			// "Please Wait");
		}

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub

			datasourse.open();
			// System.out.println("chat_type"+chat_type);
			if (chat_type.equals("1")) {
				int last_id = 0;
				String last_row_id = datasourse.getLastrecoard_table();
				if (last_row_id.equals("")) {
					last_id = 0;
				} else {
					last_id = Integer.parseInt(last_row_id) + 1;

				}

				System.out.println("LAST_ROW_ID" + last_id);
				if (Group_id.equals("0")) {
					group_id = "0";
				} else {
					group_id = Group_id;
				}
				datasourse.updatetabl_chat(
				/* WellconnectedConstant.id++ */last_id, group_id/* Groupid */,/* contant_type */"0", "0"/* readcount */, String.valueOf(unixTime), chat_type,params[0], "0"/* audioid */, "0"/* imageid */, "0",/* namecardid */
						user_id/* messageuserid */, crs_id + "", "0", "0", 
						"null",/* encrupted_msg */null);

			}

			System.out.println("thread_id" + thread_id);
			if (thread_id == null) {
				thread_id = random_Number;
			} else {

			}
			response = WellconnectedParse.send_chat_data(GroupChatActivity.this, user_id, Friend_id, params[0], params[1], params[2], "0", thread_id/* random_Number */, grouptype, group_id, "1"/* chatstatus */);

			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if (response != null) {
				JSONObject obj;
				try {
					obj = new JSONObject(response);
					JSONObject obj_res = obj.getJSONObject("response");
					if (obj_res.has("success")) {
						// insert one row in dbb
					} else {

					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}
	}

	/** send chat audio file **/

	public class SendChatAudioFileTask extends AsyncTask<String, Integer, String> {
		ProgressDialog progressDialog;
		JSONObject obj;
		String response;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
		}

		@Override
		protected String doInBackground(String... params) {

			System.out.println("thread_id" + thread_id);
			if (thread_id == null) {
				thread_id = random_Number;
			} else {

			}

			ArrayList<String> fileArrayList = new ArrayList<String>();
			// image file path name

			if (imageFilePath == null || imageFilePath.equals("")) {
				imageFilePath = "";
			} else {
				File file = new File(imageFilePath);
				System.out.println("AUDIO_FILE_PATH_IN_WEBSERVICE"+imageFilePath);
				fileArrayList.add(file.getPath());
			}

			ArrayList<String[]> dataArrayList = new ArrayList<String[]>();

			String[] f = new String[2];

			f[0] = "type";
			f[1] = params[1];
			dataArrayList.add(f);

			chat_type = params[1];

			String URL = WellconnectedConstant.WEBSERVICE_URL + "uploadmedia";

			// give image name

			response = new JsonPostRequest1().doPostWithAudioFile(URL, dataArrayList, fileArrayList, "test_audio", ".mp4");
			System.out.println("response" + response);

			Log.i("gotResponseeeeeeee", response);

			return null;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
		 */
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);

			if (response != null) {
				JSONObject object, object_res = null;
				try {
					object = new JSONObject(response);
					object_res = object.getJSONObject("response");

				} catch (JSONException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				if (object_res.has("success")) {

					String image;
					try {
						image = object_res.getString("audio");
						System.out.println("audio" + image);

						int last_id = 0;
						String last_row_id = datasourse.getLastrecoard_table();
						if (last_row_id.equals("")) {
							last_id = 0;
						} else {
							last_id = Integer.parseInt(last_row_id) + 1;

						}

						System.out.println("LAST_ROW_ID" + last_id);

						datasourse.updatetabl_chat(/*
													 * WellconnectedConstant.id++
													 */last_id, Group_id/* Groupid */,/* contant_type */"0", "0"/* readcount */, String.valueOf(unixTime), chat_type,/*
																																								 */imageFilePath, "0"/* audioid */, "0"/* imageid */, "0",/* namecardid */
								user_id/* messageuserid */, crs_id + "", "0", "0", /*
																					 */"null",/* encrupted_msg */
								null);

						String msg;
						if (type.equals("2")) {
							msg = "[Image File]";
						} else {
							msg = "[Audio File]";
						}
						response = WellconnectedParse.send_chat_data(GroupChatActivity.this, user_id, Friend_id, msg, type, image, "0", thread_id/* random_Number */, grouptype, Group_id, "1"/* chatstatus */);

					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else {

					try {
						WellconnectedUtills.customDialog(GroupChatActivity.this, object_res.getString("error"));
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
			}
		}
	}

	/** send chat data file **/

	public class SendChatDataFileTask extends AsyncTask<String, Integer, String> {
		ProgressDialog progressDialog;
		JSONObject obj;
		String response;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
		}

		@Override
		protected String doInBackground(String... params) {

			System.out.println("thread_id" + thread_id);
			if (thread_id == null) {
				thread_id = random_Number;
			} else {

			}

			ArrayList<String> fileArrayList = new ArrayList<String>();
			// image file path name

			if (imageFilePath == null || imageFilePath.equals("")) {
				imageFilePath = "";
			} else {
				File file = new File(imageFilePath);
				fileArrayList.add(file.getPath());
			}

			ArrayList<String[]> dataArrayList = new ArrayList<String[]>();

			String[] f = new String[2];

			f[0] = "type";
			f[1] = params[1];
			dataArrayList.add(f);

			chat_type = params[1];

			String URL = WellconnectedConstant.WEBSERVICE_URL + "uploadmedia";

			// give image name

			response = new JsonPostRequest1().doPostWithFile1(URL, dataArrayList, fileArrayList, "image", "png");
			System.out.println("response" + response);

			Log.i("gotResponseeeeeeee", response);

			return null;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
		 */
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);

			if (response != null) {
				JSONObject object, object_res = null;
				try {
					object = new JSONObject(response);
					object_res = object.getJSONObject("response");

				} catch (JSONException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				if (object_res.has("success")) {

					String image;
					try {
						image = object_res.getString("image");
						System.out.println("image" + image);

						int last_id = 0;
						String last_row_id = datasourse.getLastrecoard_table();
						if (last_row_id.equals("")) {
							last_id = 0;
						} else {
							last_id = Integer.parseInt(last_row_id) + 1;

						}

						System.out.println("LAST_ROW_ID" + last_id);

						datasourse.updatetabl_chat(/*
													 * WellconnectedConstant.id++
													 */last_id, Group_id/* Groupid */,/* contant_type */"0", "0"/* readcount */, String.valueOf(unixTime), chat_type,
								imageFilePath, "0"/* audioid */, "0"/* imageid */, "0",/* namecardid */
								user_id/* messageuserid */, crs_id + "", "0", "0", "null",/* encrupted_msg */
								null);

						String msg;
						if (type.equals("2")) {
							msg = "[Image File]";
						} else {
							msg = "[Audio File]";
						}
						response = WellconnectedParse.send_chat_data(GroupChatActivity.this, user_id, Friend_id, msg, type, image, "0", thread_id/* random_Number */, grouptype, Group_id, "1"/* chatstatus */);

					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else {

					try {
						WellconnectedUtills.customDialog(GroupChatActivity.this, object_res.getString("error"));
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
			}
		}
	}

	/** chat refresh task **/
	public class ChatRefreshTask extends AsyncTask<String, Integer, String> {

		JSONObject obj;
		MyGroupBase mygroup;
		String response;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			
		}

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			is_chat_received=true;
			response = WellconnectedParse.Chat_detail(GroupChatActivity.this, user_id, Friend_id, Group_type, Group_id, mesage_id, type, "1");
			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
				if (response != null) {

				try {
					JSONObject obj = new JSONObject(response);
					JSONObject obj_res = obj.getJSONObject("response");
					JSONObject obj_success = obj_res.getJSONObject("success");
					JSONArray arr_request_data = null;
					try {
						arr_request_data = obj_success.getJSONArray("request_data");

					} catch (Exception e) {
						arr_request_data = obj_success.getJSONArray("ChatDetail");

						// TODO: handle exception
					}
				
					JSONArray arr_chat_detail = obj_success.getJSONArray("ChatDetail");
				
					//add in previos 
					arr_chat=new ArrayList<ChatDetailGroupBean>();
					// System.out.println("arr_chat_detail"+arr_chat_detail.length());
					for (int i = 0; i < arr_chat_detail.length(); i++) {
						JSONObject obje = arr_chat_detail.getJSONObject(i);

						ChatDetailGroupBean chatobj = new ChatDetailGroupBean();
						chatobj.setChat_type(obje.getString("chat_type"));
						chatobj.setDate(obje.getString("date"));
						try {
							chatobj.setFriend_id(obje.getString("friend_id"));

						} catch (Exception e) {
							// TODO: handle exception
						}
						chatobj.setImage(obje.getString("image"));
						try {
							chatobj.setMessage(obje.getString("message"));

						} catch (Exception e) {
							// TODO: handle exception
						}
						chatobj.setMsgid(obje.getString("msgid"));
						chatobj.setStaticc(obje.getString("static"));
						chatobj.setThread_id(obje.getString("thread_id"));
						chatobj.setTimestamp(obje.getString("timestamp"));
						chatobj.setUsername(obje.getString("username"));
						try {
							chatobj.setType(obje.getString("type"));

							chatobj.setImage_url(obje.getString("image_url"));

						} catch (Exception e) {
							// TODO: handle exception
						}

						chatobj.setUsername(obje.getString("username"));
						try {
							chatobj.setAudio_url(obje.getString("audio_url"));

						} catch (Exception e) {
							// TODO: handle exception
						}

						arr_chat.add(chatobj);
						arr_chat_new.add(chatobj);
					}
					// insert data in database
					if (arr_chat.isEmpty()) {
						
						
					} else {
						fileDownloadReceiver = new FileDownloadReceiver();
						registerReceiver(fileDownloadReceiver, new IntentFilter("android.intent.action.DOWNLOAD_COMPLETE"));

						//WellconnectedConstant.id_1 = WellconnectedConstant.id_1 + 1;
						crs_id = WellconnectedConstant.id_1;

						datasourse.open();
						datasourse.UPDATE_TBL_CHAT(WellconnectedConstant.id_1, user_id, Friend_id, arr_chat.get(0).getThread_id(), arr_chat.get(arr_chat.size() - 1).getMsgid());

						runOnUiThread(new Runnable() {

							@Override
							public void run() {
								// TODO Auto-generated method stub
								try {
									
									getChatWindowView();
								} catch (FileNotFoundException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						});

					}

				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	public class ChatDetailTask extends AsyncTask<String, Integer, String> {

		JSONObject obj;
		MyGroupBase mygroup;
		String response;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			try {
				progressDialog_download = ProgressDialog.show(GroupChatActivity.this, "", "Please Wait");

			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			response = WellconnectedParse.Chat_detail(GroupChatActivity.this, user_id, Friend_id, Group_type, Group_id, mesage_id, type, "1");
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
		
			if (response != null) {
				try {
					JSONObject obj = new JSONObject(response);
					JSONObject obj_res = obj.getJSONObject("response");
					JSONObject obj_success = obj_res.getJSONObject("success");
					JSONArray arr_request_data = null;
					try {
						arr_request_data = obj_success.getJSONArray("request_data");

					} catch (Exception e) {
						arr_request_data = obj_success.getJSONArray("ChatDetail");

						// TODO: handle exception
					}
					try {
						JSONObject objj = arr_request_data.getJSONObject(0);

						String block_status = objj.getString("block_status");

						if (block_status.equals("1")) {
							txt_block_name.setText("Unblock");
							is_user_block = true;
						} else {
							txt_block_name.setText("Block");
							is_user_block = false;
						}
						String friend_status = objj.getString("friend_status");
						if (friend_status.equals("0")) {
							linear_add.setVisibility(View.VISIBLE);
							linear_user_info.setVisibility(View.INVISIBLE);

						} else {
							linear_add.setVisibility(View.GONE);
							linear_user_info.setVisibility(View.VISIBLE);

						}
					} catch (Exception e) {
						// TODO: handle exception
					}

					JSONArray arr_chat_detail = obj_success.getJSONArray("ChatDetail");
					arr_chat = new ArrayList<ChatDetailGroupBean>();

					// System.out.println("arr_chat_detail"+arr_chat_detail.length());
					for (int i = 0; i < arr_chat_detail.length(); i++) {
						JSONObject obje = arr_chat_detail.getJSONObject(i);

						ChatDetailGroupBean chatobj = new ChatDetailGroupBean();
						
						try {
							chatobj.setRequest_status(obje.getString("request_status"));
							
						} catch (Exception e) {
							// TODO: handle exception
						}
						chatobj.setChat_type(obje.getString("chat_type"));
						chatobj.setDate(obje.getString("date"));
						try {
							chatobj.setFriend_id(obje.getString("friend_id"));

						} catch (Exception e) {
							// TODO: handle exception
						}
						chatobj.setImage(obje.getString("image"));
						try {
							chatobj.setMessage(obje.getString("message"));

						} catch (Exception e) {
							// TODO: handle exception
						}
							try {
								chatobj.setMsgid(obje.getString("msgid"));
								
							} catch (Exception e) {
								// TODO: handle exception
							}
						chatobj.setStaticc(obje.getString("static"));
						chatobj.setThread_id(obje.getString("thread_id"));
						chatobj.setTimestamp(obje.getString("timestamp"));
						chatobj.setUsername(obje.getString("username"));
						try {
							chatobj.setType(obje.getString("type"));

							chatobj.setImage_url(obje.getString("image_url"));

						} catch (Exception e) {
							// TODO: handle exception
						}
						chatobj.setUsername(obje.getString("username"));
						try {
							chatobj.setAudio_url(obje.getString("audio_url"));

						} catch (Exception e) {
							// TODO: handle exception
						}

						arr_chat.add(chatobj);
					}
					// insert data in database
					if (arr_chat.isEmpty()) {
						progressDialog_download.dismiss();
						datasourse.open();
						String row_id = datasourse.getRowId(user_id, Friend_id);

						if (row_id == null) {
							if (WellconnectedConstant.Courser_count > 0) {
								crs_id = pref.getInt("lastzchatId", 1) + 1;

							} else {
								crs_id = 1;
							}

						} else {
							crs_id = Integer.parseInt(row_id);

							SharedPreferences.Editor editor = pref.edit();
							editor.putInt("lastzchatId", crs_id);
							editor.commit();
						}
						//wellconnected id+1 wrong check
					//	WellconnectedConstant.id_1 = WellconnectedConstant.id_1 + 1;
						// crs_id=WellconnectedConstant.id_1;

						if (type.equals("new")) {
							System.out.println("TYPE==NEW");
								if(Friend_id==null||Friend_id.length()==0)
							{
								System.out.println("FRIEND_ID_NULL");
								
								datasourse.updatetbl_chatUser(WellconnectedConstant.id_1+1, user_id, Group_id, random_Number, "0");
								
							}
							else
							{
								datasourse.updatetbl_chatUser(WellconnectedConstant.id_1+1, user_id, Friend_id, random_Number, "0");
								
							}
						}

						getChatViewWithArray(firstLimit);

						datasourse.close();

						// get zchat id according chat friendid
					} else {
						fileDownloadReceiver = new FileDownloadReceiver();
						registerReceiver(fileDownloadReceiver, new IntentFilter("android.intent.action.DOWNLOAD_COMPLETE"));

						WellconnectedConstant.id_1 = WellconnectedConstant.id_1 + 1;
						crs_id = WellconnectedConstant.id_1;

					
						datasourse.open();
					if(Friend_id==null||Friend_id.length()==0)
						{
							System.out.println("FRIEND_ID_NULL");
							datasourse.updatetbl_chatUser(WellconnectedConstant.id_1, user_id, Group_id, arr_chat.get(0).getThread_id(), arr_chat.get(arr_chat.size() - 1).getMsgid());

							
						}
						else
						{
							datasourse.updatetbl_chatUser(WellconnectedConstant.id_1, user_id, Friend_id, arr_chat.get(0).getThread_id(), arr_chat.get(arr_chat.size() - 1).getMsgid());

							
						}
						runOnUiThread(new Runnable() {

							@Override
							public void run() {
								// TODO Auto-generated method stub
								try {
									if (linear_chat_window.getChildCount() > 0) {
										linear_chat_window.removeAllViews();
									}
									getChatWindowView();
								} catch (FileNotFoundException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						});

					}

				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	void getChatWindowView() throws FileNotFoundException {
		// insert data into table then retereive it for showing
		datasourse.open();

		for (int i = 0; i < arr_chat.size(); i++) {
			String date_time = getDateTime(Long.parseLong(arr_chat.get(i).getTimestamp()));
			// System.out.println("date_time"+date_time);
			datasourse.open();
			System.out.println("WellconnectedConstant.id" +WellconnectedConstant.id);

			if (arr_chat.get(i).getChat_type().equals("1")) {
				datasourse.updatetabl_chat(WellconnectedConstant.id++, "0"/* Groupid */,/* contant_type */"0", "0"/* readcount */, arr_chat.get(i).getTimestamp(), arr_chat.get(i).getChat_type(),arr_chat.get(i).getMessage(), "0"/* audioid */, "0"/* imageid */, "0",/* namecardid */arr_chat.get(i).getFriend_id()/* messageuserid */, crs_id + "", arr_chat.get(i).getStaticc(), arr_chat.get(i).getRequest_status(),
						arr_chat.get(i).getMsgid(),/* encrupted_msg */null);
				
			} else if (arr_chat.get(i).getChat_type().equals("2")) {
				File file1 = new File(Environment.getExternalStorageDirectory() + "/" + AUDIO_RECORDER_FOLDER, arr_chat.get(i).getImage_url());

				
				datasourse.updatetabl_chat(WellconnectedConstant.id++, "0"/* Groupid */,/* contant_type */"0", "0"/* readcount */, arr_chat.get(i).getTimestamp(), arr_chat.get(i).getChat_type(),file1.toString(), "0"/* audioid */, "0"/* imageid */, "0",/* namecardid */
						arr_chat.get(i).getFriend_id()/* messageuserid */, crs_id + "", arr_chat.get(i).getStaticc(), arr_chat.get(i).getRequest_status(), arr_chat.get(i).getMsgid(), null);
			} else {
				System.out.println("AUDIONAME" + arr_chat.get(i).getAudio_url());

				File file1 = new File(Environment.getExternalStorageDirectory() + "/" +AUDIO_RECORDER_FOLDER, arr_chat.get(i).getAudio_url());

				datasourse.updatetabl_chat(WellconnectedConstant.id++, "0"/* Groupid */,/* contant_type */"0", "0"/* readcount */, arr_chat.get(i).getTimestamp(), arr_chat.get(i).getChat_type(),file1.toString(), "0"/* audioid */, "0"/* imageid */, "0",/* namecardid */
						arr_chat.get(i).getFriend_id()/* messageuserid */, crs_id + "", arr_chat.get(i).getStaticc(), arr_chat.get(i).getRequest_status(), arr_chat.get(i).getMsgid(), null);
			}

			datasourse.close();
		}

		System.out.println("Print the arr_chat List Size :"+arr_chat.size());
		Boolean isSDPresent = android.os.Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED);
			
			if(isSDPresent)
			{
			  // yes SD-card is present
				DownloadFile(arr_chat);
			}
			else
			{
				WellconnectedUtills.customDialog(GroupChatActivity.this, "No SdCard found");
				
				progressDialog_download.dismiss();
			 // Sorry
			}
	}

	// add one rowwwww

	void AddoneView(String chat_type, String user_image, String message, String user_name, String Chat_image, String arr_friend_id, String timestamp, Bitmap bitmap2, float seconds) {
		ButtonValueBean btnobj = new ButtonValueBean();

		String date_time = getDateTime(Long.parseLong(timestamp));
		// System.out.println("date_time"+date_time);

		View row = null;
		if (chat_type.equals("1")) {
			// message
			row = View.inflate(GroupChatActivity.this, R.layout.mesage_row, null);
			RelativeLayout linear_right = (RelativeLayout) row.findViewById(R.id.linear_right);
			RelativeLayout linear_left = (RelativeLayout) row.findViewById(R.id.linear_left);
			ImageView img_chat_right = (ImageView) row.findViewById(R.id.img_chat_right);
			ImageView img_chat_left = (ImageView) row.findViewById(R.id.img_chat_left);
			Uri uri = Uri.parse(WellconnectedConstant.IMAGE_URL_1 + user_image);

			if (uri != null && uri.toString().length() > 0) {

				Bitmap bitmap = mHttpImageManager.loadImage(new HttpImageManager.LoadRequest(uri, img_chat_right, progressBar));
				if (bitmap != null) {

					img_chat_right.setImageBitmap((bitmap));

				}
				Bitmap bitmap1 = mHttpImageManager.loadImage(new HttpImageManager.LoadRequest(uri, img_chat_left, progressBar));
				if (bitmap1 != null) {

					img_chat_left.setImageBitmap((bitmap1));

				}
			}

			TextView txt_chat_username_right = (TextView) row.findViewById(R.id.txt_chat_username_right);
			
			TextView txt_chat_message_right = (TextView) row.findViewById(R.id.txt_chat_message_right);
			
			TextView txt_chat_username_left = (TextView) row.findViewById(R.id.txt_chat_username_left);
			
			TextView txt_chat_message_left = (TextView) row.findViewById(R.id.txt_chat_message_left);
			
			
			TextView txt_date = (TextView) row.findViewById(R.id.txt_date);
			TextView txt_date_left = (TextView) row.findViewById(R.id.txt_date_left);
			
			if (arr_friend_id.equals(user_id)) {
				linear_right.setVisibility(View.VISIBLE);
				linear_left.setVisibility(View.INVISIBLE);
				txt_chat_username_right.setText("Me");
				txt_chat_message_right.setText(message);
				txt_date_left.setVisibility(View.GONE);
				txt_date.setVisibility(View.VISIBLE);
				txt_date.setText(date_time);
			} else {
				linear_right.setVisibility(View.INVISIBLE);
				linear_left.setVisibility(View.VISIBLE);
				txt_chat_username_left.setText(user_name);
				txt_chat_message_left.setText(message);
				txt_date_left.setVisibility(View.VISIBLE);
				txt_date.setVisibility(View.GONE);
				txt_date_left.setText(date_time);
			}
				System.out.println("ADDPOSITION"+(arr_btn_value.size()));
			btnobj.setBtn_audio(null);
			btnobj.setChat_type(chat_type);
			btnobj.setImage_audio_value(message);
			btnobj.setTag(arr_btn_value.size());
			btnobj.setValue(false);
			btnobj.setVoluBar(null);
			arr_btn_value.add(btnobj);
		} else if (chat_type.equals("2")) {
			// image
			row = View.inflate(GroupChatActivity.this, R.layout.chat_image_row, null);
			
			
			LinearLayout linear_right = (LinearLayout) row.findViewById(R.id.linear_right);
			LinearLayout linear_left = (LinearLayout) row.findViewById(R.id.linear_left);

			ImageView img_chat_right = (ImageView) row.findViewById(R.id.img_chat_right);
			ImageView img_chat_left = (ImageView) row.findViewById(R.id.img_chat_left);

			Uri uri = Uri.parse(WellconnectedConstant.IMAGE_URL_1 + user_image);

			if (uri != null && uri.toString().length() > 0) {

				Bitmap bitmap = mHttpImageManager.loadImage(new HttpImageManager.LoadRequest(uri, img_chat_right, progressBar));
				if (bitmap != null) {

					img_chat_right.setImageBitmap((bitmap));

				}
				Bitmap bitmap1 = mHttpImageManager.loadImage(new HttpImageManager.LoadRequest(uri, img_chat_left, progressBar));
				if (bitmap1 != null) {

					img_chat_left.setImageBitmap((bitmap1));

				}
			}

			TextView txt_chat_username_left = (TextView) row.findViewById(R.id.txt_chat_username_left);
			TextView txt_chat_username_right = (TextView) row.findViewById(R.id.txt_chat_username_right);
		ImageView chat_image_left = (ImageView) row.findViewById(R.id.chat_image_left);
			ImageView chat_image_right = (ImageView) row.findViewById(R.id.chat_image_right);
			
			
			chat_image_left.setTag(arr_chat_new.size()-1);
			chat_image_left.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					int pos=(Integer) v.getTag();
					System.out.println("CHAT IMAGE CLICK");
					
					Intent intent=new Intent(GroupChatActivity.this,GalleryView.class);
					intent.putExtra("IMAGE",arr_chat_new.get(pos).getImage_url());
					WellconnectedConstant.arr_chat_new=arr_chat_new;
					startActivity(intent);
				}
			});
			chat_image_right.setTag(arr_chat_new.size()-1);
			chat_image_right.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					int pos=(Integer) v.getTag();
					System.out.println("CHAT IMAGE CLICK");
					
					Intent intent=new Intent(GroupChatActivity.this,GalleryView.class);
					intent.putExtra("IMAGE",arr_chat_new.get(pos).getImage_url());
					WellconnectedConstant.arr_chat_new=arr_chat_new;
					startActivity(intent);
				}
			});
			chat_image_left.setImageBitmap(bitmap2);
			chat_image_right.setImageBitmap(bitmap2);
		
			TextView txt_date = (TextView) row.findViewById(R.id.txt_date);
			TextView txt_date_left = (TextView) row.findViewById(R.id.txt_date_left);

			if (arr_friend_id.equals(user_id)) {
				linear_right.setVisibility(View.VISIBLE);
				linear_left.setVisibility(View.INVISIBLE);
				txt_chat_username_right.setText("Me");
				txt_date.setText(date_time);
				txt_date_left.setVisibility(View.GONE);
				txt_date.setVisibility(View.VISIBLE);
			} else {
				linear_right.setVisibility(View.INVISIBLE);
				linear_left.setVisibility(View.VISIBLE);
				txt_chat_username_left.setText("Me");
				txt_date_left.setText(date_time);
				txt_date_left.setVisibility(View.VISIBLE);
				txt_date.setVisibility(View.GONE);
			}
			System.out.println("ADDPOSITION"+(arr_btn_value.size()+1));
			btnobj.setBtn_audio(null);
			btnobj.setChat_type(chat_type);
			btnobj.setImage_audio_value(message);
			btnobj.setTag(arr_btn_value.size());
			btnobj.setValue(false);
			btnobj.setVoluBar(null);
			arr_btn_value.add(btnobj);

			// save image in sd card

		} else {
			row = View.inflate(GroupChatActivity.this, R.layout.audio_row, null);
			RelativeLayout linear_right = (RelativeLayout) row.findViewById(R.id.linear_right);
			RelativeLayout linear_left = (RelativeLayout) row.findViewById(R.id.linear_left);

			TextView txt_time_right=(TextView) row.findViewById(R.id.txt_time_right);
			
			TextView txt_time_left=(TextView) row.findViewById(R.id.txt_time_left);
			
			txt_time_right.setText(String.valueOf(seconds)+" "+"Sec");
			txt_time_left.setText(String.valueOf(seconds)+" "+"Sec");
			
		
			volumebar = (SeekBar) row.findViewById(R.id.volumebar);
			volumebar.setOnTouchListener(new View.OnTouchListener() {
	            @Override
	            public boolean onTouch(View view, MotionEvent motionEvent) {
	            	System.out.println("VOLUMEBAR_Touchlistener");
	                return true;
	            }
	        });
			ImageView img_chat_right = (ImageView) row.findViewById(R.id.img_chat_right);
			ImageView img_chat_left = (ImageView) row.findViewById(R.id.img_chat_left);

			Uri uri = Uri.parse(WellconnectedConstant.IMAGE_URL_1 + user_image);

			if (uri != null && uri.toString().length() > 0) {

				Bitmap bitmap = mHttpImageManager.loadImage(new HttpImageManager.LoadRequest(uri, img_chat_right, progressBar));
				if (bitmap != null) {

					img_chat_right.setImageBitmap((bitmap));
				}

				Bitmap bitmap1 = mHttpImageManager.loadImage(new HttpImageManager.LoadRequest(uri, img_chat_left, progressBar));
				if (bitmap1 != null) {

					img_chat_left.setImageBitmap((bitmap1));
				}
			}
			btn_audio_play = (ImageButton) row.findViewById(R.id.btn_audio_play);

			System.out.println("ADD pos=====" + linear_chat_window.getChildCount());

			txt_time = (TextView) row.findViewById(R.id.txt_time);
			btn_audio_play.setOnClickListener(new OnClickListener() {
		/*s
				 * (non-Javadoc)
				 * 
				 * @see
				 * android.view.View.OnClickListener#onClick(android.view.View)
				 */
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub

					currentBeanObj = (ButtonValueBean) arg0.getTag();

					if (previousBeanObj != null) {

						if (previousBeanObj.isValue()) {

							previousBeanObj.getBtn_audio().setBackgroundResource(R.drawable.play_btn);
							previousBeanObj.setValue(false);
							stopPlaying();

							if (previousBeanObj.getTag() != currentBeanObj.getTag()) {

									previousBeanObj = currentBeanObj;
									previousBeanObj.getBtn_audio().setBackgroundResource(R.drawable.pause_btn);
									previousBeanObj.setValue(true);
									String url = previousBeanObj.getImage_audio_value();
									CurrentvoluBar=previousBeanObj.getVoluBar();
									CurrentvoluBar.setOnTouchListener(new View.OnTouchListener() {
							            @Override
							            public boolean onTouch(View view, MotionEvent motionEvent) {
							                return true;
							            }
							        });

									System.out.println("url" + url);
									new playAsyntask().execute(url);
							}
						} else if (previousBeanObj == null) {

							previousBeanObj = currentBeanObj;
							previousBeanObj.getBtn_audio().setBackgroundResource(R.drawable.pause_btn);
							previousBeanObj.setValue(true);
							String url = previousBeanObj.getImage_audio_value();
							CurrentvoluBar=previousBeanObj.getVoluBar();
							
							CurrentvoluBar.setOnTouchListener(new View.OnTouchListener() {
					            @Override
					            public boolean onTouch(View view, MotionEvent motionEvent) {
					                return true;
					            }
					        });

							System.out.println("url" + url);
							new playAsyntask().execute(url);
						}else if(previousBeanObj.isValue() == false){
							
							previousBeanObj = currentBeanObj;
							previousBeanObj.getBtn_audio().setBackgroundResource(R.drawable.pause_btn);
							previousBeanObj.setValue(true);
							String url = previousBeanObj.getImage_audio_value();
							CurrentvoluBar=previousBeanObj.getVoluBar();
							
							CurrentvoluBar.setOnTouchListener(new View.OnTouchListener() {
					            @Override
					            public boolean onTouch(View view, MotionEvent motionEvent) {
					                return true;
					            }
					        });

							System.out.println("url" + url);
							new playAsyntask().execute(url);
						}
					} else {

						previousBeanObj = currentBeanObj;
						previousBeanObj.getBtn_audio().setBackgroundResource(R.drawable.pause_btn);
						previousBeanObj.setValue(true);
						String url = previousBeanObj.getImage_audio_value();
						CurrentvoluBar=previousBeanObj.getVoluBar();
						
						CurrentvoluBar.setOnTouchListener(new View.OnTouchListener() {
				            @Override
				            public boolean onTouch(View view, MotionEvent motionEvent) {
				                return true;
				            }
				        });

						System.out.println("url" + url);
						new playAsyntask().execute(url);
					}

					
				}
			});
			TextView txt_date = (TextView) row.findViewById(R.id.txt_date);
			TextView txt_date_left = (TextView) row.findViewById(R.id.txt_date_left);
			

			TextView txt_chat_username_right = (TextView) row.findViewById(R.id.txt_chat_username_right);
			TextView txt_chat_username_left = (TextView) row.findViewById(R.id.txt_chat_username_left);
											
			if (arr_friend_id.equals(user_id)) {
				linear_right.setVisibility(View.VISIBLE);
				linear_left.setVisibility(View.INVISIBLE);
				txt_chat_username_right.setText("Me");
				txt_date.setText(date_time);
				txt_date_left.setVisibility(View.GONE);
				txt_date.setVisibility(View.VISIBLE);
			} else {
				linear_right.setVisibility(View.INVISIBLE);
				linear_left.setVisibility(View.VISIBLE);
				txt_chat_username_left.setText(arr_chat_new.get(0).getUsername());
				txt_date_left.setText(date_time);
				txt_date_left.setVisibility(View.VISIBLE);
				txt_date.setVisibility(View.GONE);
				
			}

			
			System.out.println("ADDPOSITION"+(arr_btn_value.size()+1));
			
			btnobj.setBtn_audio(btn_audio_play);
			btnobj.setChat_type(chat_type);
			btnobj.setTag(arr_btn_value.size());
			btnobj.setImage_audio_value(message);
			btnobj.setValue(false);
			btnobj.setVoluBar(volumebar);
			arr_btn_value.add(btnobj);
			
			btn_audio_play.setTag(btnobj);
		}
		linear_chat_window.addView(row);
		edit_view = View.inflate(GroupChatActivity.this, R.layout.edit_view, null);
		ed_focus = (EditText) edit_view.findViewById(R.id.ed_focus);

		linear_chat_window.addView(edit_view);

		/*
		 * final EditText ed_focus=new EditText(GroupChatActivity.this);
		 * ed_focus.setVisibility(View.INVISIBLE);
		 * linear_chat_window.addView(ed_focus);
		 */
		new Handler().post(new Runnable() {
			@Override
			public void run() {
				scroll.scrollTo(0, ed_focus.getBottom());
			}
		});
		ed_focus.requestFocus();
		// ed_focus.setVisibility(View.INVISIBLE);

	}

	private void getChatViewWithArray(int firstLimit) throws FileNotFoundException {
		// TODO Auto-generated method stub
		String text = null;
		datasourse.open();
		String row_id ="";
		if(Friend_id.length()==0)
		{
			 row_id = datasourse.getRowId(user_id, Group_id);
				
		}
		else
		{
			 row_id = datasourse.getRowId(user_id, Friend_id);
				
		}
		System.out.println("row_id" + row_id);
		
		
		count = datasourse.getCount(row_id);

		System.out.println("count" + count);
		// to be removedd
		arr_chat_new = datasourse.getChatValue(row_id, String.valueOf(firstLimit));
		System.out.println("arr_chat_new" + arr_chat_new.size());

		if(WellconnectedConstant.is_chat_refresh.equals("1"))
		{
			if(!arr_chat_new.isEmpty())
			{
			for (int i = 0; i < 1; i++) {
				String date_time = getDateTime(Long.parseLong(arr_chat_new.get(0).getTimestamp()));

				ButtonValueBean btnobj = new ButtonValueBean();

				View row = null;
				if (arr_chat_new.get(0).getChat_type().equals("1")) {
					// message
					if (arr_chat_new.get(0).getStaticc().equals("1")) {
						if(arr_chat_new.get(0).getRequest_status()!=null&&arr_chat_new.get(0).getRequest_status().equals("1"))
						{
							final String memberId=arr_chat_new.get(i).getFriend_id();
							final String messageId=arr_chat_new.get(i).getMsgid();
						
							//show join requestf
							row = View.inflate(GroupChatActivity.this, R.layout.group_join_1_row, null);
							TextView txt_chat_username_left=(TextView) row.findViewById(R.id.txt_chat_username_left);
							txt_chat_username_left.setText(arr_chat_new.get(0).getUsername());
							
							TextView txt_chat_message_left=(TextView) row.findViewById(R.id.txt_chat_message_left);
							txt_chat_message_left.setText(arr_chat_new.get(0).getMessage());
						
							ImageView img_chat_left=(ImageView) row.findViewById(R.id.img_chat_left);
							Button btn_accept=(Button) row.findViewById(R.id.btn_accept);
							Button btn_reject=(Button) row.findViewById(R.id.btn_reject);
							
							ProgressBar progress_group_join=(ProgressBar) row.findViewById(R.id.progress_group_join);
							Uri uri = Uri.parse(WellconnectedConstant.IMAGE_URL_1 + arr_chat_new.get(0).getImage());
							if (uri != null && uri.toString().length() > 0) {

								Bitmap bitmap1 = mHttpImageManager.loadImage(new HttpImageManager.LoadRequest(uri, img_chat_left, progressBar));
								if (bitmap1 != null) {
									img_chat_left.setImageBitmap((bitmap1));
								}
							}
							btn_accept.setOnClickListener(new OnClickListener() {
								
								@Override
								public void onClick(View arg0) {
									// TODO Auto-generated method stub
									status="2";
									WellconnectedConstant.is_chat_refresh="";
									new OwnerGroupActionAsyntask().execute(Group_id,status,memberId,messageId);
										}
							});
						
							btn_reject.setOnClickListener(new OnClickListener() {
								
								@Override
								public void onClick(View arg0) {
									// TODO Auto-generated method stub
									status="3";
									WellconnectedConstant.is_chat_refresh="";
									new OwnerGroupActionAsyntask().execute(Group_id,status,memberId,messageId);
							
								}
							});
						}
						else
						{
							row = View.inflate(GroupChatActivity.this, R.layout.youjoined, null);
							TextView txt_join_msg=(TextView) row.findViewById(R.id.txt_join_msg);
							txt_join_msg.setText(arr_chat_new.get(i).getMessage());
					
						}
					
					} else {

						row = View.inflate(GroupChatActivity.this, R.layout.mesage_row, null);
						RelativeLayout linear_right = (RelativeLayout) row.findViewById(R.id.linear_right);
						RelativeLayout linear_left = (RelativeLayout) row.findViewById(R.id.linear_left);
						ImageView img_chat_right = (ImageView) row.findViewById(R.id.img_chat_right);

						img_chat_right.setTag(0);
						img_chat_right.setOnClickListener(new OnClickListener() {

							@Override
							public void onClick(View arg0) {
								/*// int pos=(Integer) arg0.getTag();
								WellconnectedConstant.Group_id = "0";

								Intent intent = new Intent(GroupChatActivity.this, UserInfoActivity.class);
								intent.putExtra("Friend_id", Friend_id);
								intent.putExtra("thread_id", crs_id + "");

								WellconnectedConstant.refrence = GroupChatActivity.this;
								startActivityForResult(intent, 0);
	*/
							}
						});

						ImageView img_chat_left = (ImageView) row.findViewById(R.id.img_chat_left);
						img_chat_left.setTag(i);
						img_chat_left.setOnClickListener(new OnClickListener() {

							@Override
							public void onClick(View arg0) {
								// TODO Auto-generated method stub
								// int pos=(Integer) arg0.getTag();
							/*	WellconnectedConstant.Group_id = "0";

								Intent intent = new Intent(GroupChatActivity.this, UserInfoActivity.class);
								intent.putExtra("Friend_id", Friend_id);
								intent.putExtra("thread_id", crs_id + "");

								WellconnectedConstant.refrence = GroupChatActivity.this;
								startActivityForResult(intent, 0);*/

							}
						});

						TextView txt_chat_username_right = (TextView) row.findViewById(R.id.txt_chat_username_right);
						
						TextView txt_chat_message_right = (TextView) row.findViewById(R.id.txt_chat_message_right);
						
						TextView txt_chat_username_left = (TextView) row.findViewById(R.id.txt_chat_username_left);
							
						TextView txt_chat_message_left = (TextView) row.findViewById(R.id.txt_chat_message_left);
						
						
						TextView txt_date = (TextView) row.findViewById(R.id.txt_date);
						TextView txt_date_left = (TextView) row.findViewById(R.id.txt_date_left);
						
						ProgressBar txt_chatprogressBar = (ProgressBar) row.findViewById(R.id.txt_chatprogressBar);

						Uri uri = Uri.parse(WellconnectedConstant.IMAGE_URL_1 + arr_chat_new.get(0).getImage());

						if (uri != null && uri.toString().length() > 0) {

							Bitmap bitmap = mHttpImageManager.loadImage(new HttpImageManager.LoadRequest(uri, img_chat_right, txt_chatprogressBar));
							if (bitmap != null) {

								img_chat_right.setImageBitmap((bitmap));
							}

							Bitmap bitmap1 = mHttpImageManager.loadImage(new HttpImageManager.LoadRequest(uri, img_chat_left, txt_chatprogressBar));
							if (bitmap1 != null) {
								img_chat_left.setImageBitmap((bitmap1));
							}
						}

						try {
							if(arr_chat_new.get(0).getMessage()!=null)
							{
								try {
									byte[] data = Base64.decode(arr_chat_new.get(0).getMessage(), Base64.DEFAULT);
									text = new String(data, "UTF-8");
									
									btnobj.setImage_audio_value(text);

								} catch (IllegalArgumentException e) {
									// TODO: handle exception
								}
							
							}
							
						} catch (UnsupportedEncodingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						if (arr_chat_new.get(0).getFriend_id().equals(user_id)) {
							linear_right.setVisibility(View.VISIBLE);
							linear_left.setVisibility(View.INVISIBLE);
							txt_chat_username_right.setText("Me");
							txt_chat_message_right.setText(text);
							txt_date_left.setVisibility(View.GONE);
							txt_date.setVisibility(View.VISIBLE);
							txt_date.setText(date_time);

						} else {
							linear_right.setVisibility(View.INVISIBLE);
							linear_left.setVisibility(View.VISIBLE);
							txt_chat_message_left.setText(text);
							txt_date_left.setText(date_time);
							txt_date_left.setVisibility(View.VISIBLE);
							txt_date.setVisibility(View.GONE);
							txt_chat_username_left.setText(arr_chat_new.get(0).getUsername());
						}
						System.out.println("MESSAGE_ID" + arr_chat_new.get(0).getMsgid());

						btnobj.setBtn_audio(null);
						btnobj.setChat_type("1");
						btnobj.setTag(0);
						btnobj.setValue(false);
						btnobj.setVoluBar(null);
						arr_btn_value.add(btnobj);
					}
				} else if (arr_chat_new.get(0).getChat_type().equals("2")) {
					// image
					row = View.inflate(GroupChatActivity.this, R.layout.chat_image_row, null);
					
					LinearLayout linear_right = (LinearLayout) row.findViewById(R.id.linear_right);
					LinearLayout linear_left = (LinearLayout) row.findViewById(R.id.linear_left);

					ImageView img_chat_right = (ImageView) row.findViewById(R.id.img_chat_right);

					img_chat_right.setTag(0);
					img_chat_right.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View arg0) {
							// TODO Auto-generated method stub
							// /int pos=(Integer) arg0.getTag();
						/*	WellconnectedConstant.Group_id = "0";

							Intent intent = new Intent(GroupChatActivity.this, UserInfoActivity.class);
							intent.putExtra("Friend_id", Friend_id);
							intent.putExtra("thread_id", crs_id + "");

							WellconnectedConstant.refrence = GroupChatActivity.this;
							startActivityForResult(intent, 0);
	*/
						}
					});
					ImageView img_chat_left = (ImageView) row.findViewById(R.id.img_chat_left);
					img_chat_left.setTag(0);
					img_chat_left.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View arg0) {
							// TODO Auto-generated method stub
							// int pos=(Integer) arg0.getTag();
							/*WellconnectedConstant.Group_id = "0";

							Intent intent = new Intent(GroupChatActivity.this, UserInfoActivity.class);
							intent.putExtra("Friend_id", Friend_id);
							intent.putExtra("thread_id", crs_id + "");

							WellconnectedConstant.refrence = GroupChatActivity.this;
							startActivityForResult(intent, 0);*/

						}
					});

					ProgressBar progress_img = (ProgressBar) row.findViewById(R.id.progress_img);

					Uri uri = Uri.parse(WellconnectedConstant.IMAGE_URL_1 + arr_chat_new.get(0).getImage());

					if (uri != null && uri.toString().length() > 0) {

						Bitmap bitmap = mHttpImageManager.loadImage(new HttpImageManager.LoadRequest(uri, img_chat_right, progressBar));
						if (bitmap != null) {

							img_chat_right.setImageBitmap((bitmap));
						}

						Bitmap bitmap1 = mHttpImageManager.loadImage(new HttpImageManager.LoadRequest(uri, img_chat_left, progressBar));
						if (bitmap1 != null) {
							img_chat_left.setImageBitmap((bitmap1));
						}
					}
					TextView txt_chat_username_left = (TextView) row.findViewById(R.id.txt_chat_username_left);
					TextView txt_chat_username_right = (TextView) row.findViewById(R.id.txt_chat_username_right);
				ImageView chat_image_left = (ImageView) row.findViewById(R.id.chat_image_left);
					ImageView chat_image_right = (ImageView) row.findViewById(R.id.chat_image_right);
					
					
					chat_image_left.setTag(0);
					chat_image_left.setOnClickListener(new OnClickListener() {
						
						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							int pos=(Integer) v.getTag();
							System.out.println("CHAT IMAGE CLICK");
							
							Intent intent=new Intent(GroupChatActivity.this,GalleryView.class);
							intent.putExtra("IMAGE",arr_chat_new.get(pos).getImage_url());
							
							WellconnectedConstant.arr_chat_new=arr_chat_new;
							startActivity(intent);
						}
					});
					
					chat_image_right.setTag(0);
					chat_image_right.setOnClickListener(new OnClickListener() {
						
						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							int pos=(Integer) v.getTag();
							System.out.println("CHAT IMAGE CLICK");
							
							Intent intent=new Intent(GroupChatActivity.this,GalleryView.class);
							intent.putExtra("IMAGE",arr_chat_new.get(pos).getImage_url());
							
							WellconnectedConstant.arr_chat_new=arr_chat_new;
							startActivity(intent);
						}
					});
					System.out.println("CHAT IMAGE" + WellconnectedConstant.IMAGE_URL_5 + arr_chat_new.get(0).getImage_url());

					Uri uri1 = Uri.parse(arr_chat_new.get(0).getImage_url());

					// Uri uri1 =
					// Uri.parse(WellconnectedConstant.IMAGE_URL_5+arr_chat_new.get(i).getImage_url());

					if (uri1 != null && uri1.toString().length() > 0) {

						File image = new File(arr_chat_new.get(0).getImage_url());

						FileInputStream in = new FileInputStream(image);

						BitmapFactory.Options options = new BitmapFactory.Options();
						options.inSampleSize = 4;
						bitmap = BitmapFactory.decodeStream(in, null, options);

						// Bitmap bitmap = mHttpImageManager.loadImage(new
						// HttpImageManager.LoadRequest(uri1, chat_image,
						// progressBar));
						System.out.println("CHAT-BITMAP"+bitmap);
						if (bitmap != null) {
							chat_image_left.setImageBitmap((bitmap));
							chat_image_right.setImageBitmap((bitmap));
						}
					}
					TextView txt_date = (TextView) row.findViewById(R.id.txt_date);
					TextView txt_date_left = (TextView) row.findViewById(R.id.txt_date_left);

					if (arr_chat_new.get(0).getFriend_id().equals(user_id)) {
						linear_right.setVisibility(View.VISIBLE);
						linear_left.setVisibility(View.INVISIBLE);
						txt_chat_username_right.setText("Me");
						txt_date_left.setVisibility(View.GONE);
						txt_date.setVisibility(View.VISIBLE);
						txt_date.setText(date_time);
					} else {
						linear_right.setVisibility(View.INVISIBLE);
						linear_left.setVisibility(View.VISIBLE);
						txt_chat_username_left.setText(arr_chat_new.get(0).getUsername());
						txt_date_left.setVisibility(View.VISIBLE);
						txt_date.setVisibility(View.GONE);
						txt_date_left.setText(date_time);
						
					}
					btnobj.setTag(0);
					btnobj.setBtn_audio(null);
					btnobj.setChat_type("2");
					btnobj.setImage_audio_value(/*
												 * WellconnectedConstant.IMAGE_URL_5+
												 */arr_chat_new.get(0).getImage_url());
					btnobj.setValue(false);
					btnobj.setVoluBar(null);
					arr_btn_value.add(btnobj);
				} else {
					row = View.inflate(GroupChatActivity.this, R.layout.audio_row, null);
					RelativeLayout linear_right = (RelativeLayout) row.findViewById(R.id.linear_right);
					RelativeLayout linear_left = (RelativeLayout) row.findViewById(R.id.linear_left);
					volumebar = (SeekBar) row.findViewById(R.id.volumebar);
					// volumebar_arr[i]=volumebar;
					volumebar.setOnTouchListener(new View.OnTouchListener() {
			            @Override
			            public boolean onTouch(View view, MotionEvent motionEvent) {
			               	System.out.println("VOLUMEBAR_Touchlistener"+"Get cht array");
			   	         
			                return true;
			            }
			        });
					ImageView img_chat_right = (ImageView) row.findViewById(R.id.img_chat_right);
					img_chat_right.setTag(0);
					img_chat_right.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							// int pos=(Integer) v.getTag();
							/*WellconnectedConstant.Group_id = "0";

							Intent intent = new Intent(GroupChatActivity.this, UserInfoActivity.class);
							intent.putExtra("Friend_id", Friend_id);
							intent.putExtra("thread_id", crs_id + "");

							WellconnectedConstant.refrence = GroupChatActivity.this;
							startActivityForResult(intent, 0);*/

						}
					});

					ImageView img_chat_left = (ImageView) row.findViewById(R.id.img_chat_left);
					img_chat_left.setTag(0);
					img_chat_left.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							// int pos=(Integer) v.getTag();
							/*WellconnectedConstant.Group_id = "0";

							Intent intent = new Intent(GroupChatActivity.this, UserInfoActivity.class);
							intent.putExtra("Friend_id", Friend_id);
							intent.putExtra("thread_id", crs_id + "");

							WellconnectedConstant.refrence = GroupChatActivity.this;
							startActivityForResult(intent, 0);*/

						}
					});
					Uri uri = Uri.parse(WellconnectedConstant.IMAGE_URL_1 + arr_chat_new.get(0).getImage());
					if (uri != null && uri.toString().length() > 0) {

						Bitmap bitmap = mHttpImageManager.loadImage(new HttpImageManager.LoadRequest(uri, img_chat_right, progressBar));
						if (bitmap != null) {
							img_chat_right.setImageBitmap((bitmap));
						}

						Bitmap bitmap1 = mHttpImageManager.loadImage(new HttpImageManager.LoadRequest(uri, img_chat_left, progressBar));
						if (bitmap1 != null) {
							img_chat_left.setImageBitmap((bitmap1));
						}
					}
					btn_audio_play = (ImageButton) row.findViewById(R.id.btn_audio_play);

					txt_time = (TextView) row.findViewById(R.id.txt_time);
					btn_audio_play.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View arg0) {
							// TODO Auto-generated method stub

							currentBeanObj = (ButtonValueBean) arg0.getTag();

							if (previousBeanObj != null) {

								if (previousBeanObj.isValue()) {

									previousBeanObj.getBtn_audio().setBackgroundResource(R.drawable.play_btn);
									previousBeanObj.setValue(false);
									stopPlaying();

									if (previousBeanObj.getTag() != currentBeanObj.getTag()) {

											previousBeanObj = currentBeanObj;
											previousBeanObj.getBtn_audio().setBackgroundResource(R.drawable.pause_btn);
											previousBeanObj.setValue(true);
											String url = previousBeanObj.getImage_audio_value();
											CurrentvoluBar=previousBeanObj.getVoluBar();
											CurrentvoluBar.setOnTouchListener(new View.OnTouchListener() {
									            @Override
									            public boolean onTouch(View view, MotionEvent motionEvent) {
									                return true;
									            }
									        });

											System.out.println("url" + url);
											new playAsyntask().execute(url);
									}
								} else if (previousBeanObj == null) {

									previousBeanObj = currentBeanObj;
									previousBeanObj.getBtn_audio().setBackgroundResource(R.drawable.pause_btn);
									previousBeanObj.setValue(true);
									String url = previousBeanObj.getImage_audio_value();
									CurrentvoluBar=previousBeanObj.getVoluBar();
									
									CurrentvoluBar.setOnTouchListener(new View.OnTouchListener() {
							            @Override
							            public boolean onTouch(View view, MotionEvent motionEvent) {
							                return true;
							            }
							        });

									System.out.println("url" + url);
									new playAsyntask().execute(url);
								}else if(previousBeanObj.isValue() == false){
									
									previousBeanObj = currentBeanObj;
									previousBeanObj.getBtn_audio().setBackgroundResource(R.drawable.pause_btn);
									previousBeanObj.setValue(true);
									String url = previousBeanObj.getImage_audio_value();
									CurrentvoluBar=previousBeanObj.getVoluBar();
									
									CurrentvoluBar.setOnTouchListener(new View.OnTouchListener() {
							            @Override
							            public boolean onTouch(View view, MotionEvent motionEvent) {
							                return true;
							            }
							        });

									System.out.println("url" + url);
									new playAsyntask().execute(url);
								}
							} else {

								previousBeanObj = currentBeanObj;
								previousBeanObj.getBtn_audio().setBackgroundResource(R.drawable.pause_btn);
								previousBeanObj.setValue(true);
								String url = previousBeanObj.getImage_audio_value();
								System.out.println("url" + url);
								CurrentvoluBar=previousBeanObj.getVoluBar();
								CurrentvoluBar.setOnTouchListener(new View.OnTouchListener() {
						            @Override
						            public boolean onTouch(View view, MotionEvent motionEvent) {
						                return true;
						            }
						        });

								new playAsyntask().execute(url);
							}

							
						}
					});

					TextView txt_chat_username_right = (TextView) row.findViewById(R.id.txt_chat_username_right);
					TextView txt_chat_username_left = (TextView) row.findViewById(R.id.txt_chat_username_left);
										
					TextView txt_date = (TextView) row.findViewById(R.id.txt_date);
					TextView txt_date_left = (TextView) row.findViewById(R.id.txt_date_left);
					
					if (arr_chat_new.get(0).getFriend_id().equals(user_id)) {
						linear_right.setVisibility(View.VISIBLE);
						linear_left.setVisibility(View.INVISIBLE);
						txt_chat_username_right.setText(arr_chat_new.get(i).getUsername());
						txt_date.setText(date_time);
						txt_date.setVisibility(View.VISIBLE);
						txt_date_left.setVisibility(View.GONE);
						
					} else {
						linear_right.setVisibility(View.INVISIBLE);
						linear_left.setVisibility(View.VISIBLE);
						txt_chat_username_left.setText(arr_chat_new.get(i).getUsername());
						
						txt_date_left.setText(date_time);
						txt_date_left.setVisibility(View.VISIBLE);
						txt_date.setVisibility(View.GONE);
					}
					

					MediaPlayer player=new MediaPlayer();
					try {
						player.setDataSource(arr_chat_new.get(0).getAudio_url());
//						player.start();
						player.prepare();
						
					} catch (IllegalArgumentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SecurityException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IllegalStateException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					long totalDuration = player.getDuration();
					
					System.out.println("Print the Total Duration :"+totalDuration);
					float seconds =  (totalDuration / 1000);
				/*	int seconds = (int) (milliseconds / 1000) % 60 ;
					int minutes = (int) ((milliseconds / (1000*60)) % 60);
					int hours   = (int) ((milliseconds / (1000*60*60)) % 24);*/
					System.out.println("SECONDS"+seconds);
					player.stop();
					if(player!=null)
					{
						player=null;
					}
					btnobj.setTag(0);
					btnobj.setBtn_audio(btn_audio_play);
					btnobj.setChat_type("3");
					btnobj.setImage_audio_value(arr_chat_new.get(0).getAudio_url());
					btnobj.setValue(false);
					btnobj.setVoluBar(volumebar);
					arr_btn_value.add(btnobj);
					btn_audio_play.setTag(btnobj);
				}
				datasourse.close();
				if(is_chat_received)
				{
					if(linear_chat_window.findViewById(R.id.ed_focus)!=null)
					{
						System.out.println("EXIST EDITVIEW"+linear_chat_window.getChildCount());
						linear_chat_window.removeViewAt(linear_chat_window.getChildCount()-1);
						linear_chat_window.invalidate();
					}
					else
					{
						System.out.println("NOT EXIST EDITVIEW");
						
					}
					linear_chat_window.addView(row);
					is_chat_received=false;
				}
				else
				{
					linear_chat_window.addView(row, 0);
				}
			
			}
		}
		}
		else
		{
			for (int i = 0; i < arr_chat_new.size(); i++) {
				String date_time = getDateTime(Long.parseLong(arr_chat_new.get(i).getTimestamp()));

				ButtonValueBean btnobj = new ButtonValueBean();

				View row = null;
				if (arr_chat_new.get(i).getChat_type().equals("1")) {
					// message
					if (arr_chat_new.get(i).getStaticc().equals("1")) {
						if(arr_chat_new.get(i).getRequest_status()!=null&&arr_chat_new.get(i).getRequest_status().equals("1")&&!arr_chat_new.get(i).getRequest_status().equals("null"))
						{
						
							final String memberId=arr_chat_new.get(i).getFriend_id();
							final String messageId=arr_chat_new.get(i).getMsgid();
						
							//show join request
							row = View.inflate(GroupChatActivity.this, R.layout.group_join_1_row, null);
							TextView txt_chat_username_left=(TextView) row.findViewById(R.id.txt_chat_username_left);
							txt_chat_username_left.setText(arr_chat_new.get(i).getUsername());
							
							System.out.println("USERNAME"+arr_chat_new.get(i).getUsername());
							
							TextView txt_chat_message_left=(TextView) row.findViewById(R.id.txt_chat_message_left);
							txt_chat_message_left.setText(arr_chat_new.get(i).getMessage());
							
							ProgressBar progress_group_join=(ProgressBar) row.findViewById(R.id.progress_group_join);
							
							ImageView img_chat_left=(ImageView) row.findViewById(R.id.img_chat_left);
							Button btn_accept=(Button) row.findViewById(R.id.btn_accept);
							Button btn_reject=(Button) row.findViewById(R.id.btn_reject);
						
							
							Uri uri = Uri.parse(WellconnectedConstant.IMAGE_URL_1 + arr_chat_new.get(0).getImage());
							if (uri != null && uri.toString().length() > 0) {

								

								Bitmap bitmap1 = mHttpImageManager.loadImage(new HttpImageManager.LoadRequest(uri, img_chat_left, progressBar));
								if (bitmap1 != null) {
									img_chat_left.setImageBitmap((bitmap1));
								}
							}
							btn_accept.setOnClickListener(new OnClickListener() {
								
								@Override
								public void onClick(View arg0) {
									// TODO Auto-generated method stub
									status="2";
									WellconnectedConstant.is_chat_refresh="";
									new OwnerGroupActionAsyntask().execute(Group_id,status,memberId,messageId);
								}
							});
						
							btn_reject.setOnClickListener(new OnClickListener() {
								
								@Override
								public void onClick(View arg0) {
									// TODO Auto-generated method stub
									status="3";
									WellconnectedConstant.is_chat_refresh="";
									new OwnerGroupActionAsyntask().execute(Group_id,status,memberId,messageId);
							
								}
							});
						
							/*Uri uri = Uri.parse(WellconnectedConstant.IMAGE_URL_1 + arr_chat_new.get(i).getImage());

							if (uri != null && uri.toString().length() > 0) {

								
								Bitmap bitmap1 = mHttpImageManager.loadImage(new HttpImageManager.LoadRequest(uri, img_chat_left, txt_chatprogressBar));
								if (bitmap1 != null) {
									img_chat_left.setImageBitmap((bitmap1));
								}
							}*/
						}
						else
						{
							row = View.inflate(GroupChatActivity.this, R.layout.youjoined, null);

							TextView txt_join_msg=(TextView) row.findViewById(R.id.txt_join_msg);
							txt_join_msg.setText(arr_chat_new.get(i).getMessage());
						}
					
					
					} else {

						row = View.inflate(GroupChatActivity.this, R.layout.mesage_row, null);
						RelativeLayout linear_right = (RelativeLayout) row.findViewById(R.id.linear_right);
						RelativeLayout linear_left = (RelativeLayout) row.findViewById(R.id.linear_left);
						ImageView img_chat_right = (ImageView) row.findViewById(R.id.img_chat_right);

						img_chat_right.setTag(i);
						img_chat_right.setOnClickListener(new OnClickListener() {

							@Override
							public void onClick(View arg0) {
								/*// int pos=(Integer) arg0.getTag();
								WellconnectedConstant.Group_id = "0";

								Intent intent = new Intent(GroupChatActivity.this, UserInfoActivity.class);
								intent.putExtra("Friend_id", Friend_id);
								intent.putExtra("thread_id", crs_id + "");

								WellconnectedConstant.refrence = GroupChatActivity.this;
								startActivityForResult(intent, 0);
	*/
							}
						});

						ImageView img_chat_left = (ImageView) row.findViewById(R.id.img_chat_left);
						img_chat_left.setTag(i);
						img_chat_left.setOnClickListener(new OnClickListener() {

							@Override
							public void onClick(View arg0) {
								// TODO Auto-generated method stub
								// int pos=(Integer) arg0.getTag();
							/*	WellconnectedConstant.Group_id = "0";

								Intent intent = new Intent(GroupChatActivity.this, UserInfoActivity.class);
								intent.putExtra("Friend_id", Friend_id);
								intent.putExtra("thread_id", crs_id + "");

								WellconnectedConstant.refrence = GroupChatActivity.this;
								startActivityForResult(intent, 0);*/

							}
						});

						TextView txt_chat_username_right = (TextView) row.findViewById(R.id.txt_chat_username_right);
						
						TextView txt_chat_message_right = (TextView) row.findViewById(R.id.txt_chat_message_right);
						
						TextView txt_chat_username_left = (TextView) row.findViewById(R.id.txt_chat_username_left);
						
						TextView txt_chat_message_left = (TextView) row.findViewById(R.id.txt_chat_message_left);
						
						
						TextView txt_date = (TextView) row.findViewById(R.id.txt_date);
						TextView txt_date_left = (TextView) row.findViewById(R.id.txt_date_left);

						ProgressBar txt_chatprogressBar = (ProgressBar) row.findViewById(R.id.txt_chatprogressBar);

						Uri uri = Uri.parse(WellconnectedConstant.IMAGE_URL_1 + arr_chat_new.get(i).getImage());

						if (uri != null && uri.toString().length() > 0) {

							Bitmap bitmap = mHttpImageManager.loadImage(new HttpImageManager.LoadRequest(uri, img_chat_right, txt_chatprogressBar));
							if (bitmap != null) {

								img_chat_right.setImageBitmap((bitmap));
							}

							Bitmap bitmap1 = mHttpImageManager.loadImage(new HttpImageManager.LoadRequest(uri, img_chat_left, txt_chatprogressBar));
							if (bitmap1 != null) {
								img_chat_left.setImageBitmap((bitmap1));
							}
						}

						try {
							if(arr_chat_new.get(i).getMessage()!=null)
							{
								try {
									byte[] data = Base64.decode(arr_chat_new.get(i).getMessage(), Base64.DEFAULT);
									text = new String(data, "UTF-8");
									
									btnobj.setImage_audio_value(text);

								} catch (IllegalArgumentException e) {
									// TODO: handle exception
								}
							
							}
							
						} catch (UnsupportedEncodingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						if (arr_chat_new.get(i).getFriend_id().equals(user_id)) {
							linear_right.setVisibility(View.VISIBLE);
							linear_left.setVisibility(View.INVISIBLE);
							txt_chat_username_right.setText("Me");
							txt_chat_message_right.setText(text);
							txt_date_left.setVisibility(View.GONE);
							txt_date.setVisibility(View.VISIBLE);
							txt_date.setText(date_time);
						} else {
							linear_right.setVisibility(View.INVISIBLE);
							linear_left.setVisibility(View.VISIBLE);
							txt_chat_message_left.setText(text);
							txt_chat_username_left.setText(arr_chat_new.get(i).getUsername());
							txt_date_left.setVisibility(View.VISIBLE);
							txt_date.setVisibility(View.GONE);
							txt_date_left.setText(date_time);
						}
						System.out.println("MESSAGE_ID" + arr_chat_new.get(i).getMsgid());

						btnobj.setBtn_audio(null);
						btnobj.setChat_type("1");
						btnobj.setTag(i);
						btnobj.setValue(false);
						btnobj.setVoluBar(null);
						arr_btn_value.add(btnobj);
					}
				} else if (arr_chat_new.get(i).getChat_type().equals("2")) {
					// image
					row = View.inflate(GroupChatActivity.this, R.layout.chat_image_row, null);
					
					LinearLayout linear_right = (LinearLayout) row.findViewById(R.id.linear_right);
					LinearLayout linear_left = (LinearLayout) row.findViewById(R.id.linear_left);

					ImageView img_chat_right = (ImageView) row.findViewById(R.id.img_chat_right);

					img_chat_right.setTag(i);
					img_chat_right.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View arg0) {
							// TODO Auto-generated method stub
							// /int pos=(Integer) arg0.getTag();
						/*	WellconnectedConstant.Group_id = "0";

							Intent intent = new Intent(GroupChatActivity.this, UserInfoActivity.class);
							intent.putExtra("Friend_id", Friend_id);
							intent.putExtra("thread_id", crs_id + "");

							WellconnectedConstant.refrence = GroupChatActivity.this;
							startActivityForResult(intent, 0);
	*/
						}
					});
					ImageView img_chat_left = (ImageView) row.findViewById(R.id.img_chat_left);
					img_chat_left.setTag(i);
					img_chat_left.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View arg0) {
							// TODO Auto-generated method stub
							// int pos=(Integer) arg0.getTag();
							/*WellconnectedConstant.Group_id = "0";

							Intent intent = new Intent(GroupChatActivity.this, UserInfoActivity.class);
							intent.putExtra("Friend_id", Friend_id);
							intent.putExtra("thread_id", crs_id + "");

							WellconnectedConstant.refrence = GroupChatActivity.this;
							startActivityForResult(intent, 0);*/

						}
					});

					ProgressBar progress_img = (ProgressBar) row.findViewById(R.id.progress_img);

					Uri uri = Uri.parse(WellconnectedConstant.IMAGE_URL_1 + arr_chat_new.get(i).getImage());

					if (uri != null && uri.toString().length() > 0) {

						Bitmap bitmap = mHttpImageManager.loadImage(new HttpImageManager.LoadRequest(uri, img_chat_right, progressBar));
						if (bitmap != null) {

							img_chat_right.setImageBitmap((bitmap));
						}

						Bitmap bitmap1 = mHttpImageManager.loadImage(new HttpImageManager.LoadRequest(uri, img_chat_left, progressBar));
						if (bitmap1 != null) {
							img_chat_left.setImageBitmap((bitmap1));
						}
					}
					TextView txt_chat_username_left = (TextView) row.findViewById(R.id.txt_chat_username_left);
					TextView txt_chat_username_right = (TextView) row.findViewById(R.id.txt_chat_username_right);
					ImageView chat_image_left = (ImageView) row.findViewById(R.id.chat_image_left);
					ImageView chat_image_right = (ImageView) row.findViewById(R.id.chat_image_right);
					
					
					chat_image_left.setTag(i);
					chat_image_left.setOnClickListener(new OnClickListener() {
						
						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							int pos=(Integer) v.getTag();
							System.out.println("CHAT IMAGE CLICK");
							
							Intent intent=new Intent(GroupChatActivity.this,GalleryView.class);
							intent.putExtra("IMAGE",arr_chat_new.get(pos).getImage_url());
							
							WellconnectedConstant.arr_chat_new=arr_chat_new;
							startActivity(intent);
						}
					});
					
					chat_image_right.setTag(i);
					chat_image_right.setOnClickListener(new OnClickListener() {
						
						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							int pos=(Integer) v.getTag();
							System.out.println("CHAT IMAGE CLICK");
							
							Intent intent=new Intent(GroupChatActivity.this,GalleryView.class);
							intent.putExtra("IMAGE",arr_chat_new.get(pos).getImage_url());
							
							WellconnectedConstant.arr_chat_new=arr_chat_new;
							startActivity(intent);
						}
					});
					System.out.println("CHAT IMAGE" + WellconnectedConstant.IMAGE_URL_5 + arr_chat_new.get(i).getImage_url());

					Uri uri1 = Uri.parse(arr_chat_new.get(i).getImage_url());

					// Uri uri1 =
					// Uri.parse(WellconnectedConstant.IMAGE_URL_5+arr_chat_new.get(i).getImage_url());

					if (uri1 != null && uri1.toString().length() > 0) {

						File image = new File(arr_chat_new.get(i).getImage_url());

						FileInputStream in = new FileInputStream(image);

						BitmapFactory.Options options = new BitmapFactory.Options();
						options.inSampleSize = 4;
						bitmap = BitmapFactory.decodeStream(in, null, options);

						// Bitmap bitmap = mHttpImageManager.loadImage(new
						// HttpImageManager.LoadRequest(uri1, chat_image,
						// progressBar));
						System.out.println("CHAT-BITMAP"+bitmap);
						if (bitmap != null) {
							chat_image_left.setImageBitmap((bitmap));
							chat_image_right.setImageBitmap((bitmap));
						}
					}
					TextView txt_date = (TextView) row.findViewById(R.id.txt_date);
					TextView txt_date_left = (TextView) row.findViewById(R.id.txt_date_left);
					
				
					if (arr_chat_new.get(i).getFriend_id().equals(user_id)) {
						linear_right.setVisibility(View.VISIBLE);
						linear_left.setVisibility(View.INVISIBLE);
						txt_chat_username_right.setText("Me");
						txt_date.setText(date_time);
						txt_date_left.setVisibility(View.GONE);
						txt_date.setVisibility(View.VISIBLE);

					} else {
						linear_right.setVisibility(View.INVISIBLE);
						linear_left.setVisibility(View.VISIBLE);
						txt_chat_username_left.setText(arr_chat_new.get(i).getUsername());
						txt_date_left.setText(date_time);
						txt_date_left.setVisibility(View.VISIBLE);
						txt_date.setVisibility(View.GONE);

					}
					btnobj.setTag(i);
					btnobj.setBtn_audio(null);
					btnobj.setChat_type("2");
					btnobj.setImage_audio_value(/*
												 * WellconnectedConstant.IMAGE_URL_5+
												 */arr_chat_new.get(i).getImage_url());
					btnobj.setValue(false);
					btnobj.setVoluBar(null);
					arr_btn_value.add(btnobj);
				} else {
					row = View.inflate(GroupChatActivity.this, R.layout.audio_row, null);
					RelativeLayout linear_right = (RelativeLayout) row.findViewById(R.id.linear_right);
					RelativeLayout linear_left = (RelativeLayout) row.findViewById(R.id.linear_left);
					
					TextView txt_chat_username_left = (TextView) row.findViewById(R.id.txt_chat_username_left);
					TextView txt_chat_username_right = (TextView) row.findViewById(R.id.txt_chat_username_right);
			
					volumebar = (SeekBar) row.findViewById(R.id.volumebar);
					// volumebar_arr[i]=volumebar;
					volumebar.setOnTouchListener(new View.OnTouchListener() {
			            @Override
			            public boolean onTouch(View view, MotionEvent motionEvent) {
			               	System.out.println("VOLUMEBAR_Touchlistener");
			   	         
			                return true;
			            }
			        });
					ImageView img_chat_right = (ImageView) row.findViewById(R.id.img_chat_right);
					img_chat_right.setTag(i);
					img_chat_right.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							// int pos=(Integer) v.getTag();
							/*WellconnectedConstant.Group_id = "0";

							Intent intent = new Intent(GroupChatActivity.this, UserInfoActivity.class);
							intent.putExtra("Friend_id", Friend_id);
							intent.putExtra("thread_id", crs_id + "");

							WellconnectedConstant.refrence = GroupChatActivity.this;
							startActivityForResult(intent, 0);*/

						}
					});

					ImageView img_chat_left = (ImageView) row.findViewById(R.id.img_chat_left);
					img_chat_left.setTag(i);
					img_chat_left.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							// int pos=(Integer) v.getTag();
							/*WellconnectedConstant.Group_id = "0";

							Intent intent = new Intent(GroupChatActivity.this, UserInfoActivity.class);
							intent.putExtra("Friend_id", Friend_id);
							intent.putExtra("thread_id", crs_id + "");

							WellconnectedConstant.refrence = GroupChatActivity.this;
							startActivityForResult(intent, 0);*/

						}
					});
					Uri uri = Uri.parse(WellconnectedConstant.IMAGE_URL_1 + arr_chat_new.get(i).getImage());
					if (uri != null && uri.toString().length() > 0) {

						Bitmap bitmap = mHttpImageManager.loadImage(new HttpImageManager.LoadRequest(uri, img_chat_right, progressBar));
						if (bitmap != null) {
							img_chat_right.setImageBitmap((bitmap));
						}

						Bitmap bitmap1 = mHttpImageManager.loadImage(new HttpImageManager.LoadRequest(uri, img_chat_left, progressBar));
						if (bitmap1 != null) {
							img_chat_left.setImageBitmap((bitmap1));
						}
					}
					btn_audio_play = (ImageButton) row.findViewById(R.id.btn_audio_play);

					txt_time = (TextView) row.findViewById(R.id.txt_time);
					btn_audio_play.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View arg0) {
							// TODO Auto-generated method stub

							currentBeanObj = (ButtonValueBean) arg0.getTag();

							if (previousBeanObj != null) {

								if (previousBeanObj.isValue()) {

									previousBeanObj.getBtn_audio().setBackgroundResource(R.drawable.play_btn);
									previousBeanObj.setValue(false);
									stopPlaying();

									if (previousBeanObj.getTag() != currentBeanObj.getTag()) {

											previousBeanObj = currentBeanObj;
											previousBeanObj.getBtn_audio().setBackgroundResource(R.drawable.pause_btn);
											previousBeanObj.setValue(true);
											String url = previousBeanObj.getImage_audio_value();
											CurrentvoluBar=previousBeanObj.getVoluBar();
											
											CurrentvoluBar.setOnTouchListener(new View.OnTouchListener() {
									            @Override
									            public boolean onTouch(View view, MotionEvent motionEvent) {
									                return true;
									            }
									        });

											System.out.println("url" + url);
											new playAsyntask().execute(url);
									}
								} else if (previousBeanObj == null) {

									previousBeanObj = currentBeanObj;
									previousBeanObj.getBtn_audio().setBackgroundResource(R.drawable.pause_btn);
									previousBeanObj.setValue(true);
									String url = previousBeanObj.getImage_audio_value();
									CurrentvoluBar=previousBeanObj.getVoluBar();
									CurrentvoluBar.setOnTouchListener(new View.OnTouchListener() {
							            @Override
							            public boolean onTouch(View view, MotionEvent motionEvent) {
							                return true;
							            }
							        });

									System.out.println("url" + url);
									new playAsyntask().execute(url);
								}else if(previousBeanObj.isValue() == false){
									
									previousBeanObj = currentBeanObj;
									previousBeanObj.getBtn_audio().setBackgroundResource(R.drawable.pause_btn);
									previousBeanObj.setValue(true);
									String url = previousBeanObj.getImage_audio_value();
									CurrentvoluBar=previousBeanObj.getVoluBar();
									CurrentvoluBar.setOnTouchListener(new View.OnTouchListener() {
							            @Override
							            public boolean onTouch(View view, MotionEvent motionEvent) {
							                return true;
							            }
							        });

									System.out.println("url" + url);
									new playAsyntask().execute(url);
								}
							} else {

								previousBeanObj = currentBeanObj;
								previousBeanObj.getBtn_audio().setBackgroundResource(R.drawable.pause_btn);
								previousBeanObj.setValue(true);
								String url = previousBeanObj.getImage_audio_value();
								System.out.println("url" + url);
								CurrentvoluBar=previousBeanObj.getVoluBar();
								
								CurrentvoluBar.setOnTouchListener(new View.OnTouchListener() {
						            @Override
						            public boolean onTouch(View view, MotionEvent motionEvent) {
						                return true;
						            }
						        });

								new playAsyntask().execute(url);
							}

							
						}
					});
					TextView txt_date = (TextView) row.findViewById(R.id.txt_date);
					TextView txt_date_left = (TextView) row.findViewById(R.id.txt_date_left);
					TextView txt_time_right = (TextView) row.findViewById(R.id.txt_time_right);
					TextView txt_time_left = (TextView) row.findViewById(R.id.txt_time_left);
					
				
					if (arr_chat_new.get(i).getFriend_id().equals(user_id)) {
						linear_right.setVisibility(View.VISIBLE);
						linear_left.setVisibility(View.INVISIBLE);
						txt_chat_username_right.setText("Me");
						txt_date.setText(date_time);
						txt_date_left.setVisibility(View.GONE);
						txt_date.setVisibility(View.VISIBLE);
					} else {
						linear_right.setVisibility(View.INVISIBLE);
						linear_left.setVisibility(View.VISIBLE);
						txt_chat_username_left.setText(arr_chat_new.get(i).getUsername());
						txt_date_left.setText(date_time);
						txt_date_left.setVisibility(View.VISIBLE);
						txt_date.setVisibility(View.GONE);
					}

					MediaPlayer player=new MediaPlayer();
					try {
						player.setDataSource(arr_chat_new.get(i).getAudio_url());
//						player.start();
						player.prepare();
						
					} catch (IllegalArgumentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SecurityException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IllegalStateException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					long totalDuration = player.getDuration();
					
					System.out.println("Print the Total Duration :"+totalDuration);
					float seconds =  (totalDuration / 1000);
				/*	int seconds = (int) (milliseconds / 1000) % 60 ;
					int minutes = (int) ((milliseconds / (1000*60)) % 60);
					int hours   = (int) ((milliseconds / (1000*60*60)) % 24);*/
					System.out.println("SECONDS"+seconds);
					
					txt_time_left.setText(String.valueOf(seconds)+" "+"sec");
					txt_time_right.setText(String.valueOf(seconds)+" "+"sec");
					
					player.stop();
					if(player!=null)
					{
						player=null;
					}
					btnobj.setTag(i);
					btnobj.setBtn_audio(btn_audio_play);
					btnobj.setChat_type("3");
					btnobj.setImage_audio_value(arr_chat_new.get(i).getAudio_url());
					btnobj.setValue(false);
					btnobj.setVoluBar(volumebar);
					arr_btn_value.add(btnobj);
					btn_audio_play.setTag(btnobj);
				}
				datasourse.close();
				if(is_chat_received)
				{
					if(linear_chat_window.findViewById(R.id.ed_focus)!=null)
					{
						System.out.println("EXIST EDITVIEW"+linear_chat_window.getChildCount());
						linear_chat_window.removeViewAt(linear_chat_window.getChildCount()-1);
						linear_chat_window.invalidate();
					}
					else
					{
						System.out.println("NOT EXIST EDITVIEW");
						
					}
					linear_chat_window.addView(row);
					is_chat_received=false;
				}
				else
				{
					System.out.println("is_chat_received"+is_chat_received);
					linear_chat_window.addView(row, 0);
				}
			
			}
		}

		int_chat_window_size = arr_chat_new.size();

		if (!is_pagging) {
			edit_view = View.inflate(GroupChatActivity.this, R.layout.edit_view, null);
			ed_focus = (EditText) edit_view.findViewById(R.id.ed_focus);
			
			linear_chat_window.addView(edit_view);

			new Handler().post(new Runnable() {
				@Override
				public void run() {
					scroll.scrollTo(0, ed_focus.getBottom());
				}
			});
			ed_focus.requestFocus();
			// ed_focus.setVisibility(View.INVISIBLE);
			ed_focus.setEnabled(false);
		} else {
			is_pagging = false;

			new Handler().post(new Runnable() {
				@Override
				public void run() {
					if (edit_view != null)
						System.out.println("scroll_position" + scroll_position);
					scroll.scrollTo(0, scroll_position);
				}
			});
			ed_focus.requestFocus();
			ed_focus.setEnabled(true);
		}
	}

	private String getDateTime(long timestamp) {
		try {
			Calendar calendar = Calendar.getInstance();
			TimeZone tz = TimeZone.getDefault();
			calendar.setTimeInMillis(timestamp * 1000);
			calendar.add(Calendar.MILLISECOND, tz.getOffset(calendar.getTimeInMillis()));
		//	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm a");
			SimpleDateFormat sdf = new SimpleDateFormat("yy/MM/dd hh:mm a");
			Date currenTimeZone = (Date) calendar.getTime();
			return sdf.format(currenTimeZone);
		} catch (Exception e) {
		}
		return "";
	}

	private Handler mHandler = new Handler();
	private Runnable mRunnable = new Runnable() {

		@Override
		public void run() {
			if (mediaplayer != null) {
				final int mCurrentPosition = mediaplayer.getCurrentPosition() / 1000;
				// volumebar_arr[possition].setProgress(mCurrentPosition);
			}
			mHandler.postDelayed(this, 1000);
		}
	};

	class playAsyntask extends AsyncTask<String, Integer, String> {

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			playaudiourl(params[0]);

			return null;
		}

	}

	/** play audio url **/
	private void playaudiourl(String url) {
		// TODO Auto-generated method stub

		System.out.println("URL" + url);
		String Static_url = url.substring(0, url.lastIndexOf("/") + 1);
		String URLLL = Static_url + "TEST.3gpp";

		System.out.println("URLLL" + URLLL);

		System.out.println("PLAYYYY");

		
		mediaplayer = new MediaPlayer();
		mediaplayer.setOnCompletionListener(new OnCompletionListener() {
			
			public void onCompletion(MediaPlayer arg0) {
				// TODO Auto-generated method stub
			//	CurrentvoluBar.setProgress(0);
				
			}
		});

		if (!isPLAYING) {
			isPLAYING = true;

			try {
				mediaplayer.setDataSource(/* "http://www.pro90dmobilespeechtrainer.com/uploads/libraries/audios/HowtoStopStuttering_GetStartedEasierTraining-Clip10.mp3" *//*URLLL*/url);
				mediaplayer.prepare();
				mediaplayer.start();
				System.out.println("Duration" + mediaplayer.getDuration());
				// String duration=String.valueOf((float)mp.getDuration()/1000);

				// txt_time.setText(duration);

				// volumebar.setMax(mp.getDuration());

				// mRunnable.run();
				updateProgressBar();

			} catch (IOException e) {
				// Log.e(LOG_TAG, "prepare() failed");
			}
		} else {
			isPLAYING = false;
			stopPlaying();
		}
	}

	private void stopPlaying() {
		System.out.println("STOPP");
		isPLAYING = false;
		CurrentvoluBar.setProgress(0);
		mHandler.removeCallbacks(mUpdateTimeTask);
		// volumebar_arr[pos].setProgress(0);
		if (mediaplayer != null) {
			mediaplayer.stop();
			mediaplayer.reset();
			mediaplayer = null;
		}

	}

	/**
	 * Update timer on seekbar
	 * */
	public void updateProgressBar() {
		mHandler.postDelayed(mUpdateTimeTask, 100);
	}

	/**
	 * Background Runnable thread
	 * */
	private Runnable mUpdateTimeTask = new Runnable() {
		public void run() {
			if (mediaplayer != null) {
				int totalDuration = mediaplayer.getDuration();

				 System.out.println("TOTAL_time_duration"+totalDuration);
				int currentDuration = mediaplayer.getCurrentPosition();

				// System.out.println("currentDuration"+currentDuration);
				CurrentvoluBar.setMax(totalDuration);

				
				int progress = (int) (getProgressPercentage(currentDuration, totalDuration));
				//Log.d("Progress", ""+progress);
				CurrentvoluBar.setProgress(/*progress*/currentDuration);

				// Running this thread after 100 milliseconds
				mHandler.postDelayed(this, 100);
			} else {
				CurrentvoluBar.setProgress(0);
			}

		}
	};

	public int getProgressPercentage(long currentDuration, long totalDuration) {
		Double percentage = (double) 0;

		long currentSeconds = (int) (currentDuration / 1000);
		long totalSeconds = (int) (totalDuration / 1000);

		// calculating percentage
		percentage = (((double) currentSeconds) / totalSeconds) * 100;

		// return percentage
		return percentage.intValue();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (resultCode == Activity.RESULT_OK) {
			if (requestCode == 1) {
				try {
					Uri selectedimage = data.getData();
					String[] filepathcolumn = { MediaStore.Images.Media.DATA };

					Cursor cursor = getContentResolver().query(selectedimage, filepathcolumn, null, null, null);
					cursor.moveToFirst();

					int columnindex = cursor.getColumnIndex(filepathcolumn[0]);
					imageFilePath = cursor.getString(columnindex);
					imageType = imageFilePath.substring(imageFilePath.lastIndexOf(".") + 1);
					cursor.close();
					FileInputStream in;
					try {
						in = new FileInputStream(imageFilePath);

						BitmapFactory.Options options = new BitmapFactory.Options();
						options.inSampleSize = 4;
						bitmap = BitmapFactory.decodeStream(in, null, options);

						type = "2";// for image

						unixTime = System.currentTimeMillis() / 1000L;
						System.out.println("unixTime" + unixTime);

						ChatDetailGroupBean bean = new ChatDetailGroupBean();
						bean.setAudio_url("");
						bean.setChat_type(type);// for text
						bean.setDate(String.valueOf(unixTime));
						bean.setFriend_id(user_id);
						bean.setImage(user_image);
						bean.setImage_url("");
						bean.setImage_url(imageFilePath);
						bean.setMsg_byte(null);
						bean.setMsgid("");
						bean.setStaticc("");
						bean.setThread_id(thread_id);
						bean.setTimestamp(String.valueOf(unixTime));
						bean.setType("sender");
						bean.setUsername(user_name);
						arr_chat.add(bean);
						arr_chat_new.add(bean);
						if (edit_view != null) {
							linear_chat_window.removeView(edit_view);

						}

						// Download_single_file(WellconnectedConstant.IMAGE_URL_5+message,message);

						AddoneView(type, user_image, "", user_name, "", user_id, String.valueOf(unixTime), bitmap,0);

						if (WellconnectedUtills.isNetworkAvailable(GroupChatActivity.this)) {

							new SendChatDataFileTask().execute("", type, "");

						} else {
							WellconnectedUtills.customDialog(GroupChatActivity.this, "Internet connection is not available");

						}

						// img_user_pic.setImageBitmap(bitmap);
						// img_pic.setImageBitmap(WellconnectedUtills.getRoundedShape(bitmap));
					} catch (Exception e) {
						Log.e("Error reading file", e.toString());

						if (e instanceof FileNotFoundException) {
							Toast.makeText(GroupChatActivity.this, "Network Synchronized Image Does Not Exists", Toast.LENGTH_SHORT).show();
						}
					}
				} catch (Exception e) {
					e.printStackTrace();

					if (e instanceof FileNotFoundException) {
						Toast.makeText(GroupChatActivity.this, "Network Synchronized Image Does Not Exists", Toast.LENGTH_SHORT).show();
					}
				}
			} else if (requestCode == 2) {
				File Imagedirectory = new File(Environment.getExternalStorageDirectory() + "/MyImage");
				if (!Imagedirectory.exists()) {
					Imagedirectory.mkdir();
				}

				int quality = 5;
				String ssss = UUID.randomUUID().toString();
				File file = new File(Imagedirectory.getPath() + "/" + ssss + ".png");

				imageFilePath = file.getPath();
				imageType = "png";
				try {
					if (data.getExtras() != null) {
						bitmap = (Bitmap) data.getExtras().get("data");
						try {
							file.createNewFile();
							FileOutputStream fileOutputStream = new FileOutputStream(file);
							BufferedOutputStream bos = new BufferedOutputStream(fileOutputStream);
							bitmap.compress(CompressFormat.PNG, quality, bos);

							type = "2";// for message

							unixTime = System.currentTimeMillis() / 1000L;
							System.out.println("unixTime" + unixTime);

							ChatDetailGroupBean bean = new ChatDetailGroupBean();
							bean.setAudio_url("");
							bean.setChat_type(type);// for text
							bean.setDate(String.valueOf(unixTime));
							bean.setFriend_id(user_id);
							bean.setImage(user_image);
							bean.setImage_url(imageFilePath);
							bean.setMessage("");
							bean.setMsg_byte(null);
							bean.setMsgid("");
							bean.setStaticc("");
							bean.setThread_id(thread_id);
							bean.setTimestamp(String.valueOf(unixTime));
							bean.setType("sender");
							bean.setUsername(user_name);
							arr_chat.add(bean);
							arr_chat_new.add(bean);
							if (edit_view != null) {
								linear_chat_window.removeView(edit_view);

							}
							AddoneView(type, user_image, "", user_name, "", user_id, String.valueOf(unixTime), bitmap,0);

							if (WellconnectedUtills.isNetworkAvailable(GroupChatActivity.this)) {

								new SendChatDataFileTask().execute("", type, "");

							} else {
								WellconnectedUtills.customDialog(GroupChatActivity.this, "Internet connection is not available");

							}
							// img_user_pic.setImageBitmap(bitmap);
							// img_pic.setImageBitmap(WellconnectedUtills.getRoundedShape(bitmap));
							bos.flush();
							bos.close();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else if (resultCode == 10001) {
				System.out.println("finish");

				finish();
			}
		}
	}

	public void image_audio_aniation() {
		animation = new AnimationDrawable();
		animation.addFrame(getResources().getDrawable(R.drawable.img_1), 100);
		animation.addFrame(getResources().getDrawable(R.drawable.img_2), 100);
		animation.addFrame(getResources().getDrawable(R.drawable.img_3), 100);
		animation.addFrame(getResources().getDrawable(R.drawable.img_4), 100);
		animation.addFrame(getResources().getDrawable(R.drawable.img_5), 100);
		animation.addFrame(getResources().getDrawable(R.drawable.img_6), 100);
		animation.addFrame(getResources().getDrawable(R.drawable.img_7), 100);
		animation.addFrame(getResources().getDrawable(R.drawable.img_8), 100);

		animation.setOneShot(false);

		img_audio.setBackgroundDrawable(animation);
		// In OnCreate or button_click event you can fire animation
		animation.start();
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();

		mHandler.removeCallbacks(mRunnable);
		if (mediaplayer != null) {
			mediaplayer.stop();
			mediaplayer = null;

		}
		System.out.println("BACK PRESSED");
	}


	@Override
	public void onScrollChanged(ScrollViewExt scrollView, int x, int y, int oldx, int oldy) {
		/*
		 * System.out.println("scrollView"+scrollView);
		 * System.out.println("x"+x); System.out.println("y"+y);
		 * System.out.println("oldx"+oldx); System.out.println("oldy"+oldy);
		 */
		if (x == 0 && y == 0 && is_pagging == false) {
			// first recoarddddddddddm,
			if (Integer.parseInt(count) > 20) {
				// loadiinggg
				datasourse.close();
				page = page + 1;
				firstLimit = (page - 1) * 20;
				if (firstLimit <= Integer.parseInt(count)) {
					is_pagging = true;
					if (edit_view != null) {
						int child = linear_chat_window.getChildCount();
						System.out.println("child" + child);

						float pooos = linear_chat_window.getChildAt(child - 1).getScaleY();
						System.out.println("pooos" + pooos);

						scroll_count = scroll_count + 1;
						scroll_position = (int) linear_chat_window.getChildAt(child - 1).getY()/**
						 * 
						 * scroll_count
						 */
						;

						linear_chat_window.removeView(edit_view);

					}
					/*
					 * edit_view=View.inflate(GroupChatActivity.this,
					 * R.layout.edit_view, null); ed_focus=(EditText)
					 * edit_view.findViewById(R.id.ed_focus);
					 * ed_focus.setVisibility(View.VISIBLE);
					 * ed_focus.setText("dsfffffffff");
					 * linear_chat_window.addView(edit_view,0);
					 * ed_focus.requestFocus(); ed_focus.setEnabled(true);
					 */

					new ProgressTask().execute();
				} else {
					// no more data to show
				}
			} else {

				// no pagginggggg
			}
		}

	}
}
