package com.view.wellconnected;

import com.wellconnected.parse.WellconnectedParse;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

public class GroupAsynTask extends AsyncTask<String, Integer, String>{
	public ProgressDialog progressDialog;
	public Context context;
	public String response;
	public AsynTaskListener callBack;
	
	public GroupAsynTask(Context context)
	{
		this.context=context;
		this.callBack = (AsynTaskListener)context;
	}
	@Override
	
	protected void onPreExecute() {
		super.onPreExecute();
		progressDialog = ProgressDialog.show(context, "", "Please Wait");
		
	}
	
	@Override
	protected String doInBackground(String... params) {
		response = WellconnectedParse.groupInfo(context, params[0], params[1]);

		return null;
	}
	@Override
	protected void onPostExecute(String result) {
		super.onPostExecute(result);
		progressDialog.dismiss();
		
		if(!response.equals(""))
		{
			callBack.onTaskComplete(response);
		}
	}



}
