package com.view.wellconnected;

import java.util.ArrayList;

import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.wellconnected.bean.ChatDetailBean.ChatDetail;
import com.wellconnected.bean.ChatGroupBase;
import com.wellconnected.lazyload.ImageLoader_rounded;
import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

public class ChatActivity extends Activity{
	private String user_id,search_name;
	private ArrayList<ChatGroupBase>arr;
	private ArrayList<ChatDetail>arrDetail;
	private ListView list_chat;
	private ImageLoader_rounded imgLoader;
	private ImageView img_menu;
	private EditText ed_search;
	private LinearLayout ll_search;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.chat);
		arr=new ArrayList<ChatGroupBase>();
		WellconnectedConstant.ScreenName="";
		search_name="";
		
		ed_search=(EditText) findViewById(R.id.ed_search);
		ed_search.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub

				if(s.toString().equals(""))
				{
					search_name="";
					
					
					new ChatTask().execute();

				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				
			}
		});
		
		
		list_chat=(ListView) findViewById(R.id.list_chat);
	
				
		
		SharedPreferences	pref = this.getSharedPreferences("LoginInfo", this.MODE_WORLD_READABLE);
		
		user_id=pref.getString("User_id", "");
		
		if (WellconnectedUtills.isNetworkAvailable(ChatActivity.this)) {
			new ChatTask().execute();

		} else {
			WellconnectedUtills.customDialog(ChatActivity.this, "Internet connection is not available");

		}
		imgLoader=new ImageLoader_rounded(ChatActivity.this);
		
		
		img_menu=(ImageView) findViewById(R.id.img_menu);
		img_menu.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
/*				// TODO Auto-generated method stub
	int width = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 40, getResources().getDisplayMetrics());
				
				SlideoutActivity.prepare(ChatActivity.this, R.id.rlmain, width);
				startActivity(new Intent(ChatActivity.this,MenuActivity.class));
				overridePendingTransition(0, 0);
	*/		
			}
		});
		
		ll_search=(LinearLayout) findViewById(R.id.ll_search);
		ll_search.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				search_name=ed_search.getText().toString();
			
				new ChatTask().execute();
			}
		});
	}
	class ViewHolder
	{
		ImageView img_chat_image,img_online;
		TextView txt_group_name,txt_date,txt_friend_name;
		LinearLayout linear_images;
		ImageButton btn_logo;
	}
	class ChatAdapter extends BaseAdapter
	{

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return arrDetail.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			
			ViewHolder viewHolder=null;
			if(convertView==null)
			{
				LayoutInflater inflater=ChatActivity.this.getLayoutInflater();
				convertView=inflater.inflate(R.layout.chat_row, null);
				  viewHolder = new ViewHolder();
				  viewHolder.img_chat_image=(ImageView)convertView.findViewById(R.id.img_chat_image);
				  viewHolder.txt_friend_name=(TextView) convertView.findViewById(R.id.txt_friend_name);
				  viewHolder.txt_date=(TextView) convertView.findViewById(R.id.txt_date);

				  viewHolder.img_online=(ImageView) convertView.findViewById(R.id.img_online);
				  viewHolder.btn_logo=(ImageButton) convertView.findViewById(R.id.btn_logo);
				  
				  
				 convertView.setTag(viewHolder);
			}
			else
			{
				viewHolder = (ViewHolder)convertView.getTag();
				
			}
			viewHolder.btn_logo.setTag(position);
			
			
			if(arrDetail.get(position).getFriend_image()!=null)
			{
				
				System.out.println("URL"+arrDetail.get(position).getFriend_image());
				
				imgLoader.DisplayImage(WellconnectedConstant.IMAGE_URL_4+arrDetail.get(position).getFriend_image(),  viewHolder.img_chat_image);
				
			}
			else
			{
				

				System.out.println("URL"+arrDetail.get(position).getGroupImage());
				
				imgLoader.DisplayImage(WellconnectedConstant.IMAGE_URL_4+arrDetail.get(position).getGroupImage(),  viewHolder.img_chat_image);
				
			}
				
		if(arrDetail.get(position).getChattype().equals("1"))
		{
			viewHolder.btn_logo.setBackgroundResource(R.drawable.msg_icon);
			
		}
		else if(arrDetail.get(position).getChattype().equals("2"))
		{
			viewHolder.btn_logo.setBackgroundResource(R.drawable.play_btn);
			
		}	else if(arrDetail.get(position).getChattype().equals("3"))
		{
			viewHolder.btn_logo.setBackgroundResource(R.drawable.photo_icon);
			
		}
		if(arrDetail.get(position).getFriend_name()!=null)
		{
			viewHolder.txt_friend_name.setText(arrDetail.get(position).getFriend_name().trim());

		}
		else
		{
			viewHolder.txt_friend_name.setText(arrDetail.get(position).getGroupName().trim());

		}
		
		viewHolder.txt_date.setText(arrDetail.get(position).getCreated());
			return convertView;
		}
		
		
	}
	public class ChatTask extends AsyncTask<String, Integer, String> {
		ProgressDialog progressDialog;
		JSONObject obj;
		ChatGroupBase chatbase;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(ChatActivity.this, "", "Please Wait");

		}

		@Override
		protected String doInBackground(String... params) {

			// TODO Auto-generated method stub

			chatbase = WellconnectedParse.getChat(ChatActivity.this, user_id, search_name);

			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}

			if (chatbase != null) {
				if (chatbase.getResponse()==null) {
					//WellconnectedUtills.customDialog(ChatActivity.this, chatbase.getResponse().getError());

				} else {
					
					arrDetail=new ArrayList<ChatDetail>();
					
					arrDetail=chatbase.getResponse().getChatDetail();
					
					System.out.println("arrDetail"+arrDetail.size());
					
					list_chat.setAdapter(new ChatAdapter()); 
				}
			}

		}
	}
}
