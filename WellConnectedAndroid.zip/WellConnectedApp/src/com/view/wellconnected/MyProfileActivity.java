package com.view.wellconnected;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gcm.GCMRegistrar;
import com.wellconnected.bean.AboutUsBase;
import com.wellconnected.lazyload.ImageLoader_rounded;
import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.utills.MyApplication;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

public class MyProfileActivity extends Activity{
	private SharedPreferences pref;
	private MyApplication appDelegate;
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		}


	private TextView txt_name,txt_emaill,txt_contact_email,
	txt_year_birth,txt_gender,txt_edit,txt_header;
	private LinearLayout ll_back;
	private String user_id;
	private ImageLoader_rounded imgloader;
	private ImageView img_pic;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		setContentView(R.layout.myprofile);
		
		WellconnectedConstant.ScreenName="";
		appDelegate = (MyApplication)getApplicationContext();
		
		txt_header=(TextView) findViewById(R.id.txt_header);
		
		imgloader=new ImageLoader_rounded(MyProfileActivity.this);
		
		img_pic=(ImageView) findViewById(R.id.img_pic);
		
		txt_edit=(TextView) findViewById(R.id.txt_edit);
		txt_edit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(MyProfileActivity.this,EditProfile.class);
				startActivityForResult(intent, 0);
				
			}
		});
		
			pref = this.getSharedPreferences("LoginInfo", this.MODE_WORLD_READABLE);
		
		txt_name=(TextView) findViewById(R.id.txt_name);
		txt_emaill=(TextView) findViewById(R.id.txt_emaill);
		txt_contact_email=(TextView) findViewById(R.id.txt_contact_email);
		txt_year_birth=(TextView) findViewById(R.id.txt_year_birth);
		txt_gender=(TextView) findViewById(R.id.txt_gender);
		user_id=pref.getString("User_id", "");
		
		ll_back=(LinearLayout) findViewById(R.id.ll_back);
		ll_back.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				finish();
			}
		});
		
		if (WellconnectedUtills.isNetworkAvailable(MyProfileActivity.this)) 
		{
			new myprofileTask().execute();
		}
		else
		{
			WellconnectedUtills.customDialog(MyProfileActivity.this, "Internet connection is not available");
			
		
		}

		
		
	}
	
	
	/** about us  task **/
	public class myprofileTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		String chatbase;
;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(MyProfileActivity.this, "", "Please Wait");
			
		}

		@Override
		protected String doInBackground(String... params) {
			
			// TODO Auto-generated method stub
			chatbase = WellconnectedParse.myProfile(MyProfileActivity.this,user_id);

				//response=CCRApplicationParse.ChangePwd(ChangePasswordActivity.this, user_id, ed_password.getText().toString(), ed_new_pwd.getText().toString());
			
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			
			if (chatbase != null) {
				
				if(!chatbase.equals(""))
				{
					try {
						JSONObject obj=new JSONObject(chatbase);
						JSONObject obj_res=obj.getJSONObject("response");
						JSONArray arr=obj_res.getJSONArray("success");
						JSONObject objj=arr.getJSONObject(0);
						
						txt_name.setText(objj.getString("display_name"));
						txt_emaill.setText(objj.getString("email"));
						txt_contact_email.setText(objj.getString("contactEmail"));
						txt_year_birth.setText(objj.getString("dob"));
					//	txt_gender.setText(objj.getString("gender"));
						if((objj.getString("gender").equals("male")))
						{
					txt_gender.setText("Male");
					
						}
				else
				{
					txt_gender.setText("Female");
					
				}
						
						txt_header.setText(objj.getString("display_name"));
						
						System.out.println("URL_myProfile"+WellconnectedConstant.IMAGE_URL_3+objj.getString("user_image"));
						imgloader.DisplayImage(WellconnectedConstant.IMAGE_URL_3+objj.getString("user_image"), img_pic);
					
						
						SharedPreferences.Editor editor = pref.edit();

						editor.putString("user_image", objj.getString("user_image"));
						editor.commit();
					
						appDelegate.getChangePic().sendEmptyMessage(11);
						
										} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				
			}
		}
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		
		img_pic.setImageDrawable(null);
		
		if (WellconnectedUtills.isNetworkAvailable(MyProfileActivity.this)) 
		{
			new myprofileTask().execute();
		}
		else
		{
			WellconnectedUtills.customDialog(MyProfileActivity.this, "Internet connection is not available");
			
		
		}
		
	}

}
