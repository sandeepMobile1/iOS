package com.wellconnected.bean;

import java.util.ArrayList;

public class WellconnectedUserBean {
	public ArrayList<existingusers>existingusers;

	
	public ArrayList<existingusers> getExistingusers() {
		return existingusers;
	}


	public void setExistingusers(ArrayList<existingusers> existingusers) {
		this.existingusers = existingusers;
	}


	public static class existingusers
	{
		public String status;
		public String user_name;
		public String user_image;
		public String user_id;
		public String displayname;
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getUser_name() {
			return user_name;
		}
		public void setUser_name(String user_name) {
			this.user_name = user_name;
		}
		public String getUser_image() {
			return user_image;
		}
		public void setUser_image(String user_image) {
			this.user_image = user_image;
		}
		public String getUser_id() {
			return user_id;
		}
		public void setUser_id(String user_id) {
			this.user_id = user_id;
		}
		public String getDisplayname() {
			return displayname;
		}
		public void setDisplayname(String displayname) {
			this.displayname = displayname;
		}
		

       
	}
}
