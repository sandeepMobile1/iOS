package com.view.wellconnected;

import com.wellconnected.utills.WellconnectedConstant;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ImageView;


public class WelcomeActivity extends Activity implements OnClickListener {
	private ImageView img_login,img_resigtration;
	private SharedPreferences pref;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		

		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		WellconnectedConstant.ScreenName="";
		setContentView(R.layout.activity_main);
		
		pref = this.getSharedPreferences("LoginInfo", this.MODE_WORLD_READABLE);
		
		SharedPreferences.Editor editor = pref.edit();
		
		//editor.putString("User_id", user_id);
		editor.putString("Resigter_email", "");
		editor.commit();
		new Handler().postDelayed(new Runnable() {

			@Override
			public void run() {
				
				if(pref.getString("User_id", "").equals("")||pref.getString("is_remember", "").equals("false"))
				{
					Intent intent = new Intent(WelcomeActivity.this,
							LoginScreen.class);
					startActivity(intent);
					finish();
				}
				else 
				{
					//if(pref.getString("is_remember", "").equals("true"))
					//{
					Intent intent = new Intent(WelcomeActivity.this, MainActivity.class);
					startActivity(intent);
					finish();
					//}
					
				}


			}
		}, 2000);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent=null;
		switch(v.getId())
		{
	
	}
	}
}
