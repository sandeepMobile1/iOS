package com.view.wellconnected;

import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.wellconnected.bean.AboutUsBase;
import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

public class AboutUsActivity extends Activity{
	private TextView txt_aboutus;
	private LinearLayout ll_back;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		setContentView(R.layout.aboutus);
		WellconnectedConstant.ScreenName="";
		txt_aboutus=(TextView) findViewById(R.id.txt_aboutus);
		
		ll_back=(LinearLayout) findViewById(R.id.ll_back);
		ll_back.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				finish();
			}
		});
		
		if (WellconnectedUtills.isNetworkAvailable(AboutUsActivity.this)) 
		{
			new AboutUsTask().execute();
		}
		else
		{
			WellconnectedUtills.customDialog(AboutUsActivity.this, "Internet connection is not available");
		}
	}
	/** about us  task **/
	public class AboutUsTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		AboutUsBase chatbase;
;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(AboutUsActivity.this, "", "Please Wait");
			
		}

		@Override
		protected String doInBackground(String... params) {
			
			// TODO Auto-generated method stub
			chatbase = WellconnectedParse.aboutUs(AboutUsActivity.this);

				//response=CCRApplicationParse.ChangePwd(ChangePasswordActivity.this, user_id, ed_password.getText().toString(), ed_new_pwd.getText().toString());
			
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			
			if (chatbase != null) {
				if (chatbase.getHome()==null) {
					//WellconnectedUtills.customDialog(ChangePasswordActivity.this, chatbase.getResponse().getError());

				} else {
					txt_aboutus.setText(chatbase.getHome().getMessage());
					//WellconnectedUtills.customDialog_2(ChangePasswordActivity.this, chatbase.getResponse().getSuccess(),ChangePasswordActivity.this);

				}
			}
		}
	}
}
