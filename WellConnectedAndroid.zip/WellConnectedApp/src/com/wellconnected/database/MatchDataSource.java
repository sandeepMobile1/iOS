package com.wellconnected.database;

import java.util.ArrayList;

import com.wellconnected.bean.ChatDetailGroupBean;
import com.wellconnected.bean.Tabl_chat_user_bean;
import com.wellconnected.utills.WellconnectedConstant;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class MatchDataSource {

	private SQLiteDatabase database;
	private DataBaseManager dbHelper;

	@SuppressWarnings("unused")
	private Context mContext;

	public MatchDataSource(Context context) {
		// mContext=context;
		dbHelper = new DataBaseManager(context);
	}

	public SQLiteDatabase open() throws SQLException {
		// dbHelper=getSingleInstance(mContext);
		database = dbHelper.getWritableDatabase();
		return database;
	}

	public void close() {
		dbHelper.close();
		// database.close();
	}

	/**
	 * 
	 * @param request1
	 * @return This class defines all the DB methods used in the application the
	 *         method name itself identifies the purposes of its use
	 */

	/********************************** All Database Related Queries ****************************************/

	/**
	 * Insert method
	 * 
	 * @param table
	 *            - name of the table
	 * @param values
	 *            values to insert
	 * @throws android.database.SQLException
	 *             sql exception
	 */
	public void insert(String table, ContentValues values) throws SQLException {
		database.insert(table, null, values);
	}

	public int update(String table, ContentValues values, String where)
			throws SQLException {
		return database.update(table, values, where, null);
	}

	public int delete(String table, String whereClause) {
		return database.delete(table, whereClause, null);
	}

	/*
	 * public void saveUserDetailsToDB(String player1,String player2) {
	 * 
	 * ContentValues values1 = new ContentValues(); values1.put("userId",1);
	 * values1.put("userName",player2); values1.put("userImage","a");
	 * values1.put("gameId","a"); values1.put("set","f");
	 * values1.put("game","a"); values1.put("point","a");
	 * values1.put("score","a"); values1.put("userTeam","a");
	 * values1.put("gameStatus","a"); values1.put("firstinscore","a");
	 * values1.put("secinscore","a");
	 * 
	 * 
	 * database.insert("usertable",null, values1);
	 * 
	 * 
	 * }
	 */

	// insert State table
	public void insert_detail_StateTable(int StateId, String Pl1Score1,
			String Pl1Score2, String Pl2Score1, String Pl2Score2,
			String Pl1Set, String Pl2Set, String Pl1Game, String Pl2Game,
			String Pl1Point, String Pl2Point, String SetCount,
			String GameCount, String PointCount, String Status, String WinStatus) {

		ContentValues values1 = new ContentValues();
		values1.put("StateId", StateId);
		values1.put("Pl1Score1", Pl1Score1);
		values1.put("Pl1Score2", Pl1Score2);

		values1.put("Pl2Score1", Pl2Score1);
		values1.put("Pl2Score2", Pl2Score2);
		values1.put("Pl1Set", Pl1Set);
		values1.put("Pl2Set", Pl2Set);
		values1.put("Pl1Game", Pl1Game);
		values1.put("Pl2Game", Pl2Game);
		values1.put("Pl1Point", Pl1Point);
		values1.put("Pl2Point", Pl2Point);
		values1.put("SetCount", SetCount);
		values1.put("GameCount", GameCount);
		values1.put("PointCount", PointCount);
		values1.put("Status", Status);
		values1.put("WinStatus", WinStatus);

		database.insert("StateTbl", null, values1);

	}

	// update state table on basic of userid

	public void udate_detail_StateTable(String column_name_1,
			String column_name_2, String player_value, String status,
			int state_id, String Pl1Set, String Pl1Game, String Pl1Point,
			String Pl2Set, String Pl2Game, String Pl2Point) {
		ContentValues values1 = new ContentValues();
		values1.put(column_name_1, player_value);
		values1.put(column_name_2, status);

		values1.put("Pl1Set", Pl1Set);
		values1.put("Pl1Game", Pl1Game);
		values1.put("Pl1Point", Pl1Point);

		values1.put("Pl2Set", Pl2Set);
		values1.put("Pl2Game", Pl2Game);
		values1.put("Pl2Point", Pl2Point);

		// update point game and set from previous

		database.update("StateTbl", values1, "StateId=" + state_id, null);

	}

	public void udate_detail_StateTable_2(String Pl1Set, String Pl2Set,
			String Pl1Game, String Pl2Game, String Pl1Point, String Pl2Point,
			String SetCount, String GameCount, String PointCount,
			String WinStatus, int state_id) {
		ContentValues values1 = new ContentValues();
		values1.put("Pl1Set", Pl1Set);
		values1.put("Pl2Set", Pl2Set);
		values1.put("Pl1Game", Pl1Game);

		values1.put("Pl2Game", Pl2Game);
		values1.put("Pl1Point", Pl1Point);
		values1.put("Pl2Point", Pl2Point);
		values1.put("SetCount", SetCount);
		values1.put("GameCount", GameCount);
		values1.put("PointCount", PointCount);
		values1.put("WinStatus", WinStatus);

		database.update("StateTbl", values1, "StateId=" + state_id, null);

	}

	// game tablee

	public void saveUserDetailsToDB(int gameId, String gameMode,
			String Opponents) {

		ContentValues values1 = new ContentValues();
		values1.put("gameId", gameId);
		values1.put("gameMode", gameMode);
		values1.put("Opponents", Opponents);

		database.insert("game", null, values1);

	}

	// update usertable points

	public void updateUserTabel_points_score_game(String column_name,
			String points, String userId) {

		// UPDATE usertable SET firstinscore=1 WHERE userId=1;

		ContentValues values1 = new ContentValues();
		values1.put(column_name, points);

		// database.update("usertable", values1, "userId=1", null);

		database.update("usertable", values1, "userId=" + userId, null);

	}

	// update usertable points

	public void updateTeamImage(String column_name, byte[] image, String userId) {

		// UPDATE usertable SET firstinscore=1 WHERE userId=1;

		ContentValues values1 = new ContentValues();
		values1.put(column_name, image);

		// database.update("usertable", values1, "userId=1", null);

		database.update("usertable", values1, "userId=" + userId, null);

	}

	// update user table

	public void updateUserTabel(String column_name, String score, String userId) {

		// UPDATE usertable SET firstinscore=1 WHERE userId=1;

		ContentValues values1 = new ContentValues();
		values1.put(column_name, score);

		// database.update("usertable", values1, "userId=1", null);

		database.update("usertable", values1, "userId=" + userId, null);

	}

	// update user table for image

	public void updateUserTabel_image(String column_name, String pos,
			byte[] bArray_1) {

		// UPDATE usertable SET firstinscore=1 WHERE userId=1;

		ContentValues values1 = new ContentValues();
		values1.put(column_name, bArray_1);
		// database.update("usertable", values1, "userId=1", null);
		database.update("usertable", values1, "userId=" + pos, null);

	}

	// get setcount from db

	public ArrayList<Tabl_chat_user_bean> getTabl_chat_user() {

		ArrayList<Tabl_chat_user_bean> arrSet = new ArrayList<Tabl_chat_user_bean>();

		final String MY_QUERY = "SELECT * FROM tbl_chatUser;";

		database = dbHelper.getWritableDatabase();
		Cursor cursor = database.rawQuery(MY_QUERY, null);

		if (cursor.moveToFirst()) {
			do {
				if (cursor.getString(0) != null) {
					
					Tabl_chat_user_bean bean=new Tabl_chat_user_bean();
					bean.setId(cursor.getString(0));
					bean.setChatUserId(cursor.getString(1));
					bean.setChatFriendId(cursor.getString(2));
					bean.setZMsgId(cursor.getString(3));
					bean.setLastMsgId(cursor.getString(4));
					arrSet.add(bean);

				}
			} while (cursor.moveToNext());
		}
		cursor.close();

		return arrSet;

	}
	//get table chat
/*	public ArrayList<ChatDetailGroupBean> getTabl_chat() {

		ArrayList<ChatDetailGroupBean> arrSet = new ArrayList<ChatDetailGroupBean>();

		final String MY_QUERY = "SELECT * FROM tbl_chat";

		database = dbHelper.getWritableDatabase();
		Cursor cursor = database.rawQuery(MY_QUERY, null);

		if (cursor.moveToFirst()) {
			do {
				if (cursor.getString(0) != null) {
					
					ChatDetailGroupBean bean=new ChatDetailGroupBean();
							if(cursor.getString(5).equals("1"))
							{
								bean.setMessage(cursor.getString(6));
							}
							else if(cursor.getString(5).equals("2"))
							{
								bean.setImage_url(cursor.getString(6));
							}
							else
							{
								bean.setAudio_url(cursor.getString(6));
							}
					bean.setChat_type(cursor.getString(5));
					bean.setDate("");
					bean.setFriend_id(friend_id)
					bean.setImage(image)
					bean.setMsgid(cursor.getString(14));
					bean.setStaticc(cursor.getString(12));
					bean.setThread_id(cursor.getString(11));
					bean.setTimestamp(cursor.getString(4));
					bean.setType("");
					bean.setUsername(username)
					arrSet.add(bean);
				}
			} while (cursor.moveToNext());
		}
		cursor.close();

		return arrSet;

	}*/
	//check for empaty chat table
	public boolean is_chat_table_empaty() {

		
		final String MY_QUERY = "SELECT * FROM tbl_chat";

		database = dbHelper.getWritableDatabase();
		Cursor cursor = database.rawQuery(MY_QUERY, null);
		if(cursor.getCount()>0)
		{
			return true;
		}
		else
		{
			return false;
		}
		

	/*	if (cursor.moveToFirst()) {
			do {
				if (cursor.getString(0) != null) {
					arrGame.add(cursor.getString(0));

				}
			} while (cursor.moveToNext());
		}
		cursor.close();

		return arrGame;*/

	}
	/** get count after table join **/
	/** get row id **/
	public String getCount(String rowid)
	{
		final String MY_QUERY = "SELECT COUNT(*) from tbl_chat as tbc INNER JOIN tbl_chatUser as tcu on tbc.ZChatId=tcu.Id LEFT JOIN tbl_user as tbu on tbu.UserId = tbc.NameCardId LEFT  JOIN tbl_user as tu on tbc.MsgUserId=tu.UserId where tcu.Id ="+rowid;

		database = dbHelper.getWritableDatabase();
		Cursor cursor = database.rawQuery(MY_QUERY, null);
		String count = null;
		if (cursor.moveToFirst()) {
			do {
				count=cursor.getString(0);
					

				
			} while (cursor.moveToNext());
		}
		cursor.close();
		
		return count;
	}
	
/** get row id **/
	public String getRowId(String chatuserId,String ChatFriendId)
	{
		final String MY_QUERY = "SELECT * FROM tbl_chatUser";
		database = dbHelper.getWritableDatabase();
		Cursor cursor = database.rawQuery(MY_QUERY, null);
		System.out.println("cursor.getCount()"+cursor.getCount());
		WellconnectedConstant.Courser_count=cursor.getCount();
		String rowid = null;
		if (cursor.moveToFirst()) {
			do {
				if (cursor.getString(1) .equals(chatuserId)&&cursor.getString(2).equals(ChatFriendId)) {
					rowid=cursor.getString(0);
					

				}
			} while (cursor.moveToNext());
		}
		cursor.close();
		
		return rowid;
	}
//get user id fro user_tbl
	
	public boolean getUserId_table_user(String userid)
	{
		final String MY_QUERY = "SELECT * FROM tbl_user";

		database = dbHelper.getWritableDatabase();
		Cursor cursor = database.rawQuery(MY_QUERY, null);

		String user_id = null;
		if (cursor.moveToFirst()) {
			do {
				if (cursor.getString(1) != null) {
					user_id=cursor.getString(1);
					if(user_id.equals(userid))
					{
						String row_id=cursor.getString(0);
						WellconnectedConstant.replace_row_id=row_id;
						return true;
					}

				}
			} while (cursor.moveToNext());
		}
		cursor.close();
		return false;
		
	}
	// get Gamecount from db

	public ArrayList<String> getGameCount() {

		ArrayList<String> arrGame = new ArrayList<String>();

		final String MY_QUERY = "SELECT GameCount FROM StateTbl WHERE Status = 1 GROUP BY GameCount ORDER BY StateId";

		database = dbHelper.getWritableDatabase();
		Cursor cursor = database.rawQuery(MY_QUERY, null);

		if (cursor.moveToFirst()) {
			do {
				if (cursor.getString(0) != null) {
					arrGame.add(cursor.getString(0));

				}
			} while (cursor.moveToNext());
		}
		cursor.close();

		return arrGame;

	}
	
	/** delete all tables of DB **/
	public void emptyDatabase()
	{
		database = dbHelper.getWritableDatabase();
		database.delete("tbl_user", null, null);
		database.delete("tbl_chatUser", null, null);
		database.delete("tbl_chat", null, null);
		
	}
	public ArrayList<ChatDetailGroupBean> getChatValue(String row_id,String page_count) {
		// TODO Auto-generated method stub
		ArrayList<ChatDetailGroupBean> arrchat = new ArrayList<ChatDetailGroupBean>();
	//	final String MY_QUERY = "SELECT tbc.ContentType,tbc.ReadCount,tbc.TimeStamp,tbc.MessageType,tbc.Message,tbc.ImageId,tbc.AudioId,tbu.UserId,tbu.UserName,tbu.UserImage,tbc.MsgUserId,tu.UserName,tu.UserImage,tu.DisplayName,tbc.Id,tbc.StaticMessage,tbc.RequestStatus,tbc.MessageId from tbl_chat as tbc INNER JOIN tbl_chatUser as tcu on tbc.ZChatId=tcu.Id LEFT JOIN tbl_user as tbu on tbu.UserId = tbc.NameCardId LEFT  JOIN tbl_user as tu on tbc.MsgUserId=tu.UserId where tcu.Id ="+row_id+" order by tbc.Id DESC limit '0',20";
		
		
		final String MY_QUERY = "SELECT tbc.ContentType,tbc.ReadCount,tbc.TimeStamp,tbc.MessageType,tbc.Message,tbc.ImageId,tbc.AudioId,tbu.UserId,tbu.UserName,tbu.UserImage,tbc.MsgUserId,tu.UserName,tu.UserImage,tu.DisplayName,tbc.Id,tbc.StaticMessage,tbc.RequestStatus,tbc.MessageId from tbl_chat as tbc INNER JOIN tbl_chatUser as tcu on tbc.ZChatId=tcu.Id LEFT JOIN tbl_user as tbu on tbu.UserId = tbc.NameCardId LEFT  JOIN tbl_user as tu on tbc.MsgUserId=tu.UserId where tcu.Id ="+row_id+" order by tbc.Id DESC limit "+page_count+",20";
		System.out.println("MY_QUERY"+MY_QUERY);
		
		database = dbHelper.getWritableDatabase();
		Cursor cursor = database.rawQuery(MY_QUERY, null);

		System.out.println("cursor"+cursor.getCount());
		
		
		if (cursor.moveToFirst()) {
			do {
				if (cursor.getString(0) != null) {
					ChatDetailGroupBean bean=new ChatDetailGroupBean();
					if(cursor.getString(3).equals("3"))
					{
						bean.setAudio_url(cursor.getString(4));
						
					}
					else if(cursor.getString(3).equals("2"))
					{
						bean.setImage_url(cursor.getString(4));
					}
					else
					{
						bean.setMessage(cursor.getString(4));
						
					}
					bean.setChat_type(cursor.getString(3));
					bean.setDate(cursor.getString(2));
					bean.setFriend_id(cursor.getString(10));
					bean.setImage(cursor.getString(12));
					bean.setMsgid(cursor.getString(17));
					bean.setStaticc(cursor.getString(15));
					bean.setThread_id("");
					bean.setTimestamp(cursor.getString(2));
					bean.setUsername(cursor.getString(13));
					bean.setType("");
					bean.setMsg_byte(cursor.getBlob(15));
					bean.setRequest_status(cursor.getString(16));
					arrchat.add(bean);

				}
			} while (cursor.moveToNext());
		}
		
		cursor.close();

		return arrchat;
	}
	public String getLastrecoard_table()
	{
		String last_row_id="";
		
		final String MY_QUERY = "SELECT * FROM tbl_chat WHERE ROWID IN ( SELECT max( ROWID ) FROM tbl_chat)";
		database = dbHelper.getWritableDatabase();
		Cursor cursor = database.rawQuery(MY_QUERY, null);

		if (cursor.moveToFirst()) {
			do {
				if (cursor.getString(0) != null) {
					last_row_id=cursor.getString(0);
					
				}
			} while (cursor.moveToNext());
		}
		cursor.close();
		return last_row_id;
		
	}
	public ArrayList<String> getPointCount() {

		ArrayList<String> arrPoint = new ArrayList<String>();

		final String MY_QUERY = "SELECT PointCount FROM StateTbl WHERE Status = 1 GROUP BY PointCount ORDER BY StateId";

		database = dbHelper.getWritableDatabase();
		Cursor cursor = database.rawQuery(MY_QUERY, null);

		if (cursor.moveToFirst()) {
			do {
				if (cursor.getString(0) != null) {
					arrPoint.add(cursor.getString(0));

				}
			} while (cursor.moveToNext());
		}
		cursor.close();

		return arrPoint;

	}

	

	//tbl-user insert data
	

	public void inserttbl_user(int Id,String UserId,String UserName,
			String UserImage,String DisplayName,
			String EmailId,String PhoneNo,String Gender,String Dob,String Rating,String Unpaid_revenue)
	{
		
		ContentValues values1 = new ContentValues( );
		values1.put("Id", Id);
		values1.put("UserId",UserId);
		values1.put("UserName", UserName);
		values1.put("UserImage", UserImage);
		values1.put("DisplayName",DisplayName);
		values1.put("EmailId",EmailId);
		values1.put("PhoneNo",PhoneNo);
		values1.put("Gender",Gender);
		values1.put("Dob",Dob);
		values1.put("Rating",Rating);
		values1.put("Unpaid_revenue",Unpaid_revenue);
		
		// database.update("usertable", values1, "userId=1", null);
		//database.update("tbl_chat", values1, null, null);
		database.insert("tbl_user", null, values1);
		//database.update("gametype", values1, "id=" + id, null);

	}
	
	//update user table
	

	public void updatetbl_user(int Id,String UserId,String UserName,
			String UserImage,String DisplayName,
			String EmailId,String PhoneNo,String Gender,String Dob,String Rating,String Unpaid_revenue)
	{
		
		ContentValues values1 = new ContentValues( );
		values1.put("Id", Id);
		values1.put("UserId",UserId);
		values1.put("UserName", UserName);
		values1.put("UserImage", UserImage);
		values1.put("DisplayName",DisplayName);
		values1.put("EmailId",EmailId);
		values1.put("PhoneNo",PhoneNo);
		values1.put("Gender",Gender);
		values1.put("Dob",Dob);
		values1.put("Rating",Rating);
		values1.put("Unpaid_revenue",Unpaid_revenue);
		
		database.update("tbl_user", values1, "UserId=" + UserId, null);
		//database.update("tbl_chat", values1, null, null);
		//database.insert("tbl_user", null, values1);
		//database.update("gametype", values1, "id=" + id, null);

	}
	// update detail in gametype
	
	
	public void UPDATE_TBL_CHAT(int Id,String chatUserId,String chatFriendId,
			String ZMsgId,String lastMsgId) {

		// UPDATE usertable SET firstinscore=1 WHERE userId=1;

		
		String MY_QUERY="Update tbl_chatUser set lastMsgId ="+lastMsgId+" where chatUserId ="+chatUserId+" and chatFriendId="+ chatFriendId;
		System.out.println("MY_QUERY"+MY_QUERY);
		database = dbHelper.getWritableDatabase();
		database.execSQL(MY_QUERY);

		
	/*	ContentValues values1 = new ContentValues( );
		values1.put("Id", Id);
		values1.put("chatUserId",chatUserId);
		values1.put("chatFriendId", chatFriendId);
		values1.put("ZMsgId", ZMsgId);
		values1.put("lastMsgId",lastMsgId);
	
		// database.update("usertable", values1, "userId=1", null);

		database.update("tbl_chatUser", values1, ("chatUserId=?" and  "chatFriendId=?" ),("chatFriendId=" + chatFriendId), null);
*/
	}

	public void updatetbl_chatUser(int Id,String chatUserId,String chatFriendId,
			String ZMsgId,String lastMsgId)
	{
		
		ContentValues values1 = new ContentValues( );
		values1.put("Id", Id);
		values1.put("chatUserId",chatUserId);
		values1.put("chatFriendId", chatFriendId);
		values1.put("ZMsgId", ZMsgId);
		values1.put("lastMsgId",lastMsgId);
	
		// database.update("usertable", values1, "userId=1", null);
		//database.update("tbl_chat", values1, null, null);
		database.insert("tbl_chatUser", null, values1);
		//database.update("gametype", values1, "id=" + id, null);

	}
	
	
	public void updatetabl_chat(int friend_id,String group_id,String contant_type,
			String read_count,String timestamp,String MessageType,String Message,String  AudioId,
			String ImageId,String NameCardId,String MsgUserId,String ZChatId,String  StaticMessage,
			String RequestStatus,String MessageId,byte[]msg_byte)
	{
		
		ContentValues values1 = new ContentValues( );
		values1.put("Id", friend_id);
		values1.put("GroupId",group_id);
		values1.put("ContentType", contant_type);
		values1.put("ReadCount", read_count);
		values1.put("TimeStamp",timestamp);
		values1.put("MessageType",MessageType);
		values1.put("Message", Message);
		values1.put("AudioId", AudioId);
		values1.put("ImageId", ImageId);
		values1.put("NameCardId", NameCardId);
		values1.put("MsgUserId",MsgUserId);
		values1.put("ZChatId", ZChatId);
		values1.put("StaticMessage", StaticMessage);
		values1.put("RequestStatus", RequestStatus);
		values1.put("MessageId", MessageId);
		values1.put("Message_byte", msg_byte);

		// database.update("usertable", values1, "userId=1", null);
		//database.update("tbl_chat", values1, null, null);
		database.insert("tbl_chat", null, values1);
		//database.update("gametype", values1, "id=" + id, null);

	}
	public void updategame_type_points_score_game(String points, String game,
			String set, String id) {

		// UPDATE usertable SET firstinscore=1 WHERE userId=1;

		ContentValues values1 = new ContentValues();
		values1.put("point", points);
		values1.put("game", game);
		values1.put("sets", set);

		// database.update("usertable", values1, "userId=1", null);

		database.update("gametype", values1, "id=" + id, null);

	}

	public void update_old_game_type_points_score_game(String old_points,
			String old_game, String old_set, String id) {

		// UPDATE usertable SET firstinscore=1 WHERE userId=1;

		ContentValues values1 = new ContentValues();
		values1.put("Oldpoint", old_points);
		values1.put("Oldgame", old_game);
		values1.put("Oldset", old_set);

		// database.update("usertable", values1, "userId=1", null);

		database.update("gametype", values1, "id=" + id, null);

	}

	public void delete_messages(String thread_id) {
		// TODO Auto-generated method stub
		
			

		database.execSQL("DELETE FROM tbl_Chat where  ZChatId="+thread_id);

	}


	
	
}
