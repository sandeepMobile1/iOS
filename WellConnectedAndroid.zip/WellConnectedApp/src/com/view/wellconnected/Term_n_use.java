package com.view.wellconnected;

import com.wellconnected.utills.WellconnectedConstant;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Term_n_use extends Activity {
	private LinearLayout ll_back;
	private TextView txt_header;
	private String header,URL;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		setContentView(R.layout.aboutus);
		
		WellconnectedConstant.ScreenName="";
		header=this.getIntent().getStringExtra("TEARMS");
		
		URL=this.getIntent().getStringExtra("URL");
		
		TextView txt_aboutus=(TextView) findViewById(R.id.txt_aboutus);
		txt_aboutus.setVisibility(View.GONE);
		
		WebView web_view=(WebView) findViewById(R.id.web_view);
		web_view.setVisibility(View.VISIBLE);
		
	      web_view.getSettings().setJavaScriptEnabled(true); // enable javascript

	      web_view.setWebViewClient(new WebViewClient() {
	            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
	               // Toast.makeText(activity, description, Toast.LENGTH_SHORT).show();
	            }
	        });

	      web_view .loadUrl(URL);
	   
		txt_header=(TextView) findViewById(R.id.txt_header);
		txt_header.setText(header);
		
		
		ll_back=(LinearLayout) findViewById(R.id.ll_back);
		ll_back.setOnClickListener(new  OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				finish();
			}
		});
	}
}
