package com.view.wellconnected;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;

import com.wellconnected.utills.WellconnectedConstant;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.LayoutInflater;
import android.view.TextureView;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class GalleryView extends Activity {
	private LinearLayout ll_back;
	private ViewPager pager;
	private TextView txt_count;
	private int[] drawable={R.drawable.about_input,R.drawable.search_bg};
	private ArrayList<String>image_url;
	private String image;
	private int select_item;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.galleyviewrow);
		
		image=this.getIntent().getStringExtra("IMAGE");
		
		System.out.println("image"+image);
		
		image_url=new ArrayList<String>();
		for(int i=0;i<WellconnectedConstant.arr_chat_new.size();i++)
		{
			if(WellconnectedConstant.arr_chat_new.get(i).getChat_type().equals("2"))
			{
				image_url.add(WellconnectedConstant.arr_chat_new.get(i).getImage_url());
				
						}
		}
		/*for(int i=0;i<image_url.size();i++)
		{
			if(WellconnectedConstant.arr_chat_new.get(i).getImage_url().equals(image))
			{
				select_item=i;
				break;
			}
		}
		*/
		pager=(ViewPager) findViewById(R.id.pager);
		pager.setAdapter(new ViewPagerAdapter());
		pager.setCurrentItem(select_item);
		
		txt_count=(TextView) findViewById(R.id.txt_count);
		txt_count.setText((select_item+1)+" of "+image_url.size());
		

		pager.setOnPageChangeListener(new OnPageChangeListener() {
			
			@Override
			public void onPageSelected(int arg0) {
				// TODO Auto-generated method stub
				txt_count.setText((arg0+1)+" of "+image_url.size());
				
				
			}
			
			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
				// TODO Auto-generated method stub
				
			}
			
			public void onPageScrollStateChanged(int arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		
			ll_back=(LinearLayout) findViewById(R.id.ll_back);
		ll_back.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				finish();
			}
		});
	}
	
	public class ViewPagerAdapter extends PagerAdapter {
	    // Declare Variables
		View row=null;
	    @Override
	    public int getCount() {
	        return image_url.size();
	    }
	 
	    @Override
	    public boolean isViewFromObject(View view, Object object) {
	        return view == object;
	    }
	 
	    @Override
	    public Object instantiateItem(ViewGroup container, int position) {
	 
	        // Declare Variables
	    row=View.inflate(GalleryView.this, R.layout.view_pager_row, null);
	   ImageView img_pic=(ImageView) row.findViewById(R.id.img_pic);
	   
	   
	   img_pic.setImageBitmap(getBitmapFromURL(image_url.get(position)));
	   
	        // Add viewpager_item.xml to ViewPager
	        ((ViewPager) container).addView(row);
	 
	        return row;
	    }
	 
	    @Override
	    public void destroyItem(ViewGroup container, int position, Object object) {
	        // Remove viewpager_item.xml from ViewPager
	    	((ViewPager) container).removeView((View) object);
	    }
	}

public static Bitmap getBitmapFromURL(String src) {
	
	FileInputStream in;
	try {
		in = new FileInputStream(src);
		BitmapFactory.Options options = new BitmapFactory.Options();
		options.inSampleSize = 4;
		Bitmap bitmap = BitmapFactory.decodeStream(in, null, options);
		return bitmap;
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return null;

  /*  try {
        URL url = new URL(src);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setDoInput(true);
        connection.connect();
        InputStream input = connection.getInputStream();
        Bitmap myBitmap = BitmapFactory.decodeStream(input);
        return myBitmap;
    } catch (IOException e) {
        e.printStackTrace();
        return null;
    }*/
}
}
