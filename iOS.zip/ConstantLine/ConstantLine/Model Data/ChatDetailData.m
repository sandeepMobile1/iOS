//
//  ChatDetailData.m
//  ConstantLine
//
//  Created by octal i-phone2 on 8/13/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "ChatDetailData.h"

@implementation ChatDetailData

@synthesize name,image,message,charge,date,readStatus,userId,chatType,groupType,paidStatus,cellHeight,friendStatus,messasgeId,postAudioUrl,postImageUrl,nameCardId,nameCardName,nameCardImage,staticMessage,requestStatus,serverMsgId,audioDuration;

@end
