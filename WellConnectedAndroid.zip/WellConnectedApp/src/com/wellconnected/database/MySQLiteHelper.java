package com.wellconnected.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class MySQLiteHelper extends SQLiteOpenHelper {

	private static final String DATABASE_NAME = "YallaEmiratesDB";
	private static final int DATABASE_VERSION = 1;

	public MySQLiteHelper(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

	public void onCreate(SQLiteDatabase database) {

		// database.execSQL(YallaDataBaseConstants.CREATE_TABLE_FEATURED_ADS);
		// database.execSQL(YallaDataBaseConstants.CREATE_TABLE_FREE);
		/*
		 * database.execSQL(YallaDataBaseConstants.CREATE_TABLE_ALL_VOUCHER_DETAILS
		 * );
		 * database.execSQL(YallaDataBaseConstants.CREATE_TABLE_FEATURED_VOUCHERS
		 * );
		 * database.execSQL(YallaDataBaseConstants.CREATE_TABLE_FREE_VOUCHERS);
		 * database
		 * .execSQL(YallaDataBaseConstants.CREATE_TABLE_PREMIUM_VOUCHERS);
		 * database
		 * .execSQL(YallaDataBaseConstants.CREATE_TABLE_CAT_SUBCAT_MAPPING);
		 * database.execSQL(YallaDataBaseConstants.CREATE_TABLE_BRANCH);
		 * database.execSQL(YallaDataBaseConstants.CREATE_TABLE_USER);
		 * database.execSQL(YallaDataBaseConstants.CREATE_TABLE_COUNTRY);
		 * database.execSQL(YallaDataBaseConstants.CREATE_TABLE_CITY);
		 * database.execSQL(YallaDataBaseConstants.CREATE_TABLE_ATTRACTION);
		 * database.execSQL(YallaDataBaseConstants.CREATE_TABLE_LOCATION);
		 * database.execSQL(YallaDataBaseConstants.CREATE_TABLE_CATEGORY);
		 * database.execSQL(YallaDataBaseConstants.CREATE_TABLE_SUB_CATEGORY);
		 * database.execSQL(YallaDataBaseConstants.CREATE_TABLE_SAVED_VOUCHERS);
		 * database
		 * .execSQL(YallaDataBaseConstants.CREATE_TABLE_VOUCHER_HISTORY);
		 * database.execSQL(YallaDataBaseConstants.CREATE_TABLE_REDEEM_OFFLINE);
		 * database.execSQL(YallaDataBaseConstants.CREATE_TABLE_HOME_DELIVERY);
		 * 
		 * 
		 * 
		 * Log.i("TABLE FREE",YallaDataBaseConstants.CREATE_TABLE_FREE_VOUCHERS);
		 * Log.i("TABLE CAT_SUBCAT",YallaDataBaseConstants.
		 * CREATE_TABLE_CAT_SUBCAT_MAPPING);
		 */
	}

	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		Log.w(MySQLiteHelper.class.getName(),
				"Upgrading database from version " + oldVersion + " to "
						+ newVersion + ", which will destroy all old data");
		// db.execSQL("DROP TABLE IF EXISTS " + TABLE_COMMENTS);
		// onCreate(db);
	}

}
