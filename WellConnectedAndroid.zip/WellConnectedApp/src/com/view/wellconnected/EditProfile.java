package com.view.wellconnected;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.UUID;
import java.util.regex.Pattern;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.view.wellconnected.AboutUsActivity.AboutUsTask;
import com.view.wellconnected.UserInfoActivity.profileTask;
import com.wellconnected.bean.GroupSearchMenuListener;
import com.wellconnected.lazyload.ImageLoader_rounded;
import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.utills.JsonPostRequest1;
import com.wellconnected.utills.MyApplication;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

import android.R.bool;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap.CompressFormat;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;


public class EditProfile extends Activity implements OnClickListener{
	private String user_id,Age="",gender,imageFilePath,imageType,
		 	email_id,display_name,contactEmail,dob,intro;
	private EditText ed_screenname,ed_email,ed_contact_email,ed_intro;
	private ImageView img_gender,img_pic;
	private Button img_age,btn_done;
	private LinearLayout ll_upload;
	private boolean is_gender;
	private ImageLoader_rounded img_loader;
	private Bitmap bitmap;
	public static final Pattern EMAIL_ADDRESS_PATTERN = Pattern.compile("[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}");
	private GroupSearchMenuListener mGroupSearchMenuListener;
	private LinearLayout ll_back,linear_male,linear_female,linear_gender;;
	private MyApplication appDelegate;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		setContentView(R.layout.edit_profile_screen);
		
		WellconnectedConstant.ScreenName="";
		SharedPreferences	pref = this.getSharedPreferences("LoginInfo", this.MODE_WORLD_READABLE);
		user_id=pref.getString("User_id", "");
		
		appDelegate = (MyApplication)getApplicationContext();
//		mGroupSearchMenuListener = (GroupSearchMenuListener) getApplicationContext();
		img_loader=new ImageLoader_rounded(EditProfile.this);
		
		ll_back=(LinearLayout) findViewById(R.id.ll_back);
		ll_back.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {

				finish();
			}
		});
		
		ed_screenname=(EditText) findViewById(R.id.ed_screenname);
		ed_screenname.setEnabled(false);
		
		ed_email=(EditText) findViewById(R.id.ed_email);
		ed_email.setEnabled(false);
		
		
		ed_contact_email=(EditText) findViewById(R.id.ed_contact_email);
		ed_intro=(EditText) findViewById(R.id.ed_intro);
				
		linear_male=(LinearLayout) findViewById(R.id.linear_male);
		linear_male.setOnClickListener(this);
		
		linear_gender=(LinearLayout) findViewById(R.id.linear_gender);
		linear_gender.setOnClickListener(this);

		linear_female=(LinearLayout) findViewById(R.id.linear_female);
		linear_female.setOnClickListener(this);
		
		img_pic=(ImageView) findViewById(R.id.img_pic);
		img_pic.setOnClickListener(this);
	
		img_age=(Button) findViewById(R.id.img_age);
		img_age.setOnClickListener(this);
		
		ll_upload=(LinearLayout) findViewById(R.id.ll_upload);
		ll_upload.setOnClickListener(this);
		
		btn_done=(Button) findViewById(R.id.btn_done);
		btn_done.setOnClickListener(this);
		
		System.out.println("ONCREATET===="+MyApplication.edit_profile_bitmap);
		
		
		if(	MyApplication.is_edit_pic.equals("1"))
		{
			MyApplication.is_edit_pic="0";
			//img_pic.setImageBitmap(WellconnectedUtills.getRoundedShape(bitmap));
			
		}
		else
		{
			if (WellconnectedUtills.isNetworkAvailable(EditProfile.this)) {
				new geteditProfileTask().execute();

			} else {
				WellconnectedUtills.customDialog(EditProfile.this, "Internet connection is not available");

			}
		}
		
	}
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		InputMethodManager imm = (InputMethodManager)getSystemService(
			      EditProfile.this.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(ed_email.getWindowToken(), 0);		

		}
	@Override
	protected void onActivityResult(int requestCode,int resultCode,Intent data)
	{				
		super.onActivityResult(requestCode, resultCode, data);
		
		if(resultCode==Activity.RESULT_OK)
		{
			if(requestCode==1) 
			{
				try 
				{				
					Uri selectedimage = data.getData();
					String[] filepathcolumn = {MediaStore.Images.Media.DATA};

					Cursor cursor = getContentResolver().query(selectedimage,filepathcolumn, null, null, null);
					cursor.moveToFirst();

					int columnindex = cursor.getColumnIndex(filepathcolumn[0]);
					
					imageFilePath = cursor.getString(columnindex);				
					
					imageType = imageFilePath.substring(imageFilePath.lastIndexOf(".") + 1);										
					
					cursor.close();
					
					FileInputStream in;
					
					try 
					{
						in = new FileInputStream(imageFilePath);
						
						BitmapFactory.Options options = new BitmapFactory.Options();
						options.inSampleSize = 4;
						bitmap = BitmapFactory.decodeStream(in,null,options);
						
						
						MyApplication.edit_profile_bitmap=bitmap;
						
						System.out.println("ONACTIVITY_RESULT=="+MyApplication.edit_profile_bitmap);
						//img_user_pic.setImageBitmap(bitmap);
						
						img_pic.setImageBitmap(WellconnectedUtills.getRoundedBitmap_2(bitmap));
					}
					catch (Exception e) 
					{
						Log.e("Error reading file", e.toString());
						
						if(e instanceof FileNotFoundException)
						{
							Toast.makeText(EditProfile.this,"Network Synchronized Image Does Not Exists", Toast.LENGTH_SHORT).show();
						}
					}				
					
				} 				
				catch (Exception e) 
				{					
					e.printStackTrace();
					
					if(e instanceof FileNotFoundException)
					{
						Toast.makeText(EditProfile.this,"Network Synchronized Image Does Not Exists", Toast.LENGTH_SHORT).show();
					}
				}
			}
			else if (requestCode == 2) 
			{			
				File Imagedirectory = new File(Environment.getExternalStorageDirectory()+ "/MyImage");
				if (!Imagedirectory.exists()) 
				{
					Imagedirectory.mkdir();
				}

				int quality = 5;
				String ssss = UUID.randomUUID().toString();
				File file = new File(Imagedirectory.getPath() + "/" + ssss + ".png");
				
				imageFilePath=file.getPath();
				imageType="png";
				
				try 
				{
					if (data.getExtras() != null) 
					{
						bitmap = (Bitmap) data.getExtras().get("data");

						try 
						{
							file.createNewFile();
							FileOutputStream fileOutputStream = new FileOutputStream(file);
							BufferedOutputStream bos = new BufferedOutputStream(fileOutputStream);
							bitmap.compress(CompressFormat.PNG, quality, bos);
							
							MyApplication.edit_profile_bitmap=bitmap;
							
							System.out.println("ONACTIVITY_RESULT=="+MyApplication.edit_profile_bitmap);
							
							//img_user_pic.setImageBitmap(bitmap);
							img_pic.setImageBitmap(WellconnectedUtills.getRoundedBitmap_2(bitmap));
										bos.flush();
							bos.close();
						} 
						catch (Exception e) 
						{
							e.printStackTrace();
						}												
					}
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}			
			}			
		}				
	}
	
	/** about us  task **/
	public class geteditProfileTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		String chatbase;
;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(EditProfile.this, "", "Please Wait");
			
		}

		@Override
		protected String doInBackground(String... params) {
			
			// TODO Auto-generated method stub
			chatbase = WellconnectedParse.myProfile(EditProfile.this,user_id);

			
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			
			if (chatbase != null) {
				if(!chatbase.equals(""))
				{
						JSONObject obj;
						try {
							obj = new JSONObject(chatbase);
							JSONObject obj_res=obj.getJSONObject("response");
							JSONArray arr=obj_res.getJSONArray("success");
							JSONObject objj=arr.getJSONObject(0);
							ed_screenname.setText(objj.getString("display_name"));
							ed_email.setText(objj.getString("email"));
							ed_contact_email.setText(objj.getString("contactEmail"));
							img_age.setText(objj.getString("dob"));
							if(objj.getString("intro").equals("null"))
							{
								ed_intro.setText("");
							}
							else
							{
								ed_intro.setText(objj.getString("intro"));
								
							}
							
							getImageInSDCard(WellconnectedConstant.IMAGE_URL_1+objj.getString("user_image"));
							
							img_loader.DisplayImage(WellconnectedConstant.IMAGE_URL_1+objj.getString("user_image"), img_pic);
							
							if(objj.getString("gender").equals("male"))
							{
								gender="1";
								is_gender=true;
								linear_gender.setBackgroundResource(R.drawable.gender_selection_male);
							}
							else
							{
								gender="2";
								is_gender=false;
								linear_gender.setBackgroundResource(R.drawable.gender_selection_female);
								//img_gender.setImageResource(R.drawable.gender_selection_female);
							}
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
						
			}
				try {
					progressDialog.dismiss();
				} catch (IllegalArgumentException e) {
					// TODO: handle exception
				}
				
		}
	}
}
	@Override
	public Dialog onCreateDialog(int id,final Bundle args)
	{
		AlertDialog dialog=null;
		MyApplication.is_edit_pic="1";
		switch(id)
		{				
			/*case 0: 
			{
				return new DatePickerDialog(this, datePickerListener,Integer.parseInt(year), Integer.parseInt(month),Integer.parseInt(day));
			}	*/
			case 1:
			{
				String options[];
				               
				options=new String[]{"Gallery","Camera"};
				
				AlertDialog.Builder builder=new AlertDialog.Builder(this);
				builder.setSingleChoiceItems(options,-1, new DialogInterface.OnClickListener() 
				{					
					@Override
					public void onClick(DialogInterface dialog, int which) 
					{
						if(which==0)
						{							
							try 
							{
								Intent i = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI);
								startActivityForResult(i, 1);
							} 
							catch (Exception e) 
							{
								 e.printStackTrace();
							}
						}
						else if(which == 1)
						{														
							try 
							{
								Intent i = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
								startActivityForResult(i, 2);
							}
							catch (Exception e) 
							{
								 e.printStackTrace();
							}
						}						
						removeDialog(1);
					}					
				}).setTitle("Take Image From");
				
				dialog=builder.create();
				break;
			}			
			default:
			{
				break;
			}
		}
		return dialog;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId())
		{
		case R.id.btn_done:
			email_id=ed_email.getText().toString();
			display_name=ed_screenname.getText().toString();
			contactEmail=ed_contact_email.getText().toString();
			intro=ed_intro.getText().toString();
			if(contactEmail.equals(""))
			{
				WellconnectedUtills.customDialog(EditProfile.this, "Please enter contact email address");
				ed_contact_email.requestFocus();
				
			}
				else if (!checkEmail(contactEmail)) {

					WellconnectedUtills.customDialog(EditProfile.this, "Please Enter Valid Email Id");

					ed_contact_email.requestFocus();
				}
				else
				{
					if (WellconnectedUtills.isNetworkAvailable(EditProfile.this)) 
					{
						new EditupdateTask().execute();
					}
					else
					{
						WellconnectedUtills.customDialog(EditProfile.this, "Internet connection is not available");
					
					}
				}
			
			break;
		case R.id.linear_female:
			if(is_gender)
			{
				is_gender=false;
				linear_gender.setBackground(null);
				linear_gender.setBackgroundResource(R.drawable.gender_selection_female);
				gender="2";
			}
			else
			{
				is_gender=true;
				linear_gender.setBackgroundResource(R.drawable.gender_selection_male);
				
				gender="1";
				
			}
			
			break;
		case R.id.linear_male:
			if(is_gender)
			{
				is_gender=false;
				linear_gender.setBackground(null);
				linear_gender.setBackgroundResource(R.drawable.gender_selection_female);
				gender="2";
			}
			else
			{
				is_gender=true;
				linear_gender.setBackgroundResource(R.drawable.gender_selection_male);
				
				gender="1";
				
			}
			
			break;
		case R.id.ll_upload:
			InputMethodManager immm = (InputMethodManager)getSystemService(
				      EditProfile.this.INPUT_METHOD_SERVICE);
				immm.hideSoftInputFromWindow(v.getWindowToken(), 0);		

			showDialog(1);

			break;
		case R.id.img_age:
			
			InputMethodManager imm = (InputMethodManager)getSystemService(
				      this.INPUT_METHOD_SERVICE);
				imm.hideSoftInputFromWindow(ed_screenname.getWindowToken(), 0);
				
				
			Calendar calendar = Calendar.getInstance();
			int year = calendar.get(Calendar.YEAR);
			System.out.println("year"+year);
			int tilldate=year-100;
			ArrayList<String>year_arr=new ArrayList<String>();
			final String arr[]=new String[101];
			for(int i=0;i<=100;i++)
			{
				arr[i]=String.valueOf(year);
				year--;
			}
			
			
			  AlertDialog.Builder builder = new AlertDialog.Builder(EditProfile.this);
			    builder.setTitle("Select Age")
			           .setItems(arr, new DialogInterface.OnClickListener() {
			               public void onClick(DialogInterface dialog, int which) {
			               // The 'which' argument contains the index position
			               // of the selected item
			            	   
			            	   Age=arr[which];
			            	   
			            	   img_age.setText(Age);
			           }
			    });
			    builder.create();
			    builder.show();
			break;
		}
	}
	private boolean checkEmail(String email) {
		return EMAIL_ADDRESS_PATTERN.matcher(email).matches();
	}
	public class EditupdateTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		String response;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			try {
				progressDialog = ProgressDialog.show(EditProfile.this, "", "Please Wait");
							} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
		}
		@Override
		protected String doInBackground(String... params) {
			
			ArrayList<String> fileArrayList = new ArrayList<String>();
			//image file path name
			
			if(imageFilePath==null||imageFilePath.equals(""))
			{
				imageFilePath="";
				
				//download image in sd card 
				
			}
			else
			{
				File file = new File(imageFilePath);
				fileArrayList.add(file.getPath());
			}
				
			ArrayList<String[]> dataArrayList = new ArrayList<String[]>();
			//String[] a = new String[2];

		/*	a[0] = "device_os";
			a[1] = "android";
			dataArrayList.add(a);
*/
			String[] c = new String[2];

			c[0] = "user_id";
			c[1] = user_id;
			dataArrayList.add(c);

			String[] d = new String[2];

			d[0] = "email_id";
			d[1] = email_id ;
			dataArrayList.add(d);

			String[] e = new String[2];

			e[0] = "display_name";
			e[1] = display_name;
			dataArrayList.add(e);

			String[] f = new String[2];

			f[0] = "contactEmail";
			f[1] = contactEmail;
			dataArrayList.add(f);
		
			String[] fdevice_type = new String[2];

			fdevice_type[0] = "gender";
			fdevice_type[1] = gender;
			dataArrayList.add(fdevice_type);
			
			
			String[] fdob = new String[2];

			fdob[0] = "dob";
			fdob[1] = Age;
			dataArrayList.add(fdob);
			
			String[] fintro = new String[2];

			fintro[0] = "intro";
			fintro[1] = intro;
			dataArrayList.add(fintro);
			
			/*String[] fdevice_token = new String[2];

			fdevice_token[0] = "device_token";
			fdevice_token[1] = GCMRegistrar.getRegistrationId(RegisterActivity.this);
			dataArrayList.add(fdevice_token);
*/
			String URL = WellconnectedConstant.WEBSERVICE_URL + "edit_profile";
			MyApplication.is_edit_pic="0";
			//give image name
			
			 response=new JsonPostRequest1().doPostWithFile1(URL, dataArrayList, fileArrayList, "testimage", "png");
			System.out.println("response"+response);
			
				Log.i("gotResponseeeeeeee", response);
			
			
			return null;
		}
		/* (non-Javadoc)
		 * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
		 */
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			
			if(response!=null)
			{
				JSONObject object,object_res = null;
				try {
					object = new JSONObject(response);
					 object_res=object.getJSONObject("response");
					
				} catch (JSONException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				if(object_res.has("success"))
				{

				//	appDelegate.getChangePic().sendEmptyMessage(11);
					AlertDialog.Builder builder = new AlertDialog.Builder(EditProfile.this);
					// Add the buttons
					try {
						builder.setMessage(object_res.getString("success"));
						builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
					           public void onClick(DialogInterface dialog, int id) {
					               // User clicked OK button
					        	   finish();
					           }
					       });
//						MyApplication.is_edit_profile="1";
//						mGroupSearchMenuListener.onMenuClick();

						
					// Set other dialog properties
				
					// Create the AlertDialog
					AlertDialog dialog = builder.create();	
					dialog.show();
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
				
				}
				else
				{
					
					try {
						WellconnectedUtills.customDialog(EditProfile.this,object_res.getString("error"));
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
			}
		}
	}
	
	private void getImageInSDCard(String path)
	{
		URL url;
		try {
			url = new URL (path);
			InputStream input = url.openStream();
			try {
			    //The sdcard directory e.g. '/sdcard' can be used directly, or 
			    //more safely abstracted with getExternalStorageDirectory()
			    File storagePath = Environment.getExternalStorageDirectory();
			    OutputStream output = new FileOutputStream (new File(storagePath,"myImage.png"));
			    try {
			        byte[] buffer = new byte[5000];
			        int bytesRead = 0;
			        while ((bytesRead = input.read(buffer, 0, buffer.length)) >= 0) {
			            output.write(buffer, 0, bytesRead);
			        }
			    } finally {
			        output.close();
			    }
			} finally {
			    input.close();
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
