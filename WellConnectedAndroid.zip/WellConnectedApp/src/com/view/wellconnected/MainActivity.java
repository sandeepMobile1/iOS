package com.view.wellconnected;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.json.JSONObject;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SyncStatusObserver;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.KeyEvent;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.Request;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.SessionState;
import com.facebook.UiLifecycleHelper;
import com.facebook.Request.GraphUserCallback;
import com.facebook.model.GraphUser;
import com.view.wellconnected.LoginActivity2.FbLoginTask;
import com.wellconnected.bean.ChangePwdBase;
import com.wellconnected.bean.GroupSearchMenuListener;
import com.wellconnected.database.DataBaseManager;
import com.wellconnected.database.MatchDataSource;
import com.wellconnected.lazyload.ImageLoader_rounded;
import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.utills.MyApplication;
import com.wellconnected.utills.WellconnectedConstant;

public class MainActivity extends FragmentActivity implements GroupSearchMenuListener {
	MainLayout mLayout;
	private ListView lvMenu;
	Button btMenu;
	public String data[]={"Groups","Chats","Contacts","Settings","Help","Logout"};
    public int[] img={R.drawable.group_icon,R.drawable.chat_icon,R.drawable.contact_icon,R.drawable.setting_icon,R.drawable.hepl_icon,R.drawable.logout_icon};
    private SharedPreferences pref;
	TextView tvTitle,txt_new;
	private String contactCount,chatCount,user_name,user_image,current_screen="My group",user_id,groupCount;
	private ImageLoader_rounded img_loader;
	private String imageFilePath,imageType,device_token;
	private Bitmap bitmap;
	private OnDataPass mOnDataPass;
	private DataBaseManager dbhelper;
	private SQLiteDatabase mySqldb;
	private MatchDataSource datasourse;
	private UiLifecycleHelper uiHelper;
	private MyApplication appDelegate;
	private static final List<String> PERMISSIONS = Arrays.asList("email","user_friends", "user_location", "user_hometown", "friends_hometown", "friends_location","read_friendlists");
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		 
		WellconnectedConstant.ScreenName="";
		mLayout = (MainLayout) this.getLayoutInflater().inflate(R.layout.main_list, null);
		setContentView(mLayout);
		
		appDelegate = (MyApplication)getApplicationContext();	
		appDelegate.setChangePic(userChangePic);
		uiHelper = new UiLifecycleHelper(this, callback);
		uiHelper.onCreate(savedInstanceState);

		dbhelper=new DataBaseManager(MainActivity.this);
		mySqldb=dbhelper.getReadableDatabase();
		datasourse = new MatchDataSource(MainActivity.this);
		img_loader=new ImageLoader_rounded(MainActivity.this);
		pref = this.getSharedPreferences("LoginInfo", this.MODE_WORLD_READABLE);
		
		user_name=pref.getString("display_name", "");
		user_image=pref.getString("user_image", "");
		user_id=pref.getString("User_id", "");
		device_token=pref.getString("device_token", "");
		groupCount=pref.getString("groupCount", "");
		chatCount=pref.getString("chatCount", "");
		contactCount=pref.getString("contactCount", "");
		
		System.out.println("user_name"+user_name);
		txt_new = (TextView) findViewById(R.id.txt_new);
		
		txt_new.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if(current_screen.equals("My group"))
				{
					Intent intent=new Intent(MainActivity.this,StartGroupActivity.class);
					startActivity(intent);
					/*FragmentManager fm = MainActivity.this.getSupportFragmentManager();
					FragmentTransaction ft = fm.beginTransaction();
					Fragment fragment = null;

					fragment=new StartGroupFragment();
					mOnDataPass = (OnDataPass) fragment;
					
					if (fragment != null) {
						ft.replace(R.id.activity_main_content_fragment, fragment);
						ft.commit();
						tvTitle.setText("Start Group");
						
						txt_new.setVisibility(View.INVISIBLE);
					}*/
				}
				else if(current_screen.equals("Chat"))
				{
					Intent intent=new Intent(MainActivity.this,ContactActivity.class);
					startActivity(intent);
					
					
				}
				else if(current_screen.equals("Contacts"))
				{
					Intent intent=new Intent(MainActivity.this,AddContactActivity.class);
					startActivity(intent);
					
					/*FragmentManager fm = MainActivity.this.getSupportFragmentManager();
					FragmentTransaction ft = fm.beginTransaction();
					Fragment fragment = null;

					fragment=new AddContactFragment();
						if (fragment != null) {
						ft.replace(R.id.activity_main_content_fragment, fragment);
						ft.commit();
						tvTitle.setText("Add Contacts");
						
						txt_new.setVisibility(View.INVISIBLE);
					}*/
					
				}
				else if(current_screen.equals("MyProfile"))
				{
					Intent intent=new Intent( MainActivity.this,EditProfile.class);
					startActivity(intent);
					
				}
			}
		});
		lvMenu = (ListView) findViewById(R.id.menu_listview);
		tvTitle = (TextView) findViewById(R.id.activity_main_content_title);
		
		btMenu = (Button) findViewById(R.id.button_menu);
		
		lvMenu.setAdapter(new  MenuAdapter());
		
		lvMenu.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				onMenuItemClick(parent, view, position, id);
			}

		});

		
		btMenu.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// Show/hide the menu
				toggleMenu(v);
				InputMethodManager imm = (InputMethodManager)getSystemService(
					      MainActivity.this.INPUT_METHOD_SERVICE);
					imm.hideSoftInputFromWindow(v.getWindowToken(), 0);		}
		});
		
		current_screen="My group";
		FragmentManager fm = MainActivity.this.getSupportFragmentManager();
		FragmentTransaction ft = fm.beginTransaction();
		MyGroupListFragement fragment = new MyGroupListFragement();
		ft.add(R.id.activity_main_content_fragment, fragment);
		ft.commit();
		txt_new.setText("New");
		txt_new.setVisibility(View.VISIBLE);
	}
	private boolean hasEmailPermission() {

		Session session = Session.getActiveSession();

		return session != null && session.getPermissions().contains("email");

	}

	// Method for face book login
	private Session.StatusCallback callback = new Session.StatusCallback() {
		@Override
		public void call(Session session, final SessionState state, Exception exception) {

			if (session.isOpened()) {

				if (hasEmailPermission()) {

					Request.executeMeRequestAsync(session, new GraphUserCallback() {

						@Override
						public void onCompleted(GraphUser user, Response response) {
							System.out.println("user"+user);
							// TODO Auto-generated method stub
							if (user != null) {
								try {

									String registrantEmailSocial = response.getGraphObject().getInnerJSONObject().getString("email").toString();

									Log.d("registrantEmailSocial", registrantEmailSocial);

									String facebookID = user.getId();
									
									String fb_email = registrantEmailSocial;
									  
									String fb_username = user.getName();
								
									String  first_name =
									  user.getFirstName(); 
									String last_name =
									  user.getLastName();
									  
									  String stateName = "";
									 
									  String dob=user.getBirthday();
									//  String gender=user.get
									  String get_gender = (String) user.getProperty("gender");
									  
									String  imgurl="https://graph.facebook.com/"+user.getId()+"/picture?type=large";
									 // profile_url=imgurl; 
									
									  String facebook_friends="https://graph.facebook.com/"+user.getId()+"/friendlists";

								//	new FbLoginTask().execute(fb_email,facebookID,fb_username,dob,get_gender,imgurl);
									
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						}
					});
				} else if (!hasEmailPermission()) {
					session.requestNewPublishPermissions(new Session.NewPermissionsRequest(MainActivity.this, PERMISSIONS));

					Request request = Request.newStatusUpdateRequest(session, "Temple Hello Word Sample", new Request.Callback() {
						@Override
						public void onCompleted(Response response) {
							Log.d("", "fb:done = " + response.getGraphObject() + "," + response.getError());
						}
					});
					request.executeAsync();
				}

			}

		}
	};
	public class LogoutTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		ChangePwdBase chatbase;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(MainActivity.this, "", "Please Wait");
		}
		@Override
		protected String doInBackground(String... params) {
			
			// TODO Auto-generated method stub
			chatbase = WellconnectedParse.logout(MainActivity.this , user_id, device_token);
				//response=CCRApplicationParse.ChangePwd(ChangePasswordActivity.this, user_id, ed_password.getText().toString(), ed_new_pwd.getText().toString());
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			if (chatbase != null) {
				if (chatbase.getResponse()==null) {
					//WellconnectedUtills.customDialog(ChangePasswordActivity.this, chatbase.getResponse().getError());

				} else {
					
					
					SharedPreferences.Editor editor = pref.edit();
					editor.clear();
					editor.commit();
					
					datasourse.emptyDatabase();
					
					Intent intent=new Intent(MainActivity.this,LoginScreen.class);
					startActivity(intent);
					finish();
					//WellconnectedUtills.customDialog_2(MainActivity.this, chatbase.getResponse().getSuccess(),MainActivity.this);
				}
			}
		}
	}
	class MenuAdapter extends BaseAdapter
	{
  private boolean is_click=false;
		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return data.length+1;
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			View row=null;
			
			if(position==0)
			{
				 row=View.inflate(MainActivity.this,R.layout.menu_row_1, null);
				 TextView txt_name=(TextView) row.findViewById(R.id.txt_name);
				 txt_name.setText(user_name);
				 ImageView img_icon=(ImageView) row.findViewById(R.id.img_icon);
				 System.out.println("USER_IMAGE"+WellconnectedConstant.IMAGE_URL_1+user_image);
				 img_loader.DisplayImage(WellconnectedConstant.IMAGE_URL_1+user_image, img_icon);
				 
			}
			else if(position==1)
			{
				 row=View.inflate(MainActivity.this,R.layout.menu_row_2, null);
				 final LinearLayout linear_container=(LinearLayout) row.findViewById(R.id.linear_container);
				 RelativeLayout linear_group_count=(RelativeLayout) row.findViewById(R.id.linear_group_count);
				 TextView txt_group_count=(TextView) row.findViewById(R.id.txt_group_count);
				 
				 if(groupCount.equals("0")||groupCount.equals("null"))
				 {
					 linear_group_count.setVisibility(View.GONE);
				 }
				 else
				 {
					 txt_group_count.setText(groupCount);
					 linear_group_count.setVisibility(View.VISIBLE);
				 }
				 is_click=true;
				linear_container.setVisibility(View.VISIBLE);
					
				 LinearLayout linear_group=(LinearLayout) row.findViewById(R.id.linear_group);
				 
				 LinearLayout linear_mygroup=(LinearLayout) row.findViewById(R.id.linear_mygroup);
				 linear_mygroup.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View arg0) {
						// TODO Auto-generated method stub
						FragmentManager fm = MainActivity.this.getSupportFragmentManager();
						FragmentTransaction ft = fm.beginTransaction();
						Fragment fragment = null;
						
						current_screen="My group";
						fragment = new MyGroupListFragement();
						tvTitle.setText("My Groups");
						txt_new.setText("New");
						txt_new.setVisibility(View.VISIBLE);
						if (fragment != null) {
								ft.replace(R.id.activity_main_content_fragment, fragment);
								ft.commit();
							//	tvTitle.setText(selectedItem);
							}
						
						mLayout.toggleMenu();
					}
				});
				 
				 LinearLayout linear_manage_group=(LinearLayout) row.findViewById(R.id.linear_manage_group);
				 LinearLayout linear_add_new_group=(LinearLayout) row.findViewById(R.id.linear_add_new_group);
				 linear_add_new_group.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View arg0) {
						// TODO Auto-generated method stub
						FragmentManager fm = MainActivity.this.getSupportFragmentManager();
						FragmentTransaction ft = fm.beginTransaction();
						Fragment fragment = null;
					
						fragment = new StartGroupFragment();
						mOnDataPass = (OnDataPass) fragment;
						tvTitle.setText("Start Group");
						
						if (fragment != null) {
								ft.replace(R.id.activity_main_content_fragment, fragment);
								ft.commit();
							//	tvTitle.setText(selectedItem);
								
								txt_new.setVisibility(View.INVISIBLE);
							}
						
						mLayout.toggleMenu();
					}
				});
				 linear_group.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						
						if(is_click)
						{
							is_click=false;
							linear_container.setVisibility(View.GONE);
						}
						else
						{
							is_click=true;
							linear_container.setVisibility(View.VISIBLE);
						}
						System.out.println("CLCICKK");
						
					}
				});
				 
				 TextView txt_menu=(TextView) row.findViewById(R.id.txt_menu);
					txt_menu.setText(data[position-1]);
					ImageView img_icon=(ImageView) row.findViewById(R.id.img_icon);
					img_icon.setBackgroundResource(img[position-1]);
				
			}
			else
			{
				 row=View.inflate(MainActivity.this,R.layout.menu_row, null);
					TextView txt_menu=(TextView) row.findViewById(R.id.txt_menu);
					txt_menu.setText(data[position-1]);
					
					TextView txt_count=(TextView) row.findViewById(R.id.txt_count);
					
					
					RelativeLayout linear_btn=(RelativeLayout) row.findViewById(R.id.linear_btn);
					
					 
					 if(data[position-1].equals("Chats"))
					 {
						 if(chatCount.equals("0")||chatCount.equals("null"))
						 {
							 linear_btn.setVisibility(View.GONE);
						 }
						 else
						 {
							 linear_btn.setVisibility(View.VISIBLE);
						 }
						 txt_count.setText(chatCount);
							
					 }
					 else if(data[position-1].equals("Contacts"))
					 {
						 if(contactCount.equals("0")||contactCount.equals("null"))
						 {
							 linear_btn.setVisibility(View.GONE);
						 }
						 else
						 {
							 linear_btn.setVisibility(View.VISIBLE);
						 }
						 txt_count.setText(contactCount);
							
					 }
					 
					 
					ImageView img_icon=(ImageView) row.findViewById(R.id.img_icon);
					img_icon.setBackgroundResource(img[position-1]);
			}
			return row;
		}
	}
	
	public void toggleMenu(View v) {
		mLayout.toggleMenu();
	}

	
	private void onMenuItemClick(AdapterView<?> parent, View view,
			int position, long id) {
		
		System.out.println("position"+position);
		
		if(position==0)
		{
			//my profile with  fragment
			
			
			FragmentManager fm = MainActivity.this.getSupportFragmentManager();
			FragmentTransaction ft = fm.beginTransaction();
			Fragment fragment = null;
			current_screen="My Profile";


			fragment = new MyProfileFragment();
			
			tvTitle.setText("My Profile");
			txt_new.setVisibility(View.VISIBLE);
			txt_new.setText("Edit");
			current_screen="MyProfile";
			if (fragment != null) {
				ft.replace(R.id.activity_main_content_fragment, fragment);
				ft.commit();
				tvTitle.setText(user_name);
			}
			
			mLayout.toggleMenu();
		}
		else
		{
			String selectedItem = data[position-1];
			String currentItem = tvTitle.getText().toString();
			if (selectedItem.compareTo(currentItem) == 0) {
				mLayout.toggleMenu();
				return;
			}

			FragmentManager fm = MainActivity.this.getSupportFragmentManager();
			FragmentTransaction ft = fm.beginTransaction();
			Fragment fragment = null;
			current_screen="My group";
			
			if (selectedItem.compareTo("Layout 1") == 0) {
				fragment = new MyGroupListFragement();
				txt_new.setVisibility(View.VISIBLE);
			} else if (selectedItem.compareTo("Layout 2") == 0) {
			//	fragment = new Layout2();
				fragment = new ChatInfoFragment();
			} 
		//	if(position!=0)
			//{
				if(data[position-1].equals("Chats"))
				{
					fragment = new ChatInfoFragment();
					tvTitle.setText("Chats");
					txt_new.setText("Add");
					txt_new.setVisibility(View.VISIBLE);
					
					current_screen="Chat";
				}
				else if(data[position-1].equals("Settings"))
				{
					fragment = new SettingListFragment();
					tvTitle.setText("Settings");
					txt_new.setVisibility(View.INVISIBLE);
					current_screen="";
					
				}
				else if(data[position-1].equals("Help"))
				{
					fragment = new HelpFragment();
					tvTitle.setText("Help");
					txt_new.setVisibility(View.INVISIBLE);
					current_screen="";
				}
				else if(data[position-1].equals("Contacts"))
				{
					fragment = new ContactListFragment();
					
					tvTitle.setText("Contacts");
					txt_new.setVisibility(View.VISIBLE);
					txt_new.setText("Add");
					current_screen="Contacts";
			
				}
				else if(data[position-1].equals("Logout"))
				{
					final Dialog dialog=new Dialog(MainActivity.this);
					dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
					dialog.setContentView(R.layout.logout_popup);
					Button btn_no=(Button) dialog.findViewById(R.id.btn_no);
					btn_no.setOnClickListener(new OnClickListener() {
						
						@Override
						public void onClick(View arg0) {
							// TODO Auto-generated method stub
							dialog.cancel();
						}
					});
					
					Button btn_yes=(Button) dialog.findViewById(R.id.btn_yes);
					btn_yes.setOnClickListener(new OnClickListener() {
						
						@Override
						public void onClick(View arg0) {
							// TODO Auto-generated method stub
						new LogoutTask().execute();
						
						dialog.cancel();
						}
					});
					dialog.show();
					
					current_screen="";
			
				}
				if(data[position-1].equals("Logout"))
				{
					
				}
				else
				{
					if (fragment != null) {
						ft.replace(R.id.activity_main_content_fragment, fragment);
						ft.commit();
						mLayout.toggleMenu();
					//	tvTitle.setText(selectedItem);
					}
				}
				
			//}
		}
		
	
	}
	
	public interface OnDataPass {
		
	    public void onDataPass(Bitmap data,String image_path);
	    
	}
		@Override
	protected void onActivityResult(int requestCode,int resultCode,Intent data)
	{				
		super.onActivityResult(requestCode, resultCode, data);
		
		Fragment attachech =getSupportFragmentManager().findFragmentById(R.id.activity_main_content_fragment);
		
		if(attachech instanceof StartGroupFragment)
		{
			System.out.println("true");
			
			if(resultCode==Activity.RESULT_OK)
			{
				if(requestCode==1) 
				{
					try 
					{				
						Uri selectedimage = data.getData();
						String[] filepathcolumn = {MediaStore.Images.Media.DATA};

						Cursor cursor =MainActivity.this.getContentResolver().query(selectedimage,filepathcolumn, null, null, null);
						cursor.moveToFirst();

						int columnindex = cursor.getColumnIndex(filepathcolumn[0]);
						
						imageFilePath = cursor.getString(columnindex);				
						
					 imageType = imageFilePath.substring(imageFilePath.lastIndexOf(".") + 1);										
						
						cursor.close();
						
						FileInputStream in;
						
						try 
						{
							in = new FileInputStream(imageFilePath);
							
							BitmapFactory.Options options = new BitmapFactory.Options();
							options.inSampleSize = 4;
							 bitmap = BitmapFactory.decodeStream(in,null,options);
							
							//img_user_pic.setImageBitmap(bitmap);
							//img_pic_1.setImageBitmap(WellconnectedUtills.getRoundedShape(bitmap));
						}
						catch (Exception e) 
						{
							Log.e("Error reading file", e.toString());
							
							if(e instanceof FileNotFoundException)
							{
								Toast.makeText(MainActivity.this,"Network Synchronized Image Does Not Exists", Toast.LENGTH_SHORT).show();
							}
						}				
					} 				
					catch (Exception e) 
					{					
						e.printStackTrace();
						
						if(e instanceof FileNotFoundException)
						{
							Toast.makeText(MainActivity.this,"Network Synchronized Image Does Not Exists", Toast.LENGTH_SHORT).show();
						}
					}
				}
				else if (requestCode == 2) 
				{			
					File Imagedirectory = new File(Environment.getExternalStorageDirectory()+ "/MyImage");
					if (!Imagedirectory.exists()) 
					{
						Imagedirectory.mkdir();
					}

					int quality = 5;
					String ssss = UUID.randomUUID().toString();
					File file = new File(Imagedirectory.getPath() + "/" + ssss + ".png");
					
					imageFilePath=file.getPath();
					imageType="png";
					
					try 
					{
						if (data.getExtras() != null) 
						{
							bitmap = (Bitmap) data.getExtras().get("data");

							try 
							{
								file.createNewFile();
								FileOutputStream fileOutputStream = new FileOutputStream(file);
								BufferedOutputStream bos = new BufferedOutputStream(fileOutputStream);
								bitmap.compress(CompressFormat.PNG, quality, bos);
								
								//img_user_pic.setImageBitmap(bitmap);
								//img_pic_1.setImageBitmap(WellconnectedUtills.getRoundedShape(bitmap));
										bos.flush();
								bos.close();
							} 
							catch (Exception e) 
							{
								e.printStackTrace();
							}												
						}
						
						
					} 
					catch (Exception e) 
					{
						e.printStackTrace();
					}			
				}		
				 
				mOnDataPass.onDataPass(bitmap,imageFilePath);
			}
		}
		else
		{
			uiHelper.onActivityResult(requestCode, resultCode, data);

			System.out.println("false");
			
		}
				
	}
		
	
	@Override
	public void onBackPressed() {
	
		FragmentManager fm = getSupportFragmentManager();
		Fragment fragment_byID = fm.findFragmentById(R.id.activity_main_content_fragment);


		System.out.println("fragment_byID===="+fragment_byID);
		
		if(fragment_byID instanceof MyGroupListFragement&&WellconnectedConstant.is_drawer_closed.equals("0"))
		{
			System.out.println("IFCLOUSE====");
			
			
			MyGroupListFragement.onBack();
		}
		else
		{
			if (mLayout.isMenuShown()) {
				mLayout.toggleMenu();
			} else {
				super.onBackPressed();
				moveTaskToBack(true);
			}
		}
		
	}
	
	private Handler userChangePic = new Handler(){
		
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			
			System.out.println("User Change Pick");
			groupCount=pref.getString("groupCount", "");
			user_image=pref.getString("user_image", "");
			contactCount=pref.getString("contactCount", "");
			chatCount=pref.getString("chatCount", "");
			
			lvMenu.setAdapter(new  MenuAdapter());
		}
	};
	@Override
	public void onMenuClick() {
		
		if(MyApplication.is_edit_profile.equals("1"))
		{
			MyApplication.is_edit_profile="0";
			user_image=pref.getString("user_image", "");
			lvMenu.setAdapter(new  MenuAdapter());
		
		}
		else
		{
			if (mLayout != null) {
				mLayout.toggleMenu();
			} 
		}
		
		
	}
}

