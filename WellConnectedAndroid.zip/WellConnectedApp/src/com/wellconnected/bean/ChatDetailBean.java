package com.wellconnected.bean;

import java.util.ArrayList;

public class ChatDetailBean {
	public String unreadCount;
	public String getUnreadCount() {
		return unreadCount;
	}


	public void setUnreadCount(String unreadCount) {
		this.unreadCount = unreadCount;
	}


	public ArrayList<ChatDetail>ChatDetail;
	
	
	public ArrayList<ChatDetail> getChatDetail() {
		return ChatDetail;
	}


	public void setChatDetail(ArrayList<ChatDetail> chatDetail) {
		ChatDetail = chatDetail;
	}


	public static class ChatDetail
	{
		public String getGroupType() {
			return groupType;
		}
		public void setGroupType(String groupType) {
			this.groupType = groupType;
		}
		public String getChattype() {
			return Chattype;
		}
		public void setChattype(String chattype) {
			Chattype = chattype;
		}
		public String getChatStatus() {
			return chatStatus;
		}
		public void setChatStatus(String chatStatus) {
			this.chatStatus = chatStatus;
		}
		public String getRequest_status() {
			return request_status;
		}
		public void setRequest_status(String request_status) {
			this.request_status = request_status;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getIndividualCount() {
			return individualCount;
		}
		public void setIndividualCount(String individualCount) {
			this.individualCount = individualCount;
		}
		public String getDate() {
			return date;
		}
		public void setDate(String date) {
			this.date = date;
		}
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
		public String getCreated() {
			return created;
		}
		public void setCreated(String created) {
			this.created = created;
		}
		public String getFriend_image() {
			return friend_image;
		}
		public void setFriend_image(String friend_image) {
			this.friend_image = friend_image;
		}
		public String getFriend_id() {
			return friend_id;
		}
		public void setFriend_id(String friend_id) {
			this.friend_id = friend_id;
		}
		public String getMsgId() {
			return msgId;
		}
		public void setMsgId(String msgId) {
			this.msgId = msgId;
		}
		public String getFriend_name() {
			return friend_name;
		}
		public void setFriend_name(String friend_name) {
			this.friend_name = friend_name;
		}
		public String getThread_id() {
			return thread_id;
		}
		public void setThread_id(String thread_id) {
			this.thread_id = thread_id;
		}
		public String groupType;
		public String Chattype;
		//public String static;
		public String chatStatus;
		public String request_status;
		public String status;
		public String individualCount;
		public String date;
		public String message;
		public String created;
		public String friend_image;
		public String friend_id;
		public String msgId;
		public String friend_name;
		public String thread_id;
		
		
		public String groupName;
		public String threadId;
		public String groupId;
		public String groupOwnerId;

		public String groupImage;
		public String groupUserTableId;
		public String special;
		public String paidStatus;
		
		public String subCharge;
		public String parent_id;
		public String getGroupName() {
			return groupName;
		}
		public void setGroupName(String groupName) {
			this.groupName = groupName;
		}
		public String getThreadId() {
			return threadId;
		}
		public void setThreadId(String threadId) {
			this.threadId = threadId;
		}
		public String getGroupId() {
			return groupId;
		}
		public void setGroupId(String groupId) {
			this.groupId = groupId;
		}
		public String getGroupOwnerId() {
			return groupOwnerId;
		}
		public void setGroupOwnerId(String groupOwnerId) {
			this.groupOwnerId = groupOwnerId;
		}
		public String getGroupImage() {
			return groupImage;
		}
		public void setGroupImage(String groupImage) {
			this.groupImage = groupImage;
		}
		public String getGroupUserTableId() {
			return groupUserTableId;
		}
		public void setGroupUserTableId(String groupUserTableId) {
			this.groupUserTableId = groupUserTableId;
		}
		public String getSpecial() {
			return special;
		}
		public void setSpecial(String special) {
			this.special = special;
		}
		public String getPaidStatus() {
			return paidStatus;
		}
		public void setPaidStatus(String paidStatus) {
			this.paidStatus = paidStatus;
		}
		public String getSubCharge() {
			return subCharge;
		}
		public void setSubCharge(String subCharge) {
			this.subCharge = subCharge;
		}
		public String getParent_id() {
			return parent_id;
		}
		public void setParent_id(String parent_id) {
			this.parent_id = parent_id;
		}
		
		
	}
	
	
	
	

}
