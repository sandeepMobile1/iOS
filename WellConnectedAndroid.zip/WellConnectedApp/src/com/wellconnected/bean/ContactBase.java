package com.wellconnected.bean;

public class ContactBase {

	private ContactsuccessBase response;

	public ContactsuccessBase getResponse() {
		return response;
	}

	public void setResponse(ContactsuccessBase response) {
		this.response = response;
	}
	
}
