package com.wellconnected.bean;

import java.util.ArrayList;

public class ContactBean {
	public ArrayList<contacts>contacts;
	
	

	public ArrayList<contacts> getContacts() {
		return contacts;
	}



	public void setContacts(ArrayList<contacts> contacts) {
		this.contacts = contacts;
	}



	public static class contacts
	{
		
		public String id;
		public String user_name;
		public String user_id;
		public String request_status;
		public String intro;
		public String user_image;
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getUser_name() {
			return user_name;
		}
		public void setUser_name(String user_name) {
			this.user_name = user_name;
		}
		public String getUser_id() {
			return user_id;
		}
		public void setUser_id(String user_id) {
			this.user_id = user_id;
		}
		public String getRequest_status() {
			return request_status;
		}
		public void setRequest_status(String request_status) {
			this.request_status = request_status;
		}
		public String getIntro() {
			return intro;
		}
		public void setIntro(String intro) {
			this.intro = intro;
		}
		public String getUser_image() {
			return user_image;
		}
		public void setUser_image(String user_image) {
			this.user_image = user_image;
		}
		
	}
		
	}
	
	
	
	


