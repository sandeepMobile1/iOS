package com.view.wellconnected;


import java.io.File;
import java.util.ArrayList;
import java.util.Random;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.view.wellconnected.MainActivity.OnDataPass;
import com.wellconnected.utills.JsonPostRequest1;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

public class StartGroupFragment extends Fragment implements OnClickListener, OnDataPass{
	
	private LinearLayout ll_upload;
	private EditText ed_title,ed_about;
	private Button btn_member,btn_detail,btn_done;
	private String imageFilePath,imageType,user_id,
	group_title,random_Number,periodType="Monthly",subscriptionPeriod="0 month",subscriptionCharge="1",groupIntro;
	private Bitmap bitmap;
	private ImageView img_pic_1;
	private   AlertDialog.Builder builder_1;
	OnDataPass dataPasser;
	
	
	@Override
	public void onAttach(Activity activity) {
		// TODO Auto-generated method stub
		super.onAttach(activity);
		
		//dataPasser = (OnDataPass) activity;
		
	//	System.out.println("dataPasser"+dataPasser);
		
	}
	
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		
		View view = inflater.inflate(R.layout.startgroup_screen, null);
		
		WellconnectedConstant.ScreenName="";
		img_pic_1=(ImageView)view. findViewById(R.id.img_pic_1);
		
		SharedPreferences	pref = getActivity().getSharedPreferences("LoginInfo", getActivity().MODE_WORLD_READABLE);
			
		user_id=pref.getString("User_id", "");
		
		
			ll_upload=(LinearLayout)view. findViewById(R.id.ll_upload);
			ll_upload.setOnClickListener(this);
			
			ed_title=(EditText)view. findViewById(R.id.ed_title);
			
			ed_about=(EditText)view. findViewById(R.id.ed_about);
			
			btn_member=(Button)view. findViewById(R.id.btn_member);
			btn_member.setOnClickListener(this);
			
			btn_detail=(Button) view.findViewById(R.id.btn_detail);
			btn_detail.setOnClickListener(this);
			builder_1 = new AlertDialog.Builder(getActivity());
			builder_1.setTitle("Make your selection");
			
			btn_done=(Button) view.findViewById(R.id.btn_done);
			btn_done.setOnClickListener(this);
			
					 random_Number=getRandomNumber();
					
					System.out.println("Number"+random_Number);
		
		return view;
         
	}
	public String getRandomNumber()
	{
		
		char[] chars = "abcdefghijklmnopqrstuvwxyz0123456789".toCharArray();
		StringBuilder sb = new StringBuilder();
		Random random = new Random();
		for (int i = 0; i < 40; i++) {
		    char c = chars[random.nextInt(chars.length)];
		    sb.append(c);
		}
		String output = sb.toString();
		System.out.println(output);
		return output;
	}
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		
	}
	public Dialog onCreateDialog(int id,final Bundle args)
	{
		AlertDialog dialog=null;
		switch(id)
		{					
			/*case 0: 
			{
				return new DatePickerDialog(this, datePickerListener,Integer.parseInt(year), Integer.parseInt(month),Integer.parseInt(day));
			}	*/
			case 1:
			{
				String options[];
				               
				options=new String[]{"Gallery","Camera"};
				
				AlertDialog.Builder builder=new AlertDialog.Builder(getActivity());
				builder.setSingleChoiceItems(options,-1, new DialogInterface.OnClickListener() 
				{					
					@Override
					public void onClick(DialogInterface dialog, int which) 
					{
						if(which==0)
						{							
							try 
							{
								Intent i = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI);
								startActivityForResult(i, 1);
							} 
							catch (Exception e) 
							{
								 e.printStackTrace();
							}
						}
						else if(which == 1)
						{														
							try 
							{
								Intent i = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
								startActivityForResult(i, 2);
							}
							catch (Exception e) 
							{
								 e.printStackTrace();
							}
						}						
						//removeDialog(1);
					}					
				}).setTitle("Take Image From");
				
				dialog=builder.create();
				break;
			}			
			default:
			{
				break;
			}
		}
		return dialog;
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId())
		{
		case R.id.btn_done:
			
			
			 group_title=ed_title.getText().toString();
			 groupIntro=ed_about.getText().toString();
			
			if(group_title.equals(""))
			{
				WellconnectedUtills.customDialog(getActivity(), "Please enter group title");
				
			}
			else if(group_title.length()<4)
			{
				WellconnectedUtills.customDialog(getActivity(), "Group title should be at least 4 Characters and maximum 40 Characters");
				
			}
			else if(group_title.length()>40)
			{
				WellconnectedUtills.customDialog(getActivity(), "Group title should be at least 4 Characters and maximum 40 Characters");
				
			}
			else if(groupIntro.equals(""))
			{
				WellconnectedUtills.customDialog(getActivity(), "Please enter group intro");
				
			}
			else
			{
				

				if (WellconnectedUtills.isNetworkAvailable(getActivity())) {
					new NewGroupTask().execute();

				} else {
					WellconnectedUtills.customDialog(getActivity(), "Internet connection is not available");

				}
			}
			break;
		case R.id.btn_detail:
			
			final Dialog dialog = new Dialog(getActivity());
			dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
			dialog.setContentView(R.layout.detail_popup);

			Button btn_ok = (Button) dialog.findViewById(R.id.btn_ok);
			btn_ok.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					dialog.dismiss();
				}
			});

			Button btn_cancel = (Button) dialog.findViewById(R.id.btn_cancel);
			btn_cancel.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					dialog.dismiss();
					
					subscriptionPeriod="1 Month";
					
					subscriptionCharge="1";
					
					periodType="Monthly";
				}
			});

			
			
			RelativeLayout rl_amount = (RelativeLayout) dialog
			.findViewById(R.id.rl_amount);
			
			final TextView txt_amount = (TextView) dialog
					.findViewById(R.id.txt_amount);

			rl_amount.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					/*final CharSequence[] items;
					items=new CharSequence[101];
					for(int i=0;i<=100;i++)
					{
						items[i]=i+""+"$";
						
					}
*/
					final String [] items={"$1","$2","$5","$10","$20","$50","$100"};
					
					final String [] itemss={"1","2","5","10","20","50","100"};
					
					
					builder_1.setItems(items,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int item) {
									// Do something with the selection
									txt_amount.setText(items[item]);
									
									subscriptionCharge=itemss[item].toString();
								}
							});
					AlertDialog alert = builder_1.create();
					alert.show();

				}
			});
			
			final TextView txt_time = (TextView) dialog
					.findViewById(R.id.txt_time);

			RelativeLayout rl_time = (RelativeLayout) dialog
					.findViewById(R.id.rl_time);
			rl_time.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					final CharSequence[] items = { "0 month", "1 month",
							"2 month", "3 month", "4 month", "5 month",
							"6 month", "7 month", "8 month", "9 month",
							"10 month", "11 month", "12 month" };

					builder_1.setItems(items,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int item) {
									// Do something with the selection
									txt_time.setText(items[item]);
									
									subscriptionPeriod=items[item].toString();
								}
							});
					AlertDialog alert = builder_1.create();
					alert.show();

				}
			});
			final TextView txt_type = (TextView) dialog
					.findViewById(R.id.txt_type);

			RelativeLayout rl_type = (RelativeLayout) dialog
					.findViewById(R.id.rl_type);
			rl_type.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					final CharSequence[] items = { "Monthly", "Annual" };

					builder_1.setItems(items,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int item) {
									// Do something with the selection
									txt_type.setText(items[item]);
									periodType=items[item].toString();
								}
							});
					AlertDialog alert = builder_1.create();
					alert.show();

				}
			});

			dialog.show();
			break;
		case R.id.btn_member:
			
			   final CharSequence[] items = {
					   "Paid", "Free"
		        };

		        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		        builder.setTitle("Make your selection");
		        builder.setItems(items, new DialogInterface.OnClickListener() {
		            public void onClick(DialogInterface dialog, int item) {
		                // Do something with the selection
		            	btn_member.setText(items[item]);
		            }
		        });
		        AlertDialog alert = builder.create();
		        alert.show();
			break;
		case R.id.ll_upload:
			
			//showDialog(1);
			final InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(getActivity().INPUT_METHOD_SERVICE);
		    imm.hideSoftInputFromWindow(getView().getWindowToken(), 0);
		
			String options[];
			               
			options=new String[]{"Gallery","Camera"};
				
			AlertDialog.Builder builder_1=new AlertDialog.Builder(getActivity());
			
			  	
			builder_1.setSingleChoiceItems(options,-1, new DialogInterface.OnClickListener() 
			{					
				@Override
				public void onClick(DialogInterface dialog, int which) 
				{
					if(which==0)
					{							
						try 
						{
							Intent i = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI);
							getActivity().startActivityForResult(i, 1);
						} 
						catch (Exception e) 
						{
							 e.printStackTrace();
						}
					}
					else if(which == 1)
					{														
						try 
						{
							Intent i = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
							getActivity().startActivityForResult(i, 1);
								}
						catch (Exception e) 
						{
							 e.printStackTrace();
						}
					}	
					dialog.cancel();
				//	removeDialog(1);
				}					
			}).setTitle("Take Image From");
			AlertDialog alert_1 = builder_1.create();
			
			 alert_1.show();
				break;
		

			
		}
	}
	

	
	public class NewGroupTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		String response;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(getActivity(), "", "Please Wait");
			
		}

		@Override
		protected String doInBackground(String... params) {
			
			ArrayList<String> fileArrayList = new ArrayList<String>();
			//image file path name
			
			if(imageFilePath==null||imageFilePath.equals(""))
			{
				imageFilePath="";
			}
			else
			{
				File file = new File(imageFilePath);
				
				fileArrayList.add(file.getPath());

			}
				
			ArrayList<String[]> dataArrayList = new ArrayList<String[]>();
				String[] c = new String[2];

			c[0] = "userId";
			c[1] = user_id;
			dataArrayList.add(c);

			String[] d = new String[2];

			d[0] = "groupTitle";
			d[1] = group_title ;
			dataArrayList.add(d);

			String[] e = new String[2];

			e[0] = "groupIntro";
			e[1] = groupIntro;
			dataArrayList.add(e);

			String[] f = new String[2];

			f[0] = "subscriptionCharge";
			f[1] = subscriptionCharge;
			dataArrayList.add(f);

			System.out.println("subscriptionCharge"+subscriptionCharge);
		
			String[] fdevice_type = new String[2];

			fdevice_type[0] = "subscriptionPeriod";
			fdevice_type[1] = subscriptionPeriod;
			dataArrayList.add(fdevice_type);

			String[] g = new String[2];

			g[0] = "groupMember";
			g[1] = "";
			dataArrayList.add(g);

			
			String[] h = new String[2];

			h[0] = "threadId";
			h[1] = random_Number;
			dataArrayList.add(h);

			String[] i = new String[2];

			i[0] = "groupType";
			i[1] = "public";
			dataArrayList.add(i);

			
			String[] j = new String[2];

			j[0] = "periodType";
			j[1] = periodType;
			dataArrayList.add(j);

		
			String URL = WellconnectedConstant.WEBSERVICE_URL + "create_group";
			
			//give image name
			
			 response=new JsonPostRequest1().doPostWithFile1(URL, dataArrayList, fileArrayList, "testimage", "png");
			System.out.println("response"+response);
			
				Log.i("gotResponseeeeeeee", response);
			
			
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			
			if(response!=null)
			{
				JSONObject object,object_res = null;
				try {
					object = new JSONObject(response);
					 object_res=object.getJSONObject("response");
					
				} catch (JSONException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				if(object_res.has("success"))
				{
					
			
					try {
						
						String group_id=object_res.getString("groupId");
						String groupCode=object_res.getString("groupCode");
						
						
						WellconnectedUtills.customDialog(getActivity(),/*object_res.getString("message")*/"Group created successfully");
						
						//WellconnectedUtills.customDialog_2(getActivity(),object_res.getString("message"),getActivity());
						
						} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
				//	finish();
				}
				else
				{
					
					try {
						WellconnectedUtills.customDialog(getActivity(),object_res.getString("error"));
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
					
				}
				
			
			}
			
		}
	}

	@Override
	public void onDataPass(Bitmap data,String image_path) {
		// TODO Auto-generated method stub
		System.out.println("DATTTTTTAAA"+data);
		System.out.println("image_path"+image_path);
		imageFilePath=image_path;
		
		
		img_pic_1.setImageBitmap(WellconnectedUtills.getRoundedShape(data));
		
	}

	
	
}
