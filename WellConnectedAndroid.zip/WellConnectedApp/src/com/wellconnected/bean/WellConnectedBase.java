package com.wellconnected.bean;

public class WellConnectedBase {

	private WellconnectedUserBean response;

	public WellconnectedUserBean getresponse() {
		return response;
	}

	public void setresponse(WellconnectedUserBean response) {
		this.response = response;
	}

	
	
}
