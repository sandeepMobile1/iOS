package com.wellconnected.utills;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import android.util.Base64;
import android.util.Log;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.InvalidAlgorithmParameterException;
import java.security.spec.AlgorithmParameterSpec;

public class AES256Cipher {

	public static byte[] encrypt(byte[] ivBytes, byte[] keyBytes,
			byte[] textBytes) throws java.io.UnsupportedEncodingException,
			NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException, InvalidAlgorithmParameterException,
			IllegalBlockSizeException, BadPaddingException {

		AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);
		SecretKeySpec newKey = new SecretKeySpec(keyBytes, "AES");
		Cipher cipher = null;
		cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");

		// cipher = Cipher.getInstance("AES");

		cipher.init(Cipher.ENCRYPT_MODE, newKey, ivSpec);
		return cipher.doFinal(textBytes);
	}

	public static byte[] decrypt(byte[] ivBytes, byte[] keyBytes,
			byte[] textBytes) throws java.io.UnsupportedEncodingException,
			NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException, InvalidAlgorithmParameterException,
			IllegalBlockSizeException, BadPaddingException {

		AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);
		SecretKeySpec newKey = new SecretKeySpec(keyBytes, "AES");
		 Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");

//		Cipher cipher = Cipher.getInstance("AES");

		cipher.init(Cipher.DECRYPT_MODE, newKey, ivSpec);
		return cipher.doFinal(textBytes);
	}
	
	
	public static String ecrypt(String orgStr,String KEY) {

		try {

			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			byte[] keyBytes = new byte[16];
			byte[] b = KEY.getBytes("UTF-8");
			int len = b.length;

			if (len > keyBytes.length) {
				len = keyBytes.length;
			}

			System.arraycopy(b, 0, keyBytes, 0, len);
			SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");
			cipher.init(Cipher.ENCRYPT_MODE, keySpec);

			byte[] input = orgStr.getBytes("UTF-8");
			byte[] results = cipher.doFinal(input);
			byte[] textBytes = android.util.Base64.encode(results,
					android.util.Base64.DEFAULT);

			return new String(textBytes, "UTF-8");

		} catch (Exception e) {
			Log.d("decryption", e.getMessage());
		}

		return "";
	}
	public static String decrypt(String encrText,String KEY) {

		try {

			Cipher cipher = Cipher.getInstance("AES/ECB/NoPadding");
			byte[] keyBytes = new byte[16];
			byte[] b = KEY.getBytes("UTF-8");
			int len = b.length;

			if (len > keyBytes.length) {
				len = keyBytes.length;
			}

			System.arraycopy(b, 0, keyBytes, 0, len);
			SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");
			cipher.init(Cipher.DECRYPT_MODE, keySpec);

			byte[] results = cipher.doFinal(Base64.decode(encrText, 0));

			return new String(results, "UTF-8");

		} catch (Exception e) {
			Log.d("decryption", e.getMessage());

		}

		return "";
	}
	
}
