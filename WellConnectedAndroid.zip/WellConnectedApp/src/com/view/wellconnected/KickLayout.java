package com.view.wellconnected;

import java.security.acl.Owner;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.view.wellconnected.AboutUsActivity.AboutUsTask;
import com.view.wellconnected.PhoneContect.sendPhoneNoTask;
import com.wellconnected.bean.AboutUsBase;
import com.wellconnected.bean.GropUserData;
import com.wellconnected.lazyload.ImageLoader_rounded;
import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;


public class KickLayout extends Activity {
	private LinearLayout ll_back;
	private String user_id,Group_id,ownerId,member_id,threadId;
	private ArrayList<GropUserData>arr_group;
	private ListView lis_kick;
	private TextView txt_header;
	private ImageLoader_rounded img_loader;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.kick_out_layout);
		
		WellconnectedConstant.ScreenName="";
		img_loader=new ImageLoader_rounded(KickLayout.this);
		
		lis_kick=(ListView) findViewById(R.id.lis_kick);
		
		txt_header=(TextView) findViewById(R.id.txt_header);
		
		SharedPreferences	pref = this.getSharedPreferences("LoginInfo", this.MODE_WORLD_READABLE);
		
		user_id=pref.getString("User_id", "");
		
		Group_id=this.getIntent().getStringExtra("GroupId");
		ownerId=this.getIntent().getStringExtra("OwnerId");
		threadId=this.getIntent().getStringExtra("ThreadId");
		
	
		ll_back=(LinearLayout) findViewById(R.id.ll_back);
		ll_back.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(KickLayout.this,GroupInfoActivity.class);
				startActivity(intent);
				finish();
			}
		});
		if(WellconnectedConstant.isPrevilage.equals("1"))
		{
			txt_header.setText("");
		}
		else
		{
			
		}
		
		if (WellconnectedUtills.isNetworkAvailable(KickLayout.this)) 
		{
			
			new KickOutTask().execute();
		}
		else
		{
			WellconnectedUtills.customDialog(KickLayout.this, "Internet connection is not available");
		}
		
		lis_kick.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				//dialog wit yes no btn
				
				member_id=arr_group.get(arg2).getUser_id();
				
				AlertDialog dialog;

				AlertDialog.Builder builder=new AlertDialog.Builder(KickLayout.this);
				if(WellconnectedConstant.isPrevilage.equals("1"))
				{
					builder.setMessage("do you want to give previlage to this member?");
					
					
				}
				else
				{
					builder.setMessage("Do you want to kick out this user?");
					
					
				}
				builder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						// TODO Auto-generated method stub
						if(WellconnectedConstant.isPrevilage.equals("1"))
						{
							new addPrevilegeTask().execute();
							
						}
						else
						{
							new KickOutFromGroupTask().execute();
							
						}
						
					
					}
				});
				builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
			           public void onClick(DialogInterface dialog, int id) {
			               // User cancelled the dialog
			        	   
			        	  
			           }
			       });
				dialog = builder.create();
			      dialog.show();
				
			}
		});
				
	}
	public class KickOutFromGroupTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		String chatbase;
;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(KickLayout.this, "", "Please Wait");
			
		}

		@Override
		protected String doInBackground(String... params) {
			
			// TODO Auto-generated method stub
			chatbase = WellconnectedParse.KickOutGroup(KickLayout.this,user_id,member_id,threadId,Group_id);
				
				//response=CCRApplicationParse.ChangePwd(ChangePasswordActivity.this, user_id, ed_password.getText().toString(), ed_new_pwd.getText().toString());
			
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			
			if (chatbase != null) {
				
				try {
					JSONObject obj=new JSONObject(chatbase);
					
					JSONObject obj_res=obj.getJSONObject("response");
					if(obj_res.has("success"))
					{
						AlertDialog.Builder builder = new AlertDialog.Builder(KickLayout.this);
						builder.setMessage(obj_res.getString("success"))
						       .setCancelable(false)
						       .setPositiveButton("OK", new DialogInterface.OnClickListener() {
						           public void onClick(DialogInterface dialog, int id) {
						                //do things
						        	   if (WellconnectedUtills.isNetworkAvailable(KickLayout.this)) 
						       		{
						       			
						       			new KickOutTask().execute();
						       		}
						       		else
						       		{
						       			WellconnectedUtills.customDialog(KickLayout.this, "Internet connection is not available");
						       		}
						           }
						       });
						AlertDialog alert = builder.create();
						alert.show();
						//WellconnectedUtills.customDialog(KickLayout.this,obj_res.getString("success"));
					}
					else
					{
						WellconnectedUtills.customDialog(KickLayout.this,obj_res.getString("error"));
						
					}
					
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
	}
	/**add previlege task **/
	
	public class addPrevilegeTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		String chatbase;
;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(KickLayout.this, "", "Please Wait");
			
		}

		@Override
		protected String doInBackground(String... params) {
			
			// TODO Auto-generated method stub
			chatbase = WellconnectedParse.addPrevilege(KickLayout.this,ownerId,Group_id,member_id);

				//response=CCRApplicationParse.ChangePwd(ChangePasswordActivity.this, user_id, ed_password.getText().toString(), ed_new_pwd.getText().toString());
			
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			
			if (chatbase != null) {
				
				try {
					JSONObject obj=new JSONObject(chatbase);
					
					JSONObject obj_res=obj.getJSONObject("response");
					if(obj_res.has("success"))
					{
						WellconnectedUtills.customDialog(KickLayout.this,obj_res.getString("success"));
					}
					else
					{
						WellconnectedUtills.customDialog(KickLayout.this,obj_res.getString("error"));
						
					}
					
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
	}
	
	/** about us  task **/
	public class KickOutTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		String chatbase;
;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(KickLayout.this, "", "Please Wait");
			
		}

		@Override
		protected String doInBackground(String... params) {
			
			// TODO Auto-generated method stub
			chatbase = WellconnectedParse.KickOut(KickLayout.this,user_id,Group_id);

				//response=CCRApplicationParse.ChangePwd(ChangePasswordActivity.this, user_id, ed_password.getText().toString(), ed_new_pwd.getText().toString());
			
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			
			if (chatbase != null) {
				
				try {
					JSONObject obj=new JSONObject(chatbase);
					JSONObject obj_res=obj.getJSONObject("response");
					JSONArray arr=obj_res.getJSONArray("GroupUser");
					
				arr_group=new ArrayList<GropUserData>();
					for(int i=0;i<arr.length();i++)
					{
						JSONObject obj_1=arr.getJSONObject(i);
						
						GropUserData data=new GropUserData();
						data.setDisplay_name(obj_1.getString("displayname"));
						data.setUser_id(obj_1.getString("user_id"));
						data.setUser_image(obj_1.getString("user_image"));
						data.setUser_name(obj_1.getString("user_name"));
						arr_group.add(data);
					}
					System.out.println("SIZE"+arr_group.size());
					lis_kick.setAdapter(new ListAdapter());
					
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
	}
	
	class ListAdapter extends BaseAdapter
	{

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return arr_group.size();
		}

		@Override
		public Object getItem(int arg0) {
			// TODO Auto-generated method stub
			return arg0;
		}

		@Override
		public long getItemId(int arg0) {
			// TODO Auto-generated method stub
			return arg0;
		}

		@Override
		public View getView(int arg0, View arg1, ViewGroup arg2) {
			// TODO Auto-generated method stub
			View row=View.inflate(KickLayout.this, R.layout.contact_list_row_1, null);
			ImageView img_contact_image=(ImageView) row.findViewById(R.id.img_contact_image);
			
			if(arr_group.get(arg0).getUser_image().equals("null"))
			{
				img_contact_image.setBackgroundResource(R.drawable.user_pic);
			}
			else
			{
				img_loader.DisplayImage(WellconnectedConstant.IMAGE_URL_3+arr_group.get(arg0).getUser_image(), img_contact_image);
				
			}
			
			Button btn_delete=(Button) row.findViewById(R.id.btn_delete);
			btn_delete.setVisibility(View.INVISIBLE);
			
			TextView txt_contact_name=(TextView) row.findViewById(R.id.txt_contact_name);
			txt_contact_name.setText(arr_group.get(arg0).getUser_name().trim());
			return row;
		}
		
	}
}
