package com.wellconnected.parse;

import org.json.JSONObject;

import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;
import com.wellconnected.bean.AboutUsBase;
import com.wellconnected.bean.BlockGroupBase;
import com.wellconnected.bean.ChangePwdBase;
import com.wellconnected.bean.ChatGroupBase;
import com.wellconnected.bean.ContactBase;
import com.wellconnected.bean.ForgotBase;
import com.wellconnected.bean.LoginBase;
import com.wellconnected.bean.MyGroupBase;
import com.wellconnected.bean.NotificationBase;
import com.wellconnected.bean.ProfileBase;
import com.wellconnected.bean.WellConnectedBase;
import com.wellconnected.servercommunication.CCRAppServerCommunication;
import com.wellconnected.utills.WellconnectedConstant;


public class WellconnectedParse {
	
	
	/** reg**/
	
	

	
/**forgot **/
	public static LoginBase login_state(Context ctx, String username, String password, String device_token)

	{
		LoginBase base_responce = null;

		try {
			JSONObject parameters = new JSONObject();

			parameters.put("user_type","2");

			parameters.put("device_token", device_token);
			parameters.put("password", password);
			parameters.put("username", username);

			Log.d("Request", parameters.toString());

			JSONObject json;

			json = CCRAppServerCommunication.callJson(WellconnectedConstant.WEBSERVICE_URL + WellconnectedConstant.login, parameters);

			Log.d("Response", json.toString());

			try {
				Gson gson = new Gson();
				base_responce = gson.fromJson(json.toString(), LoginBase.class);
				System.out.println("base_responce" + base_responce);

				/*
				 * storeResponse =
				 * gson.fromJson(json.toString(),StoresBase.class);
				 * System.out.println
				 * ("Print the firstList size"+storeResponse.getResponse
				 * ().getStores().size());
				 * System.out.println("Pint the Image List :"
				 * +storeResponse.getResponse().getHighlight_ad().size());
				 */
			} catch (Exception ex) {

				ex.printStackTrace();
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return base_responce;

	}

	/** fb login Base **/
	public static LoginBase Fblogin_state(Context ctx, String email_id, String fbId,String display_name, String dob,String gender,String image,String device_token)

	{
		LoginBase base_responce = null;

		try {
			JSONObject parameters = new JSONObject();

			parameters.put("user_type","2");

			parameters.put("email_id", email_id);
			parameters.put("fbId", fbId);
			parameters.put("display_name", display_name);
			parameters.put("dob", dob);
			parameters.put("gender", gender);
			parameters.put("image", image);
			parameters.put("device_token", device_token);
			Log.d("Request", parameters.toString());

			JSONObject json;

			json = CCRAppServerCommunication.callJson(WellconnectedConstant.WEBSERVICE_URL + WellconnectedConstant.fb_login, parameters);

			Log.d("Response", json.toString());

			try {
				Gson gson = new Gson();
				base_responce = gson.fromJson(json.toString(), LoginBase.class);
				System.out.println("base_responce" + base_responce);

			
			} catch (Exception ex) {

				ex.printStackTrace();
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return base_responce;

	}
	public static ForgotBase forgot_state(Context ctx, String email)

	{
		ForgotBase base_responce = null;

		try {
			JSONObject parameters = new JSONObject();

			parameters.put("email", email);

			Log.d("Request", parameters.toString());

			JSONObject json;

			json = CCRAppServerCommunication.callJson(WellconnectedConstant.WEBSERVICE_URL + WellconnectedConstant.forgot_password, parameters);

			Log.d("Response", json.toString());

			try {
				Gson gson = new Gson();
				base_responce = gson.fromJson(json.toString(), ForgotBase.class);
				System.out.println("base_responce" + base_responce);

				
			} catch (Exception ex) {

				ex.printStackTrace();
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return base_responce;

	}
	
	//send chat data
	

	public static String send_chat_data(Context ctx, String user_id , String friend_id,String message,String type,String image,
			String nameCard,String threadId ,String group_type,String groupId,String chatStatus)

	{
		MyGroupBase base_responce = null;
		JSONObject json = null;

		try {
			JSONObject parameters = new JSONObject();

			parameters.put("user_id", user_id);
			parameters.put("friend_id", friend_id);
			parameters.put("message", message);
			parameters.put("type", type);
			parameters.put("image", image);
			parameters.put("nameCard", nameCard);
			parameters.put("threadId", threadId);
			parameters.put("group_type", group_type);
			parameters.put("groupId", groupId);
			parameters.put("chatStatus", chatStatus);
			
			Log.d("Request", parameters.toString());

			
			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+ WellconnectedConstant.send_chat_data, parameters);

			Log.d("Response", json.toString());
/*
			try {
				Gson gson = new Gson();
				base_responce = gson.fromJson(json.toString(),
						MyGroupBase.class);
				System.out.println("base_responce" + base_responce);

			} catch (Exception ex) {

				ex.printStackTrace();
			}*/

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return  json.toString();

	}

	//group owner request
	//chat detail 
	
	public static String Groupownerrequest(Context ctx, String userId , String groupId,String status,String memberId,String messageId)

	{
		MyGroupBase base_responce = null;
		JSONObject json = null;

		try {
			JSONObject parameters = new JSONObject();

			parameters.put("userId", userId);
			parameters.put("groupId", groupId);
			parameters.put("status", status);

			parameters.put("memberId", memberId);
			parameters.put("messageId", messageId);
			
			Log.d("Request", parameters.toString());

			
			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+ WellconnectedConstant.OwnerGroupAction, parameters);

			Log.d("Response", json.toString());
/*
			try {
				Gson gson = new Gson();
				base_responce = gson.fromJson(json.toString(),
						MyGroupBase.class);
				System.out.println("base_responce" + base_responce);

			} catch (Exception ex) {

				ex.printStackTrace();
			}*/

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return  json.toString();

	}
	//chat detail 
	
	public static String Chat_detail(Context ctx, String user_id , String friend_id,String group_type,String groupId,String msgid,String type,String page )

	{
		MyGroupBase base_responce = null;
		JSONObject json = null;

		try {
			JSONObject parameters = new JSONObject();

			parameters.put("user_id", user_id);
			parameters.put("friend_id", friend_id);
			parameters.put("group_type", group_type);
			parameters.put("groupId", groupId);
			parameters.put("msgid", msgid);
			parameters.put("type", type);
			parameters.put("page", page);
			
			Log.d("Request", parameters.toString());

			
			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+ WellconnectedConstant.chat_detail, parameters);

			Log.d("Response", json.toString());
/*
			try {
				Gson gson = new Gson();
				base_responce = gson.fromJson(json.toString(),
						MyGroupBase.class);
				System.out.println("base_responce" + base_responce);

			} catch (Exception ex) {

				ex.printStackTrace();
			}*/

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return  json.toString();

	}
	public static MyGroupBase my_group(Context ctx, String userId, String page)

	{
		MyGroupBase base_responce = null;

		try {
			JSONObject parameters = new JSONObject();

			parameters.put("userId", userId);
			parameters.put("page", page);
			Log.d("Request", parameters.toString());

			JSONObject json;

			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+ WellconnectedConstant.latestGroup, parameters);

			Log.d("Response", json.toString());

			try {
				Gson gson = new Gson();
				base_responce = gson.fromJson(json.toString(),
						MyGroupBase.class);
				System.out.println("base_responce" + base_responce);

			} catch (Exception ex) {

				ex.printStackTrace();
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return base_responce;

	}
	
	
	public static MyGroupBase my_group_search(Context ctx, String userId, String page,String search_name)

	{
		MyGroupBase base_responce = null;

		try {
			JSONObject parameters = new JSONObject();

			parameters.put("userId", userId);
			parameters.put("page", page);
			parameters.put("search_name", search_name);
			
			
			
			Log.d("Request", parameters.toString());

			JSONObject json;

			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+ WellconnectedConstant.findGroup, parameters);

			Log.d("Response", json.toString());

			try {
				Gson gson = new Gson();
				base_responce = gson.fromJson(json.toString(),
						MyGroupBase.class);
				System.out.println("base_responce" + base_responce);

			} catch (Exception ex) {

				ex.printStackTrace();
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return base_responce;

	}
	
	
	public static String ClearallTAsk(Context ctx, String member_id,String user_id)

	{
		JSONObject json=null;

		try {
			JSONObject parameters = new JSONObject();

			parameters.put("member_id", member_id);
			parameters.put("user_id", user_id);
			
			
			Log.d("Request", parameters.toString());

			
			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+ WellconnectedConstant.clear_individual_message, parameters);

			Log.d("Response", json.toString());

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return json.toString();

	}
	
	//profile task
	
	
	public static ProfileBase getprofile(Context ctx, String user_id,String friend_id)

	{
		ProfileBase base_responce = null;
		try {
			JSONObject parameters = new JSONObject();

			parameters.put("user_id", user_id);
			parameters.put("friend_id", friend_id);
			
			
			Log.d("Request", parameters.toString());

			JSONObject json;

			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+ WellconnectedConstant.friend_profile, parameters);

			Log.d("Response", json.toString());

			try {
				Gson gson = new Gson();
				base_responce = gson.fromJson(json.toString(),
						ProfileBase.class);
				System.out.println("base_responce" + base_responce);

			} catch (Exception ex) {

				ex.printStackTrace();
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return base_responce;

	}
	public static ContactBase getContact(Context ctx, String user_id)

	{
		ContactBase base_responce = null;
		try {
			JSONObject parameters = new JSONObject();

			parameters.put("user_id", user_id);
			Log.d("Request", parameters.toString());

			JSONObject json;

			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+ WellconnectedConstant.
							contact_listing
							
							, parameters);

			Log.d("Response", json.toString());

			try {
				Gson gson = new Gson();
				base_responce = gson.fromJson(json.toString(),
						ContactBase.class);
				System.out.println("base_responce" + base_responce);

			} catch (Exception ex) {

				ex.printStackTrace();
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return base_responce;

	}
	/** get notification **/
	
	public static NotificationBase getNotification_status(Context ctx, String user_id)

	{
		NotificationBase base_responce = null;

		try {
			JSONObject parameters = new JSONObject();
			parameters.put("user_id", user_id);

			Log.d("Request", parameters.toString());
			JSONObject json;
			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+ WellconnectedConstant.unPaidAmount, parameters);
			Log.d("Response", json.toString());
			try {
				Gson gson = new Gson();
				base_responce = gson.fromJson(json.toString(),
						NotificationBase.class);
				System.out.println("base_responce" + base_responce);

			} catch (Exception ex) {
				ex.printStackTrace();
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return base_responce;
	}
	
	/** update notification **/
	
	public static ChangePwdBase UpdateNotification_status(Context ctx, String user_id,String notification)

	{
		ChangePwdBase base_responce = null;

		try {
			JSONObject parameters = new JSONObject();
			parameters.put("userId", user_id);
			parameters.put("notification", notification);

			Log.d("Request", parameters.toString());
			JSONObject json;
			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+ WellconnectedConstant.updateNotification, parameters);
			Log.d("Response", json.toString());
			try {
				Gson gson = new Gson();
				base_responce = gson.fromJson(json.toString(),
						ChangePwdBase.class);
				System.out.println("base_responce" + base_responce);

			} catch (Exception ex) {
				ex.printStackTrace();
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return base_responce;
	}
	
	/** get wellconnected users task **/
	
	//about us
	public static WellConnectedBase wellconnectedusers(Context ctx,String user_id,String search_name)

	{
		WellConnectedBase base_responce = null;

		try {
			JSONObject parameters = new JSONObject();
			parameters.put("user_id", user_id);
			parameters.put("search_name", search_name);
			Log.d("Request", parameters.toString());
			JSONObject json;
			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+ WellconnectedConstant.user_listing , parameters);
			Log.d("Response", json.toString());
			try {
				Gson gson = new Gson();
				base_responce = gson.fromJson(json.toString(),
						WellConnectedBase.class);
				System.out.println("base_responce" + base_responce);

			} catch (Exception ex) {
				ex.printStackTrace();
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return base_responce;
	}
	
	//add user task 
	//about us
		public static ChangePwdBase addUser(Context ctx,String user_id,String friend_id,String intro)

		{
			ChangePwdBase base_responce = null;

			try {
				JSONObject parameters = new JSONObject();
				parameters.put("user_id", user_id);
				parameters.put("friend_id", friend_id);
				parameters.put("intro", intro);
				
				
				
				Log.d("Request", parameters.toString());
				JSONObject json;
				json = CCRAppServerCommunication.callJson(
						WellconnectedConstant.WEBSERVICE_URL
								+ WellconnectedConstant.add_contact  , parameters);
				Log.d("Response", json.toString());
				try {
					Gson gson = new Gson();
					base_responce = gson.fromJson(json.toString(),
							ChangePwdBase.class);
					System.out.println("base_responce" + base_responce);

				} catch (Exception ex) {
					ex.printStackTrace();
				}

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return base_responce;
		}
		
		//get edit profile
		//get phone no
		public static String sendPhoneNo(Context ctx,String user_id,String phone_number,String username)
		{
			JSONObject json = null;
			try {
				JSONObject parameters = new JSONObject();
				parameters.put("user_id",user_id);
				parameters.put("phone_number",phone_number);
				parameters.put("username",username);
				
				
				Log.d("Request", parameters.toString());
		
				json = CCRAppServerCommunication.callJson(
						WellconnectedConstant.WEBSERVICE_URL
								+ WellconnectedConstant.send_phone_num, parameters);
				Log.d("Response", json.toString());
				

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return json.toString();
		}
		
		//my profile 
		public static String myProfile(Context ctx,String user_id)
		{
			JSONObject json = null;
			try {
				JSONObject parameters = new JSONObject();
				parameters.put("user_id",user_id);
				Log.d("Request", parameters.toString());
		
				json = CCRAppServerCommunication.callJson(
						WellconnectedConstant.WEBSERVICE_URL
								+ WellconnectedConstant.user_profile_detail, parameters);
				Log.d("Response", json.toString());
				

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return json.toString();
		}
		//blockkkk
		
		//about us
		//group info
		
		public static String groupInfo(Context ctx,String id,String user_id)
		{
			JSONObject json=null;
			
			try {
				JSONObject parameters = new JSONObject();
				parameters.put("id", id);
				parameters.put("user_id",user_id);
				Log.d("Request", parameters.toString());
			
				json = CCRAppServerCommunication.callJson(
						WellconnectedConstant.WEBSERVICE_URL
								+ WellconnectedConstant.groupInfo, parameters);
				Log.d("Response", json.toString());
			

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return json.toString();
		}
		
		//add previlege task
		
		

	
		public static String KickOutGroup(Context ctx,String userId,String memberId,String threadId,String groupId)
		{
			
			JSONObject json = null;
			try {
				JSONObject parameters = new JSONObject();
				parameters.put("userId", userId);
				parameters.put("memberId",memberId);
				parameters.put("threadId",threadId);
				parameters.put("groupId",groupId);
				
				Log.d("Request", parameters.toString());
				
				json = CCRAppServerCommunication.callJson(
						WellconnectedConstant.WEBSERVICE_URL
								+ WellconnectedConstant.groupKickOut, parameters);
				Log.d("Response", json.toString());


			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return json.toString();
		}
		
		public static String addPrevilege(Context ctx,String ownerId,String group_id,String memberId)
		{
			
			JSONObject json = null;
			try {
				JSONObject parameters = new JSONObject();
				parameters.put("ownerId", ownerId);
				parameters.put("groupId",group_id);
				parameters.put("memberId",memberId);
				
				Log.d("Request", parameters.toString());
				
				json = CCRAppServerCommunication.callJson(
						WellconnectedConstant.WEBSERVICE_URL
								+ WellconnectedConstant.groupPrivailage, parameters);
				Log.d("Response", json.toString());


			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return json.toString();
		}
		
		//kick out taskk
		
		public static String KickOut(Context ctx,String user_id,String group_id)
		{
			
			JSONObject json = null;
			try {
				JSONObject parameters = new JSONObject();
				parameters.put("userId", user_id);
				parameters.put("groupId",group_id);
				
				Log.d("Request", parameters.toString());
				
				json = CCRAppServerCommunication.callJson(
						WellconnectedConstant.WEBSERVICE_URL
								+ WellconnectedConstant.groupUserListing, parameters);
				Log.d("Response", json.toString());


			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return json.toString();
		}
		/** edit group content **/
		
		

			
		public static String editGroupContent(Context ctx,String groupId,String groupContent)
		{
			JSONObject json = null;
			try {
				JSONObject parameters = new JSONObject();
				parameters.put("groupId", groupId);
				parameters.put("groupContent", groupContent);
				Log.d("Request", parameters.toString());
				
				json = CCRAppServerCommunication.callJson(
						WellconnectedConstant.WEBSERVICE_URL
								+ WellconnectedConstant.groupEdit, parameters);
				Log.d("Response", json.toString());
				

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return json.toString();
		}
	//about us
	public static AboutUsBase aboutUs(Context ctx)
	{
		AboutUsBase base_responce = null;
		try {
			JSONObject parameters = new JSONObject();
			parameters.put("", "");
			Log.d("Request", parameters.toString());
			JSONObject json;
			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+ WellconnectedConstant.home_message, parameters);
			Log.d("Response", json.toString());
			try {
				Gson gson = new Gson();
				base_responce = gson.fromJson(json.toString(),
						AboutUsBase.class);
				System.out.println("base_responce" + base_responce);

			} catch (Exception ex) {
				ex.printStackTrace();
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return base_responce;
	}
	/** quit group **/
	public static String QuitgroupTask(Context ctx,String userId,
			String groupId,String ownerId,String owner)
	{
			try {
			JSONObject parameters = new JSONObject();
			parameters.put("userId",userId);
			parameters.put("groupId",groupId);
			parameters.put("ownerId",ownerId);
			parameters.put("owner",owner);
			Log.d("Request", parameters.toString());
			JSONObject json;
			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+WellconnectedConstant.groupQuit, parameters);
			Log.d("Response", json.toString());
			
		return json.toString();
	}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	/** close group task **/



	public static String CloseGroupTask(Context ctx,String userId,
			String groupId,String groupStatus,String threadId )
	{
			try {
			JSONObject parameters = new JSONObject();
			parameters.put("userId",userId);
			parameters.put("groupId",groupId);
			parameters.put("groupStatus",groupStatus);
			parameters.put("threadId",threadId);

			Log.d("Request", parameters.toString());
			JSONObject json;
			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+WellconnectedConstant.groupClose, parameters);
			Log.d("Response", json.toString());
			
		return json.toString();
	}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	/** clear mesg task **/
	public static String ClearMsgTask(Context ctx,String userId,
			String groupId)
	{
			try {
			JSONObject parameters = new JSONObject();
			parameters.put("userId",userId);
			parameters.put("groupId",groupId);

			Log.d("Request", parameters.toString());
			JSONObject json;
			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+WellconnectedConstant.clearAllGroupMessage, parameters);
			Log.d("Response", json.toString());
			
		return json.toString();
	}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	/** group info task **/
	//about us
		public static String JoinTask(Context ctx,String key,
				String userId,String groupId,String memberId)
		{
				try {
				JSONObject parameters = new JSONObject();
				parameters.put("userId",userId);
				parameters.put("groupId",groupId);
				parameters.put("memberId",memberId);
				Log.d("Request", parameters.toString());
				JSONObject json;
				json = CCRAppServerCommunication.callJson(
						WellconnectedConstant.WEBSERVICE_URL
								+ key, parameters);
				Log.d("Response", json.toString());
				
			return json.toString();
		}
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}
	/** change pswd **/
	
	public static ChangePwdBase changepwd(Context ctx, String user_id, String password,String newpassword)
	{
		ChangePwdBase base_responce = null;
		try {
			JSONObject parameters = new JSONObject();
			parameters.put("user_id", user_id);
			parameters.put("password", password);
			parameters.put("newpassword", newpassword);
			Log.d("Request", parameters.toString());
			JSONObject json;
			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+ WellconnectedConstant.change_password, parameters);
			Log.d("Response", json.toString());
			try {
				Gson gson = new Gson();
				base_responce = gson.fromJson(json.toString(),
						ChangePwdBase.class);
				System.out.println("base_responce" + base_responce);
			} catch (Exception ex) {
				ex.printStackTrace();
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return base_responce;
	}
	/** delete contact **/
	
/** change pswd **/
	
	public static ChangePwdBase DeleteContact(Context ctx, String user_id)
	{
		ChangePwdBase base_responce = null;
		try {
			JSONObject parameters = new JSONObject();
			parameters.put("id", user_id);
			Log.d("Request", parameters.toString());
			JSONObject json;
			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+ WellconnectedConstant.delete_contact, parameters);
			Log.d("Response", json.toString());
			try {
				Gson gson = new Gson();
				base_responce = gson.fromJson(json.toString(),
						ChangePwdBase.class);
				System.out.println("base_responce" + base_responce);
			} catch (Exception ex) {
				ex.printStackTrace();
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return base_responce;
	}
	
	
	//logout
	public static ChangePwdBase logout(Context ctx, String user_id, String device_token)
	{
		ChangePwdBase base_responce = null;
		try {
			JSONObject parameters = new JSONObject();
			parameters.put("user_id", user_id);
			parameters.put("device_token", device_token);
		
			Log.d("Request", parameters.toString());
			JSONObject json;
			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+ WellconnectedConstant.logout, parameters);
			Log.d("Response", json.toString());
			try {
				Gson gson = new Gson();
				base_responce = gson.fromJson(json.toString(),
						ChangePwdBase.class);
				System.out.println("base_responce" + base_responce);
			} catch (Exception ex) {
				ex.printStackTrace();
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return base_responce;
	}
	public static ChatGroupBase getChat(Context ctx, String user_id, String search_name)
	{
		ChatGroupBase base_responce = null;
		try {
			JSONObject parameters = new JSONObject();
			parameters.put("user_id", user_id);
			parameters.put("search_name", search_name);
			Log.d("Request", parameters.toString());
			JSONObject json;
			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+ WellconnectedConstant.chat_listing, parameters);
			Log.d("Response", json.toString());
			try {
				Gson gson = new Gson();
				base_responce = gson.fromJson(json.toString(),
						ChatGroupBase.class);
				System.out.println("base_responce" + base_responce);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return base_responce;
	}
	
	/** contat list **/
	
	public static ContactBase getContactList(Context ctx, String user_id)
	{
		ContactBase base_responce = null;
		try {
			JSONObject parameters = new JSONObject();
			parameters.put("user_id", user_id);
			Log.d("Request", parameters.toString());
			JSONObject json;
			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+ WellconnectedConstant.contact_listing , parameters);
			Log.d("Response", json.toString());
			try {
				Gson gson = new Gson();
				base_responce = gson.fromJson(json.toString(),
						ContactBase.class);
				System.out.println("base_responce" + base_responce);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return base_responce;
	}
	
	
/** contact actionn**/
	
	public static String getcontactaction(Context ctx, String user_id,String memberId,String status,String contactId )
	{
		ContactBase base_responce = null;
				JSONObject json= null;
		try {
			JSONObject parameters = new JSONObject();
			parameters.put("userId", user_id);
			parameters.put("memberId", memberId);
			parameters.put("status", status);
			parameters.put("contactId", contactId);
			
			Log.d("Request", parameters.toString());
		
			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+ WellconnectedConstant.contact_action , parameters);
			
			Log.d("Response", json.toString());
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return json.toString();
	}
	public static BlockGroupBase getBlockList(Context ctx, String user_id)
	{
		BlockGroupBase base_responce = null;
		try {
			JSONObject parameters = new JSONObject();
			parameters.put("user_id", user_id);
			
			Log.d("Request", parameters.toString());
			JSONObject json;
			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+ WellconnectedConstant.block_list, parameters);
			Log.d("Response", json.toString());
			try {
				Gson gson = new Gson();
				base_responce = gson.fromJson(json.toString(),
						BlockGroupBase.class);
				System.out.println("base_responce" + base_responce);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return base_responce;
	}
	
	public static ChangePwdBase updateBlockList(Context ctx, String user_id,String member_id,String block)
	{
		ChangePwdBase base_responce = null;
		try {
			JSONObject parameters = new JSONObject();
			parameters.put("user_id", user_id);
			parameters.put("member_id", member_id);
			parameters.put("block", block);
			
			
			
			Log.d("Request", parameters.toString());
			JSONObject json;
			json = CCRAppServerCommunication.callJson(
					WellconnectedConstant.WEBSERVICE_URL
							+ WellconnectedConstant.updateMemberBlock, parameters);
			Log.d("Response", json.toString());
			try {
				Gson gson = new Gson();
				base_responce = gson.fromJson(json.toString(),
						ChangePwdBase.class);
				System.out.println("base_responce" + base_responce);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return base_responce;
	}
}