package com.wellconnected.bean;

import java.util.ArrayList;

public class MygroupBean {
	public String getTotal_records() {
		return total_records;
	}
	public void setTotal_records(String total_records) {
		this.total_records = total_records;
	}
	public String getUnreadCount() {
		return unreadCount;
	}
	public void setUnreadCount(String unreadCount) {
		this.unreadCount = unreadCount;
	}
	
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	
	
	public String getSuccess() {
		return success;
	}
	public void setSuccess(String success) {
		this.success = success;
	}
	public String error;
	public String total_records;
	public String totalRecord;
	
	
	public String getTotalRecord() {
		return totalRecord;
	}
	public void setTotalRecord(String totalRecord) {
		this.totalRecord = totalRecord;
	}
	public String unreadCount;
	public String success;
	public ArrayList<GroupDetail> GroupDetail=new ArrayList<MygroupBean.GroupDetail>();
	
	

	


	public ArrayList<GroupDetail> getGroupDetail() {
		return GroupDetail;
	}
	public void setGroupDetail(ArrayList<GroupDetail> groupDetail) {
		GroupDetail = groupDetail;
	}






	public static class GroupDetail
	{
		
		public String getLatest() {
			return latest;
		}
		public void setLatest(String latest) {
			this.latest = latest;
		}
		public String getGroupId() {
			return groupId;
		}
		public void setGroupId(String groupId) {
			this.groupId = groupId;
		}
		public String getGroupName() {
			return groupName;
		}
		public void setGroupName(String groupName) {
			this.groupName = groupName;
		}
		public String getIntro() {
			return intro;
		}
		public void setIntro(String intro) {
			this.intro = intro;
		}
		public String getGroupImage() {
			return groupImage;
		}
		public void setGroupImage(String groupImage) {
			this.groupImage = groupImage;
		}
		public String getPaidStatus() {
			return paidStatus;
		}
		public void setPaidStatus(String paidStatus) {
			this.paidStatus = paidStatus;
		}
		public String getCreated() {
			return created;
		}
		public void setCreated(String created) {
			this.created = created;
		}
		public String getSubCharge() {
			return subCharge;
		}
		public void setSubCharge(String subCharge) {
			this.subCharge = subCharge;
		}
		public String getGroupType() {
			return groupType;
		}
		public void setGroupType(String groupType) {
			this.groupType = groupType;
		}
		public String getJoin() {
			return join;
		}
		public void setJoin(String join) {
			this.join = join;
		}
		public String getGroupOwnerId() {
			return groupOwnerId;
		}
		public void setGroupOwnerId(String groupOwnerId) {
			this.groupOwnerId = groupOwnerId;
		}
		public String getGroupUserTableId() {
			return groupUserTableId;
		}
		public void setGroupUserTableId(String groupUserTableId) {
			this.groupUserTableId = groupUserTableId;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getRequest_status() {
			return request_status;
		}
		public void setRequest_status(String request_status) {
			this.request_status = request_status;
		}
		public String getSubscribeStatus() {
			return subscribeStatus;
		}
		public void setSubscribeStatus(String subscribeStatus) {
			this.subscribeStatus = subscribeStatus;
		}
		public String getIndividualCount() {
			return individualCount;
		}
		public void setIndividualCount(String individualCount) {
			this.individualCount = individualCount;
		}
		public String getParent_id() {
			return parent_id;
		}
		public void setParent_id(String parent_id) {
			this.parent_id = parent_id;
		}
		public String getSpecial() {
			return special;
		}
		public void setSpecial(String special) {
			this.special = special;
		}
		public String getThreadId() {
			return threadId;
		}
		public void setThreadId(String threadId) {
			this.threadId = threadId;
		}
		String latest;
		String groupId;
		String groupCode;
		public String getGroupCode() {
			return groupCode;
		}
		public void setGroupCode(String groupCode) {
			this.groupCode = groupCode;
		}
		String groupName;
		String intro;
		String groupImage;
		String paidStatus;
		String created;
		String subCharge;
		String groupType;
		String join;
		String groupOwnerId;
		String groupUserTableId;
		String status;
		String request_status;
		String subscribeStatus;
		String individualCount;
		String parent_id;
		String special;
		String threadId;
		String message;
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
		
		
       
	}
	
}
