package com.wellconnected.bean;

import android.widget.ImageButton;

public class Button_circle_state {
	public String getIs_selected() {
		return is_selected;
	}
	public void setIs_selected(String is_selected) {
		this.is_selected = is_selected;
	}
	public ImageButton getBtn_circle() {
		return btn_circle;
	}
	public void setBtn_circle(ImageButton btn_circle) {
		this.btn_circle = btn_circle;
	}
	public String is_selected;
	public ImageButton btn_circle;

}
