package com.wellconnected.bean;

public interface GroupSearchMenuListener {

	public void onMenuClick();
}
