//
//  CAVNSArrayTypeCategory.h
//  Shopping
//
//  Created by Mac on 7/20/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

@interface NSArray (Type)
-(id)firstObjectWithClass:(Class)class;
@end
