package com.wellconnected.bean;

public class ChatGroupBase {

	private ChatDetailBean response;

	public ChatDetailBean getResponse() {
		return response;
	}

	public void setResponse(ChatDetailBean response) {
		this.response = response;
	}
	
}
