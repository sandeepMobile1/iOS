//
//  UserProfileData.m
//  ConstantLine
//
//  Created by octal i-phone2 on 8/13/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "UserProfileData.h"

@implementation UserProfileData

@synthesize user_name,display_name,email,user_image,dob,gender,rating,num_of_groups,phone_num,user_id,friend_status,unpaid_revenue,contact_email,password,intro;

@end
