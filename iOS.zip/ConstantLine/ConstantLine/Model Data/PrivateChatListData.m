//
//  PrivateChatListData.m
//  ConstantLine
//
//  Created by Pramod Sharma on 20/11/13.
//
//

#import "PrivateChatListData.h"

@implementation PrivateChatListData

@synthesize name,image,message,charge,date,readStatus,userId,chatType,groupType,paidStatus,messasgeId,cellHeight,zChatId,requestStatus,groupUserTableId,groupOwnerId,groupJoinStatus,subscribeStatus,chatStatus;

@end
