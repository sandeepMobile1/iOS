package com.view.wellconnected;

import org.json.JSONException;
import org.json.JSONObject;

import com.wellconnected.bean.AboutUsBase;
import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

public class EditGroupDeatil extends Activity{
	LinearLayout  ll_back;
	Button btn_edit;
	private String Group_id,groupContent;
	private EditText ed_text;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		setContentView(R.layout.editcontant);
		WellconnectedConstant.ScreenName="";
		Group_id=this.getIntent().getStringExtra("GroupId");
		
		System.out.println("Group_id"+Group_id);
		
		ed_text=(EditText) findViewById(R.id.ed_text);
		
		ll_back=(LinearLayout) findViewById(R.id.ll_back);
		ll_back.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});
		
		btn_edit=(Button) findViewById(R.id.btn_edit);
		btn_edit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				groupContent=ed_text.getText().toString().trim();
				if(groupContent.length()>0)
				{
					System.out.println("groupContent"+groupContent);
					new EditTextTask().execute();
				}
				else
				{
					WellconnectedUtills.customDialog(EditGroupDeatil.this, "Please enter group detail");
				}
			
			}
		});
	}
	
	public class EditTextTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		String chatbase;
;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(EditGroupDeatil.this, "", "Please Wait");
			
		}

		@Override
		protected String doInBackground(String... params) {
			
			// TODO Auto-generated method stub
			chatbase = WellconnectedParse.editGroupContent(EditGroupDeatil.this,Group_id,groupContent);

				//response=CCRApplicationParse.ChangePwd(ChangePasswordActivity.this, user_id, ed_password.getText().toString(), ed_new_pwd.getText().toString());
			
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			
			if (chatbase != null) {
				
				JSONObject obj;
				try {
					obj = new JSONObject(chatbase);
					JSONObject obj_res=obj.getJSONObject("response");
					if(obj_res.has("success"))
					{
						
						WellconnectedUtills.customDialog(EditGroupDeatil.this, obj_res.getString("success"));
						
					}
					else
					{
						WellconnectedUtills.customDialog(EditGroupDeatil.this, obj_res.getString("error"));
						
					}
					
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}
