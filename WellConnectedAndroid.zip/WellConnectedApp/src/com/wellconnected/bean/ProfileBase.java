package com.wellconnected.bean;

public class ProfileBase {

	private ProfileSuccessBase response;

	public ProfileSuccessBase getResponse() {
		return response;
	}

	public void setResponse(ProfileSuccessBase response) {
		this.response = response;
	}
	
}
