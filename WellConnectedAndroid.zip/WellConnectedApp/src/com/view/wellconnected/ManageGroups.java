package com.view.wellconnected;

import org.json.JSONException;
import org.json.JSONObject;

import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class ManageGroups extends Activity {
	private String closeStatus,user_id,Group_id,groupStatus,threadId,ownerId;
	private TextView txt_groupname,txt_group_text;
	private LinearLayout ll_back;
	private RelativeLayout rl_closegroup,rl_edit_group,rl_add_previlage,rl_quitgroup;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.manage_group);
		
		WellconnectedConstant.ScreenName="";
		SharedPreferences	pref = this.getSharedPreferences("LoginInfo", this.MODE_WORLD_READABLE);
		
		user_id=pref.getString("User_id", "");
		Group_id=this.getIntent().getStringExtra("GroupId");
		threadId=this.getIntent().getStringExtra("threadId");
		
		closeStatus=this.getIntent().getStringExtra("Manage_group");
		ownerId=this.getIntent().getStringExtra("OwnerId");
		
		
		txt_groupname=(TextView) findViewById(R.id.txt_groupname);
		txt_group_text=(TextView) findViewById(R.id.txt_group_text);
		
		if(closeStatus.equals("0"))
		{
			
			groupStatus="1";
			txt_groupname.setText("Close Group");
			txt_group_text.setText("Group will not accept new member and display 'Closed for new member' status on the search result.");
			
			}
		else
		{
			groupStatus="0";
			txt_groupname.setText("Open Group");
			txt_group_text.setText("Group will be re-opened for new members.");
	
		}
		rl_closegroup=(RelativeLayout) findViewById(R.id.rl_closegroup);
		rl_closegroup.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				new GroupCloseTask().execute();
			}
		});
		
		rl_edit_group=(RelativeLayout) findViewById(R.id.rl_edit_group);
		rl_edit_group.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(ManageGroups.this,EditGroupDeatil.class);
				intent.putExtra("GroupId", Group_id);
				
				startActivity(intent);
			}
		});
		
		rl_add_previlage=(RelativeLayout) findViewById(R.id.rl_add_previlage);
		rl_add_previlage.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(ManageGroups.this,KickLayout.class);
				intent.putExtra("GroupId", Group_id);
				intent.putExtra("OwnerId", ownerId);
				intent.putExtra("ThreadId", threadId);
				WellconnectedConstant.isPrevilage="1";
				startActivity(intent);
			}
		});
		rl_quitgroup=(RelativeLayout) findViewById(R.id.rl_quitgroup);
		rl_quitgroup.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if(ownerId.equals(user_id))
				{
					WellconnectedUtills.customDialog(ManageGroups.this, "You can not quit group");
				}
				else
				{
					new QuitGroupTask().execute();
				}
			}
		});
		ll_back=(LinearLayout) findViewById(R.id.ll_back);
		ll_back.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				Intent intent=new Intent(ManageGroups.this,GroupInfoActivity.class);
				intent.putExtra("Id", getIntent().getStringExtra("Id"));
				intent.putExtra("user_id", getIntent().getStringExtra("user_id"));
				intent.putExtra("Join_status", getIntent().getStringExtra("Join_status"));
				intent.putExtra("Group_Type", getIntent().getStringExtra("Group_Type"));
				startActivity(intent);
				finish();
			}
		});
	}
	
/** Quit group **/

	public class QuitGroupTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		String chatbase;
;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(ManageGroups.this, "", "Please Wait");
			
		}

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			chatbase = WellconnectedParse.QuitgroupTask(ManageGroups.this,user_id,Group_id,ownerId,"0");

			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			
			if (chatbase != null) {
				JSONObject obj;
				try {
					obj = new JSONObject(chatbase);
					JSONObject obj_res=obj.getJSONObject("response");
					if(obj_res.has("success"))
					{
						
						WellconnectedUtills.customDialog(ManageGroups.this, obj_res.getString("success"));
						
					}
					else
					{
						WellconnectedUtills.customDialog(ManageGroups.this, obj_res.getString("error"));
						
					}
					
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	/** group close task **/
	
	private class GroupCloseTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		String chatbase;
;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(ManageGroups.this, "", "Please Wait");
		}
		@Override
		protected String doInBackground(String... params) {
			
			chatbase = WellconnectedParse.CloseGroupTask(ManageGroups.this, user_id, Group_id, groupStatus, threadId);
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}

			if (chatbase != null) {
				JSONObject obj;
				try {
					obj = new JSONObject(chatbase);
					JSONObject obj_res=obj.getJSONObject("response");
					if(obj_res.has("success"))
					{
						if(groupStatus.equals("0"))
						{
							groupStatus="1";
						txt_groupname.setText("Close Group");
						txt_group_text.setText("Group will not accept new member and display 'Closed for new member' status on the search result.");
						
						}
						else
						{
							groupStatus="0";
							txt_groupname.setText("Open Group");
							txt_group_text.setText("Group will be re-opened for new members.");
						
						}
						WellconnectedUtills.customDialog(ManageGroups.this, obj_res.getString("success"));
					}
					else
					{
						WellconnectedUtills.customDialog(ManageGroups.this, obj_res.getString("error"));
					}
					
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}
