package com.view.wellconnected;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

import org.json.JSONObject;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.Request;
import com.facebook.Request.GraphUserCallback;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.SessionState;
import com.facebook.UiLifecycleHelper;
import com.facebook.model.GraphUser;
import com.google.android.gcm.GCMRegistrar;
import com.wellconnected.bean.ForgotBase;
import com.wellconnected.bean.LoginBase;
import com.wellconnected.database.DataBaseManager;
import com.wellconnected.database.MatchDataSource;
import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

public class LoginActivity2 extends Activity implements OnClickListener {
	private EditText ed_email, ed_password, forgotPasswordDialogEditText;
	private ImageButton img_rember, img_login_btn, img_fb_btn;
	private Button forgotPasswordDialogButtonOk, forgotPasswordDialogButtonCancel;
	private TextView txt_forgot_pwd;
	private String str_email, str_pwd;
	//private boolean is_remember = true;x
	private String is_remember="true";
	public static final Pattern EMAIL_ADDRESS_PATTERN = Pattern.compile("[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}");
	private Dialog dialog;
	private SharedPreferences pref;
	private DataBaseManager dbhelper;
	private MatchDataSource datasourse;
	private SQLiteDatabase mySqldb;
	private static final List<String> PERMISSIONS = Arrays.asList("email","user_friends", "user_location", "user_hometown", "friends_hometown", "friends_location","read_friendlists");
	private UiLifecycleHelper uiHelper;
	private LinearLayout ll_back;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		 
		setContentView(R.layout.loginscreen_2);
		
		WellconnectedConstant.ScreenName="";
		dbhelper=new DataBaseManager(LoginActivity2.this);
		mySqldb=dbhelper.getReadableDatabase();
		datasourse = new MatchDataSource(LoginActivity2.this);

		uiHelper = new UiLifecycleHelper(this, callback);
		uiHelper.onCreate(savedInstanceState);

		GCMRegistrar.checkDevice(this);
		GCMRegistrar.checkManifest(this);
		
		ll_back=(LinearLayout) findViewById(R.id.ll_back)
				;		
						ll_back.setOnClickListener(new OnClickListener() {
							
							@Override
							public void onClick(View arg0) {
								// TODO Auto-generated method stub
								finish();
							}
						});
		pref = this.getSharedPreferences("LoginInfo", this.MODE_WORLD_READABLE);
		
		if(pref.getString("User_id", "").equals(""))
		{
			
		}
		else 
		{
			if(pref.getString("is_remember", "").equals("true"))
			{
			Intent intent = new Intent(LoginActivity2.this, MainActivity.class);
			startActivity(intent);
			finish();
			}
		}

		final String regId = GCMRegistrar.getRegistrationId(this);

		if (regId.equals("")) {
			GCMRegistrar.register(this, WellconnectedUtills.GCMSenderId);
		} else {
			Log.v("", "Already registered:  " + regId);
		}
		
		ed_password = (EditText) findViewById(R.id.ed_password);

		ed_email = (EditText) findViewById(R.id.ed_email);
		
		if(!pref.getString("Resigter_email", "").equals(""))
		{
			ed_email.setText(pref.getString("Resigter_email", ""));
		}
		
		img_rember = (ImageButton) findViewById(R.id.img_rember);
		img_rember.setOnClickListener(this);

		img_login_btn = (ImageButton) findViewById(R.id.img_login_btn);
		img_login_btn.setOnClickListener(this);

		img_fb_btn = (ImageButton) findViewById(R.id.img_fb_btn);
		img_fb_btn.setOnClickListener(this);

		txt_forgot_pwd = (TextView) findViewById(R.id.txt_forgot_pwd);
		txt_forgot_pwd.setOnClickListener(this);

		dialog = new Dialog(this, android.R.style.Theme_Translucent);
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

		dialog.setContentView(R.layout.custom_dialog_forgot_password);
		forgotPasswordDialogButtonOk = (Button) dialog.findViewById(R.id.custom_dialog_ok);
		forgotPasswordDialogButtonCancel = (Button) dialog.findViewById(R.id.custom_dialog_cancel);
		forgotPasswordDialogEditText = (EditText) dialog.findViewById(R.id.custom_dialog_edit_text);
		forgotPasswordDialogButtonOk.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				String emailId = forgotPasswordDialogEditText.getText().toString().trim();

				if (emailId.equals("")) {

					WellconnectedUtills.customDialog(LoginActivity2 .this, "Please Enter Email Id !");

				} else if (!checkEmail(emailId)) {

					WellconnectedUtills.customDialog(LoginActivity2.this, "Enter valid email");

				} else {
					dialog.dismiss();
					new ForgotPasswordTask1().execute(emailId);

				}

			}
		});

		forgotPasswordDialogButtonCancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				dialog.dismiss();

				forgotPasswordDialogEditText.setText("");
			}
		});
	}
	/**
	 * Method for set the permission in facebook
	 * 
	 * @return
	 */
	private boolean hasEmailPermission() {

		Session session = Session.getActiveSession();

		return session != null && session.getPermissions().contains("email");

	}

	// Method for face book login
	private Session.StatusCallback callback = new Session.StatusCallback() {
		@Override
		public void call(Session session, final SessionState state, Exception exception) {

			if (session.isOpened()) {

				if (hasEmailPermission()) {

					Request.executeMeRequestAsync(session, new GraphUserCallback() {

						@Override
						public void onCompleted(GraphUser user, Response response) {
							System.out.println("user"+user);
							// TODO Auto-generated method stub
							if (user != null) {
								try {

									String registrantEmailSocial = response.getGraphObject().getInnerJSONObject().getString("email").toString();

									Log.d("registrantEmailSocial", registrantEmailSocial);

									String facebookID = user.getId();
									
									String fb_email = registrantEmailSocial;
									  
									String fb_username = user.getName();
								
									String  first_name =
									  user.getFirstName(); 
									String last_name =
									  user.getLastName();
									  
									  String stateName = "";
									 
									  String dob=user.getBirthday();
									//  String gender=user.get
									  String get_gender = (String) user.getProperty("gender");
									  
									String  imgurl="https://graph.facebook.com/"+user.getId()+"/picture?type=large";
									 // profile_url=imgurl; 
									
									  String facebook_friends="https://graph.facebook.com/"+user.getId()+"/friendlists";

									new FbLoginTask().execute(fb_email,facebookID,fb_username,dob,get_gender,imgurl);
									
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						}
					});
				} else if (!hasEmailPermission()) {
					session.requestNewPublishPermissions(new Session.NewPermissionsRequest(LoginActivity2.this, PERMISSIONS));

					Request request = Request.newStatusUpdateRequest(session, "Temple Hello Word Sample", new Request.Callback() {
						@Override
						public void onCompleted(Response response) {
							Log.d("", "fb:done = " + response.getGraphObject() + "," + response.getError());
						}
					});
					request.executeAsync();
				}

			}

		}
	};
	/*************************************************************************
	 * F A C E B O O K *
	 ************************************************************************/
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {

		// facebook
		uiHelper.onActivityResult(requestCode, resultCode, data);

	}

	@Override
	protected void onPause() {
		super.onPause();
		uiHelper.onPause();
	}

	@Override
	protected void onResume() {
		super.onResume();
		uiHelper.onResume();
	}

	private boolean checkEmail(String email) {
		return EMAIL_ADDRESS_PATTERN.matcher(email).matches();
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {

		case R.id.txt_forgot_pwd:
			
			forgotPasswordDialogEditText.setText("");
			dialog.show();
			break;
		case R.id.img_login_btn:
			InputMethodManager imm = (InputMethodManager) getSystemService(LoginActivity2.this.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(v.getApplicationWindowToken(), 0);

			str_email = ed_email.getText().toString().trim();

			str_pwd = ed_password.getText().toString().trim();

			if (str_email.equals("")) {
				WellconnectedUtills.customDialog(LoginActivity2.this, "Please enter Email Id");
				ed_email.setText("");
				ed_email.requestFocus();

			} else if (!checkEmail(str_email)) {

				WellconnectedUtills.customDialog(LoginActivity2.this, "Please Enter Valid Email Id");

				ed_email.requestFocus();

			} else if (str_pwd.equals("")) {

				WellconnectedUtills.customDialog(LoginActivity2.this, "Please enter password");

				ed_password.requestFocus();
				ed_password.setText("");

			} else if (str_pwd.length() < 6) {

				WellconnectedUtills.customDialog(LoginActivity2.this, "Password should be 6 character long");

				ed_password.setText("");

				ed_password.requestFocus();

			} else {

				if (WellconnectedUtills.isNetworkAvailable(LoginActivity2.this)) {
					new LoginTask().execute();

				} else {
					WellconnectedUtills.customDialog(LoginActivity2.this, "Internet connection is not available");

				}
			}
			break;
		case R.id.img_fb_btn:

			
			if (WellconnectedUtills.isNetworkAvailable(LoginActivity2.this)) {
					//isLoginWithFBClicked = true;

				Session session = Session.getActiveSession();

				if (!session.isOpened() && !session.isClosed()) {

					session.openForRead(new Session.OpenRequest(LoginActivity2.this).setPermissions(PERMISSIONS).setCallback(callback));

				} else {

					Session.openActiveSession(LoginActivity2.this, true, callback);
					
					session.closeAndClearTokenInformation();
				}

				} else {
					WellconnectedUtills.customDialog(LoginActivity2.this, "Internet connection is not available");

			}
			break;

		case R.id.img_rember:

			if (is_remember.equals("true")) {
				is_remember = "false";
				 img_rember.setBackgroundResource(R.drawable.check);
			} else {
				is_remember = "true";
				img_rember.setBackgroundResource(R.drawable.checked);

			}

			break;
		}
	}
	
	
/** forgot pwd **/
	
	public class ForgotPasswordTask1 extends AsyncTask<String, Integer, String> {
		ProgressDialog progressDialog;
		JSONObject obj;
		ForgotBase forgotbase;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(LoginActivity2.this, "", "Please Wait");

		}

		@Override
		protected String doInBackground(String... params) {

			// TODO Auto-generated method stub

			forgotbase = WellconnectedParse.forgot_state(LoginActivity2.this, params[0]);

			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}

			if (forgotbase != null) {
				if (forgotbase.getResponse().getError() != null) {
					WellconnectedUtills.customDialog(LoginActivity2.this, forgotbase.getResponse().getError());

				} else {
					WellconnectedUtills.customDialog(LoginActivity2.this, forgotbase.getResponse().getSuccess());
					forgotPasswordDialogEditText.setText("");
					dialog.dismiss();
				}
			}

		}
	}
	/**fb login task **/

	public class FbLoginTask extends AsyncTask<String, Integer, String> {
		ProgressDialog progressDialog;
		JSONObject obj;
		LoginBase loginbase;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(LoginActivity2.this, "", "Please Wait");

		}

		@Override
		protected String doInBackground(String... params) {

			// TODO Auto-generated method stub

		loginbase = WellconnectedParse.Fblogin_state(LoginActivity2.this, params[0],params[1],params[2],params[3],params[4],params[5],GCMRegistrar.getRegistrationId(LoginActivity2.this));

			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}

			if (loginbase != null) {
				if (loginbase.getResponse().getError() != null) {
					WellconnectedUtills.customDialog(LoginActivity2.this, loginbase.getResponse().getError());

				} else {
					SharedPreferences.Editor editor = pref.edit();

					editor.putString("User_id", loginbase.getResponse().getUser_id());
					editor.putString("user_image", loginbase.getResponse().getUser_image());
					editor.putString("groupCount", loginbase.getResponse().getGroupCount());
					editor.putString("display_name", loginbase.getResponse().getDisplay_name());
					editor.putString("user_name", loginbase.getResponse().getUsername());
					editor.putString("chatCount", loginbase.getResponse().getChatCount());
					editor.putString("contactCount", loginbase.getResponse().getContactCount());
					editor.putString("is_remember", is_remember);
					editor.putString("device_token",  GCMRegistrar.getRegistrationId(LoginActivity2.this)
);
					editor.commit();
					
					//if that user id exist in db then replace it with new 
					
					datasourse.open();
					
						
						if(datasourse.getUserId_table_user(loginbase.getResponse().getUser_id()))
						{
							System.out.println("USER_ID_EXISTS");
							
							datasourse.updatetbl_user(WellconnectedConstant.login_id++,loginbase.getResponse().getUser_id(),
									loginbase.getResponse().getUsername(),
									loginbase.getResponse().getUser_image(),
									loginbase.getResponse().getDisplay_name(),"","","","","","");
						}
						else
						{
							datasourse.inserttbl_user(WellconnectedConstant.login_id++,loginbase.getResponse().getUser_id(),
									loginbase.getResponse().getUsername(),
									loginbase.getResponse().getUser_image(),
									loginbase.getResponse().getDisplay_name(),"","","","","","");
						}
					
				//insert data in tbl_user
					Intent intent = new Intent(LoginActivity2.this, MainActivity.class);
					startActivityForResult(intent, 1001);
					finish();
				}
			}
		}
	}
	/** login task **/
	public class LoginTask extends AsyncTask<String, Integer, String> {
		ProgressDialog progressDialog;
		JSONObject obj;
		LoginBase loginbase;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(LoginActivity2.this, "", "Please Wait");

		}

		@Override
		protected String doInBackground(String... params) {

			// TODO Auto-generated method stub

		loginbase = WellconnectedParse.login_state(LoginActivity2.this, str_email, str_pwd,   GCMRegistrar.getRegistrationId(LoginActivity2.this));

			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}

			if (loginbase != null) {
				if (loginbase.getResponse().getError() != null) {
					
					ed_email.setText("");
					ed_password.setText("");
					WellconnectedUtills.customDialog(LoginActivity2.this, loginbase.getResponse().getError());

				} else {
					SharedPreferences.Editor editor = pref.edit();

					editor.putString("User_id", loginbase.getResponse().getUser_id());
					editor.putString("user_image", loginbase.getResponse().getUser_image());
					editor.putString("groupCount", loginbase.getResponse().getGroupCount());
					editor.putString("display_name", loginbase.getResponse().getDisplay_name());
					editor.putString("user_name", loginbase.getResponse().getUsername());
					editor.putString("chatCount", loginbase.getResponse().getChatCount());
					editor.putString("contactCount", loginbase.getResponse().getContactCount());
					editor.putString("is_remember", is_remember);
					editor.putString("device_token",  GCMRegistrar.getRegistrationId(LoginActivity2.this)
);
					editor.commit();
					
					//if that user id exist in db then replace it with new 
					
					datasourse.open();
					
						
						if(datasourse.getUserId_table_user(loginbase.getResponse().getUser_id()))
						{
							System.out.println("USER_ID_EXISTS");
							
							datasourse.updatetbl_user(WellconnectedConstant.login_id++,loginbase.getResponse().getUser_id(),
									loginbase.getResponse().getUsername(),
									loginbase.getResponse().getUser_image(),
									loginbase.getResponse().getDisplay_name(),"","","","","","");
						}
						else
						{
							datasourse.inserttbl_user(WellconnectedConstant.login_id++,loginbase.getResponse().getUser_id(),
									loginbase.getResponse().getUsername(),
									loginbase.getResponse().getUser_image(),
									loginbase.getResponse().getDisplay_name(),"","","","","","");
						}
					
				//insert data in tbl_user
					Intent intent = new Intent(LoginActivity2.this, MainActivity.class);
					startActivityForResult(intent, 1001);
					finish();
				}
			}
		}
	}
}