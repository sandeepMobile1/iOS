//
//  ChatListData.m
//  ConstantLine
//
//  Created by octal i-phone2 on 8/13/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "ChatListData.h"

@implementation ChatListData

@synthesize name,image,message,charge,date,readStatus,userId,chatType,groupType,paidStatus,messasgeId,cellHeight,zChatId,requestStatus,groupUserTableId,groupOwnerId,groupJoinStatus,subscribeStatus,chatStatus,latestStatus,unreadMessageCount,groupParentId,groupSpecialType,groupCode;


@end
