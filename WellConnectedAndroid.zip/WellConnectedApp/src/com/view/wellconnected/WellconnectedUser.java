package com.view.wellconnected;

import java.net.URLEncoder;
import java.util.ArrayList;

import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.view.wellconnected.SkipActivity.SearchTask;
import com.wellconnected.bean.ChangePwdBase;
import com.wellconnected.bean.WellConnectedBase;
import com.wellconnected.bean.WellconnectedUserBean.existingusers;
import com.wellconnected.lazyload.ImageLoader_rounded;
import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

public class WellconnectedUser extends Activity{
	
	LinearLayout ll_back,ll_search;
	private EditText ed_search;
	private String user_id,search_name,friend_id,value;
	private ArrayList<existingusers>arr_wellconnected;
	private ListView list_wellconnected;
	private ImageLoader_rounded imgLoader;
	private TextView txt_noresult;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		setContentView(R.layout.wellconnected_user);
		WellconnectedConstant.ScreenName="";
		SharedPreferences	pref = this.getSharedPreferences("LoginInfo", this.MODE_WORLD_READABLE);
		
		arr_wellconnected=new ArrayList<existingusers>();
		txt_noresult=(TextView) findViewById(R.id.txt_noresult);
		
		imgLoader=new ImageLoader_rounded(WellconnectedUser.this);
		user_id=pref.getString("User_id", "");
		
		list_wellconnected=(ListView) findViewById(R.id.list_wellconnected);
		list_wellconnected.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
				// TODO Auto-generated method stub
			
				if(arr_wellconnected.get(arg2).getStatus().equals("0"))
				{
					WellconnectedConstant.Group_id="2";
				}
				else
				{
					//invisible
					WellconnectedConstant.Group_id="3";
				}
				Intent intent=new Intent(WellconnectedUser.this,UserInfoActivity.class);
				intent.putExtra("Friend_id", arr_wellconnected.get(arg2).getUser_id());
				intent.putExtra("thread_id","");
				startActivity(intent);
			}
		});
		
		
		ll_search=(LinearLayout) findViewById(R.id.ll_search);
		ll_search.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				search_name=ed_search.getText().toString().trim();
				InputMethodManager imm = (InputMethodManager)getSystemService(
						WellconnectedUser.this.INPUT_METHOD_SERVICE);
					imm.hideSoftInputFromWindow(v.getWindowToken(), 0);		
	
					if(search_name.length()>0)
					{
						if (WellconnectedUtills.isNetworkAvailable(WellconnectedUser.this)) 
						{
							new WellconnectedUserTask().execute();
						}
						else
						{
							WellconnectedUtills.customDialog(WellconnectedUser.this, "Internet connection is not available");
						
						}
					}
			}
		});
		
		ed_search=(EditText) findViewById(R.id.ed_search);
		ed_search.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
				// TODO Auto-generated method stub
				
				String value=arg0.toString().trim();
				if(value.length()==0)
				{
					if(arr_wellconnected!=null)
					{		arr_wellconnected.clear();
					}
					list_wellconnected.setAdapter(new WellconnectedAdapter());
					txt_noresult.setVisibility(View.VISIBLE);
					list_wellconnected.setVisibility(View.GONE);
				
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
				// TODO Auto-generated method stub
			}
			
			@Override
			public void afterTextChanged(Editable arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		ed_search.setText("");
		
		ed_search.setOnEditorActionListener(new TextView.OnEditorActionListener() {
		    @Override
		    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
		        if (actionId == EditorInfo.IME_ACTION_SEARCH) {
		        	
		        	InputMethodManager imm = (InputMethodManager)getSystemService(
		        			WellconnectedUser.this.INPUT_METHOD_SERVICE);
		        		imm.hideSoftInputFromWindow(ed_search.getWindowToken(), 0);
		        	
		        		search_name=ed_search.getText().toString().trim();
					
							if(search_name.length()>0)
							{
								if (WellconnectedUtills.isNetworkAvailable(WellconnectedUser.this)) 
								{
									new WellconnectedUserTask().execute();
								}
								else
								{
									WellconnectedUtills.customDialog(WellconnectedUser.this, "Internet connection is not available");
									
								
								}
							}
						
		            return true;
		        }
		        return false;
		    }
		});
		ed_search.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void afterTextChanged(Editable arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		ll_back=(LinearLayout) findViewById(R.id.ll_back);
		ll_back.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				finish();
			}
		});
		txt_noresult.setVisibility(View.VISIBLE);
		list_wellconnected.setVisibility(View.GONE);
	
	}
	
	/** wellconnected users  task **/
	public class addUserTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		ChangePwdBase chatbase;
;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(WellconnectedUser.this, "", "Please Wait");
			
		}
		@Override
		protected String doInBackground(String... params) {
			
			// TODO Auto-generated method stub
			chatbase = WellconnectedParse.addUser(WellconnectedUser.this, user_id, friend_id,value);

				//response=CCRApplicationParse.ChangePwd(ChangePasswordActivity.this, user_id, ed_password.getText().toString(), ed_new_pwd.getText().toString());
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			if (chatbase != null) {
				if (chatbase.getResponse().getError()!=null) {
					
					WellconnectedUtills.customDialog(WellconnectedUser.this, chatbase.getResponse().getError());

				} else {
					
				//	WellconnectedUtills.customDialog(WellconnectedUser.this, chatbase.getResponse().getSuccess());

					AlertDialog dialog;
					 Builder builder = new AlertDialog.Builder(WellconnectedUser.this);
				      builder.setMessage(chatbase.getResponse().getSuccess());
				      builder.setCancelable(true);
				      builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
						
						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							if (WellconnectedUtills.isNetworkAvailable(WellconnectedUser.this)) 
							{
								new WellconnectedUserTask().execute();
							}
							else
							{
								WellconnectedUtills.customDialog(WellconnectedUser.this, "Internet connection is not available");
							}
						}
					});
				      dialog = builder.create();
				      dialog.show();
				}
			}
		}
	}
	
	/** wellconnected users  task **/
	public class WellconnectedUserTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		WellConnectedBase chatbase;
;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(WellconnectedUser.this, "", "Please Wait");
		}

		@Override
		protected String doInBackground(String... params) {
			
			// TODO Auto-generated method stub
			chatbase = WellconnectedParse.wellconnectedusers(WellconnectedUser.this, user_id, search_name);

			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			if (chatbase != null) {
				if (chatbase.getresponse()==null) {
					//WellconnectedUtills.customDialog(ChangePasswordActivity.this, chatbase.getResponse().getError());
				} else {
					
					arr_wellconnected=chatbase.getresponse().getExistingusers();
					
					if(arr_wellconnected.isEmpty())
					{
						txt_noresult.setVisibility(View.VISIBLE);
						list_wellconnected.setVisibility(View.GONE);
					}
					else
					{
						txt_noresult.setVisibility(View.GONE);
						list_wellconnected.setVisibility(View.VISIBLE);
						
					}
					System.out.println("SIZE"+arr_wellconnected.size());
				//	txt_aboutus.setText(chatbase.getHome().getMessage());
					//WellconnectedUtills.customDialog_2(ChangePasswordActivity.this, chatbase.getResponse().getSuccess(),ChangePasswordActivity.this);
					
					list_wellconnected.setAdapter(new WellconnectedAdapter());
					
				}
			}
		}
		
	}
	
	class ViewHolder
	{
		ImageView img_chat_image,img_online;
		TextView txt_group_name,txt_friend_name;
		LinearLayout linear_images;
		Button btn_Add;
	}
	class WellconnectedAdapter extends BaseAdapter
	{

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return arr_wellconnected.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			
		//	ViewHolder viewHolder=null;
			LayoutInflater inflater=WellconnectedUser.this.getLayoutInflater();
			convertView=inflater.inflate(R.layout.wellconected_row, null);
		
			ImageView img_chat_image=(ImageView)convertView.findViewById(R.id.img_chat_image);
			TextView  txt_friend_name=(TextView) convertView.findViewById(R.id.txt_friend_name);
			ImageView	 img_online=(ImageView) convertView.findViewById(R.id.img_online);
			Button btn_Add=(Button) convertView.findViewById(R.id.btn_add);
			
	
			txt_friend_name.setText(arr_wellconnected.get(position).getDisplayname().trim());
			 System.out.println("URL"+WellconnectedConstant.IMAGE_URL_1+arr_wellconnected.get(position).getUser_image());
				
			 
			 if(arr_wellconnected.get(position).getUser_image()==null)
			 {
				img_chat_image.setBackgroundResource(R.drawable.phone_pic_bg)	;	
			 }
			 else
			 {
				 if(arr_wellconnected.get(position).getUser_image().contains("https"))
				 {
						imgLoader.DisplayImage(arr_wellconnected.get(position).getUser_image(),img_chat_image);
						
				 }
				 else
				 {
						imgLoader.DisplayImage(WellconnectedConstant.IMAGE_URL_1+arr_wellconnected.get(position).getUser_image(),  img_chat_image);
						
				 }
						
			 }
				if(arr_wellconnected.get(position).getStatus().equals("0"))
				{
					btn_Add.setVisibility(View.VISIBLE);
				}
				else
				{
				btn_Add.setVisibility(View.INVISIBLE);
				WellconnectedConstant.Group_id="";
				}
			btn_Add.setFocusable(false);
			btn_Add.setTag(position);
			btn_Add.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View arg0) {
						
						 int pos=(Integer) arg0.getTag();
						friend_id=arr_wellconnected.get(pos).getUser_id();
						
						// TODO Auto-generated method stub
						final Dialog dialog=new  Dialog(WellconnectedUser.this);
						dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);						dialog.setContentView(R.layout.dialog_layout);
						final EditText ed_popup=(EditText) dialog.findViewById(R.id.ed_popup);
						
						Button btn_ok=(Button) dialog.findViewById(R.id.btn_ok);
						btn_ok.setOnClickListener(new OnClickListener() {
							
							@Override
							public void onClick(View arg0) {
								// TODO Auto-generated method stub
								
								 value=URLEncoder.encode(ed_popup.getText().toString().trim());
									
								if(value.length()>80)
								{
									WellconnectedUtills.customDialog(WellconnectedUser.this, "Maximum 80 char allowed");
									}
								else
								{
									//webservice 
									if(value.length()>0)
									{
										
										InputMethodManager imm = (InputMethodManager)getSystemService(
							        			WellconnectedUser.this.INPUT_METHOD_SERVICE);
							        		imm.hideSoftInputFromWindow(ed_popup.getWindowToken(), 0);
							        
										new addUserTask().execute();
										dialog.dismiss();
								
									}
								}
							}
						});
						Button btn_cancel=(Button) dialog.findViewById(R.id.btn_cancel);
						btn_cancel.setOnClickListener(new OnClickListener() {
							
							@Override
							public void onClick(View arg0) {
								// TODO Auto-generated method stub
								dialog.dismiss();
							}
						});
						dialog.show();
					}
				});
			return convertView;
		}
	}
	
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		InputMethodManager imm = (InputMethodManager)getSystemService(
			      WellconnectedUser.this.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(ed_search.getWindowToken(), 0);
	}
}
