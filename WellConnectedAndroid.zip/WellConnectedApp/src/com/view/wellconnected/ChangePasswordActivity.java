package com.view.wellconnected;

import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.wellconnected.bean.ChangePwdBase;
import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

public class ChangePasswordActivity extends Activity {

	private LinearLayout ll_back;
	private EditText ed_old_pwd,ed_new_pwd,ed_confirm_pwd;
	private Button btn_change_pwd;
	private String user_id,password,newpassword;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		setContentView(R.layout.change_password_screen);
		
		WellconnectedConstant.ScreenName="";
	SharedPreferences	pref = this.getSharedPreferences("LoginInfo", this.MODE_WORLD_READABLE);
		
	user_id=pref.getString("User_id", "");
	
		
		ed_old_pwd=(EditText) findViewById(R.id.ed_old_pwd);
		ed_new_pwd=(EditText) findViewById(R.id.ed_new_pwd);
		ed_confirm_pwd=(EditText) findViewById(R.id.ed_confirm_pwd);
		
		btn_change_pwd=(Button) findViewById(R.id.btn_change_pwd);
		btn_change_pwd.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				password=ed_old_pwd.getText().toString();
				newpassword=ed_new_pwd.getText().toString();
				{
				if(ed_old_pwd.getText().toString().equals(""))
				{
					WellconnectedUtills.customDialog(ChangePasswordActivity.this, "Please Enter existing password");
					
					ed_old_pwd.requestFocus();
			
					
				}
				  else if (ed_old_pwd.getText().toString().length() < 6 || ed_old_pwd.getText().toString().length()>15) {
					  
					  WellconnectedUtills.customDialog(ChangePasswordActivity.this, "Password should be at least 6 Characters and maximum 15 Characters.");
						
					  ed_old_pwd.requestFocus();
				
					  ed_old_pwd.setText("");
			
				 }
				else if(ed_new_pwd.getText().toString().equals(""))
				{
					WellconnectedUtills.customDialog(ChangePasswordActivity.this, "Please Enter New password");
					
					ed_new_pwd.requestFocus();
			
					
				}
				else if (ed_new_pwd.getText().toString().length() < 6 || ed_new_pwd.getText().toString().length() >15 ) {
					  
					WellconnectedUtills.customDialog(ChangePasswordActivity.this, "New Password should be at least 6 Characters and maximum 15 Characters.");
						
					  ed_new_pwd.requestFocus();
				
					  ed_new_pwd.setText("");
			
				 }
				else if(ed_confirm_pwd.getText().toString().equals(""))
				{
					WellconnectedUtills.customDialog(ChangePasswordActivity.this, "Please Enter Confirm password");
					
					ed_confirm_pwd.requestFocus();
			
					
				}
				else if (ed_confirm_pwd.getText().toString().length() < 6 || ed_confirm_pwd.getText().toString().length()>15) {
					  
					WellconnectedUtills.customDialog(ChangePasswordActivity.this, "Password should be at least 6 Characters and maximum 15 Characters.");
						
					  ed_confirm_pwd.requestFocus();
				
					  ed_confirm_pwd.setText("");
			
				 }
				else if (!(ed_new_pwd.getText().toString().equals(ed_confirm_pwd.getText().toString()))) {

					WellconnectedUtills.customDialog(ChangePasswordActivity.this, "New Password and Confirm password do not match");
					
					ed_confirm_pwd.requestFocus();
			
				}
				else
				{
					InputMethodManager imm = (InputMethodManager) getSystemService(ChangePasswordActivity.this.INPUT_METHOD_SERVICE);
					imm.hideSoftInputFromWindow(v.getApplicationWindowToken(),
							0);
					if (WellconnectedUtills.isNetworkAvailable(ChangePasswordActivity.this)) 
					{
						new ChangePwdTask().execute();
					}
					else
					{
						WellconnectedUtills.customDialog(ChangePasswordActivity.this, "Internet connection is not available");
						
					
					}

				}
			}
			}
		});
		
		ll_back=(LinearLayout) findViewById(R.id.ll_back);
		ll_back.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				finish();
			}
		});
	}
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		InputMethodManager imm = (InputMethodManager)getSystemService(
			      this.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(ed_confirm_pwd.getWindowToken(), 0);
	}
	/** change pwd task **/
	public class ChangePwdTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		ChangePwdBase chatbase;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(ChangePasswordActivity.this, "", "Please Wait");
		}
		@Override
		protected String doInBackground(String... params) {
			
			// TODO Auto-generated method stub
			chatbase = WellconnectedParse.changepwd(ChangePasswordActivity.this , user_id, password, newpassword);
				//response=CCRApplicationParse.ChangePwd(ChangePasswordActivity.this, user_id, ed_password.getText().toString(), ed_new_pwd.getText().toString());
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			if (chatbase != null) {
				if (chatbase.getResponse()==null) {
					//WellconnectedUtills.customDialog(ChangePasswordActivity.this, chatbase.getResponse().getError());

				} else {
					if(chatbase.getResponse().error==null)
					{
						WellconnectedUtills.customDialog_2(ChangePasswordActivity.this, chatbase.getResponse().getSuccess(),ChangePasswordActivity.this);
						
					}
					else
					{
						WellconnectedUtills.customDialog(ChangePasswordActivity.this,  chatbase.getResponse().getError());
					}
				}
			}
		}
	}
}
