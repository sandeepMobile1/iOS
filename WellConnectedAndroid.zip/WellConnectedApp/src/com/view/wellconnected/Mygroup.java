package com.view.wellconnected;

import java.util.ArrayList;

import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.wellconnected.bean.MyGroupBase;
import com.wellconnected.bean.MygroupBean.GroupDetail;
import com.wellconnected.lazyload.ImageLoader;
import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

public class Mygroup extends Activity implements OnClickListener, OnScrollListener {
	
	private String user_id,page_no="1",total_count,search_name;
	private ListView list_group;
	private ArrayList<com.wellconnected.bean.MygroupBean.GroupDetail> arr_group;
	private EditText ed_search;
	private TextView txt_new;
	private LinearLayout ll_back,ll_loadmore,ll_search;
	private ImageLoader imgLoader;
	private int page_no_1=1,search_page=1;;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mygroup);
		WellconnectedConstant.is_menu_click=false;
		ll_loadmore=(LinearLayout) findViewById(R.id.ll_loadmore);
		
		ll_search=(LinearLayout) findViewById(R.id.ll_search);
		ll_search.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				search_name=ed_search.getText().toString().trim();
				search_page=page_no_1-1;
				new SearchTask().execute();
			}
		});
		imgLoader=new ImageLoader(Mygroup.this);
		
		SharedPreferences myPrefs = getSharedPreferences("LoginInfo",
				this.MODE_WORLD_READABLE);
		arr_group=new ArrayList<com.wellconnected.bean.MygroupBean.GroupDetail>();
		ed_search=(EditText) findViewById(R.id.ed_search);
		
		
		InputMethodManager imm = (InputMethodManager) getSystemService(Mygroup.this.INPUT_METHOD_SERVICE);
		imm.hideSoftInputFromWindow(ed_search.getApplicationWindowToken(), 0);

	
		ed_search.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub
				
				if(s.toString().equals(""))
				{
					
					arr_group=new ArrayList<com.wellconnected.bean.MygroupBean.GroupDetail>();
					page_no_1--;
					new MyGroupTask().execute();

				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				
			}
		});
		txt_new=(TextView) findViewById(R.id.txt_new);
		txt_new.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(Mygroup.this,StartGroupActivity.class);
				startActivity(intent);
				//finish();
			}
		});
		
		user_id=myPrefs.getString("User_id", "");
		
		list_group=(ListView) findViewById(R.id.list_group);
		list_group.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				System.out.println("JOIN"+arr_group.get(position).getJoin().equals("0"));
				/*if(arr_group.get(position).getJoin().equals("1")&&arr_group.get(position).getPaidStatus().equals("1")&&arr_group.get(position).getSubscribeStatus().equals("1"))
				{
					//chat class 
					Intent intent=new Intent(Mygroup.this,ChatActivity.class);
					startActivity(intent);
				}
				else
				{
					//group info class
				}*/
				if(arr_group.get(position).getJoin().equals("0"))
				{
					Intent intent=new Intent(Mygroup.this,GroupInfoActivity.class);
					startActivity(intent);
				}
			}
		});
		ll_back=(LinearLayout) findViewById(R.id.ll_back);
		ll_back.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
					
				/*	WellconnectedConstant.array_activity=new ArrayList<Activity>();
					WellconnectedConstant.array_activity.add(Mygroup.this);
					
					System.out.println("ARRAYSIZE"+WellconnectedConstant.array_activity.size());
					
					
					int width = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 4080, getResources().getDisplayMetrics());
					
					SlideoutActivity.prepare(Mygroup.this, R.id.rlmain, width);
					startActivity(new Intent(Mygroup.this,MenuActivity.class));
					overridePendingTransition(0, 0);
					
				*/
				
			}
		});
		
		if (WellconnectedUtills.isNetworkAvailable(Mygroup.this)) {
			new MyGroupTask().execute();

		} else {
			WellconnectedUtills.customDialog(Mygroup.this, "Internet connection is not available");

		}
		
		list_group.setOnScrollListener(Mygroup.this);

	/*	((LoadMoreListViewCode) list_group).setOnLoadMoreListener(new OnLoadMoreListener() {
			public void onLoadMore() {
				// Do the work to load more items at the end of list
				// here
				
				System.out.println("LOADMORE");
				if (WellconnectedUtills.isNetworkAvailable(Mygroup.this)) 
				{

					new MyGroupTask().execute();
	}
			}
		});*/
ll_loadmore.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				ed_search.setText("");
				if(arr_group.size()<Integer.parseInt(total_count))
				{
					ll_loadmore.setVisibility(View.VISIBLE);
					new MyGroupTask().execute();
				}
				else
				{
					ll_loadmore.setVisibility(View.VISIBLE);
					
				}
			}
		});
		
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		System.out.println("FINISHEDD");
		finish();
	}
	class GroupAdapter extends BaseAdapter
	{

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return arr_group.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			
			ViewHolder viewHolder=null;
			if(convertView==null)
			{
				LayoutInflater inflater=Mygroup.this.getLayoutInflater();
				convertView=inflater.inflate(R.layout.mygroup_row, null);
				  viewHolder = new ViewHolder();
				  viewHolder.img_group_image=(ImageView)convertView.findViewById(R.id.img_group_image);
				  viewHolder.txt_group_name=(TextView) convertView.findViewById(R.id.txt_group_name);
				  viewHolder.txt_detail=(TextView)convertView. findViewById(R.id.txt_detail);
				  viewHolder.txt_date=(TextView) convertView.findViewById(R.id.txt_date);
					//viewHolder.linear_images=(LinearLayout) convertView.findViewById(R.id.linear_images);
				  viewHolder.img_online=(ImageView) convertView.findViewById(R.id.img_online);
				  viewHolder.btn_share=(Button) convertView.findViewById(R.id.btn_share);
				  
				  
				 convertView.setTag(viewHolder);
			}
			else
			{
				viewHolder = (ViewHolder)convertView.getTag();
				
			}
			
			if(arr_group.get(position).getStatus().equals("read")||arr_group.get(position).getStatus().equals("1"))
			{
		
			
				 viewHolder.img_online.setVisibility(View.INVISIBLE);
			}
			else
			{
				
				 viewHolder.img_online.setVisibility(View.VISIBLE);
			
			}
			
			viewHolder.txt_group_name.setText(arr_group.get(position).getGroupName());
			
			
			if(arr_group.get(position).getIntro()==null)
			{
				viewHolder.txt_detail.setText(arr_group.get(position).getMessage());
				
			}
			else
			{
				viewHolder.txt_detail.setText(arr_group.get(position).getIntro());
				
			}
			System.out.println("URLL"+WellconnectedConstant.IMAGE_URL_4+arr_group.get(position).getGroupImage());
		if(arr_group.get(position).getJoin().equals("0"))
		{
			viewHolder.btn_share.setVisibility(View.VISIBLE);
			
		}
		else
		{
			viewHolder.btn_share.setVisibility(View.INVISIBLE);
			
		}
		
		if(arr_group.get(position).getGroupImage().equals(""))
		{
			 viewHolder.img_group_image.setImageResource(R.drawable.user_pic3);
		}
			 imgLoader.DisplayImage(WellconnectedConstant.IMAGE_URL_4+arr_group.get(position).getGroupImage(),  viewHolder.img_group_image);
			return convertView;
		}
		
		
	}
	
	class ViewHolder
	{
		ImageView img_group_image,img_online;
		TextView txt_group_name,txt_detail,txt_date;
		LinearLayout linear_images;
		Button btn_share;
	}
	
	/**search task **/
	
	
	public class SearchTask extends AsyncTask<String, Integer, String> {
		ProgressDialog progressDialog;
		JSONObject obj;
		MyGroupBase mygroup;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(Mygroup.this, "", "Please Wait");

		}

		@Override
		protected String doInBackground(String... params) {

			// TODO Auto-generated method stubfg

			mygroup = WellconnectedParse.my_group_search(Mygroup.this, user_id, search_page+"",search_name);
			
			
			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}

			if (mygroup != null) {
				if (mygroup.getResponse().getError() != null) {
					WellconnectedUtills.customDialog(Mygroup.this, mygroup.getResponse().getError());

				} else {
					
					 total_count=mygroup.getResponse().getTotalRecord();
					
					System.out.println("total_count"+total_count);
					arr_group=new ArrayList<com.wellconnected.bean.MygroupBean.GroupDetail>();
				//	arr_group=mygroup.getResponse().getGroupDetail();
					
					
					
					
					for(int i=0;i<mygroup.getResponse().getGroupDetail().size();i++)
					{
						
						
//						MygroupBean mMygroupBean = new MygroupBean();
//						GroupDetail mGroupDetail = mMygroupBean.new GroupDetail();
						GroupDetail obj=new com.wellconnected.bean.MygroupBean.GroupDetail();
						
						obj.setCreated(mygroup.getResponse().getGroupDetail().get(i).getCreated());
						obj.setGroupId(mygroup.getResponse().getGroupDetail().get(i).getGroupId());
						obj.setGroupImage(mygroup.getResponse().getGroupDetail().get(i).getGroupImage());
						obj.setGroupName(mygroup.getResponse().getGroupDetail().get(i).getGroupName());
						obj.setGroupOwnerId(mygroup.getResponse().getGroupDetail().get(i).getGroupOwnerId());
						obj.setGroupType(mygroup.getResponse().getGroupDetail().get(i).getGroupType());
						obj.setGroupUserTableId(mygroup.getResponse().getGroupDetail().get(i).getGroupUserTableId());
						obj.setIndividualCount(mygroup.getResponse().getGroupDetail().get(i).getIndividualCount());
						obj.setIntro(mygroup.getResponse().getGroupDetail().get(i).getIntro());
						obj.setJoin(mygroup.getResponse().getGroupDetail().get(i).getJoin());
						obj.setLatest(mygroup.getResponse().getGroupDetail().get(i).getLatest());
						obj.setPaidStatus(mygroup.getResponse().getGroupDetail().get(i).getPaidStatus());
						
						obj.setParent_id(mygroup.getResponse().getGroupDetail().get(i).getParent_id());
						obj.setRequest_status(mygroup.getResponse().getGroupDetail().get(i).getRequest_status());
						obj.setSpecial(mygroup.getResponse().getGroupDetail().get(i).getSpecial());
						
						
						obj.setStatus(mygroup.getResponse().getGroupDetail().get(i).getStatus());
						obj.setSubCharge(mygroup.getResponse().getGroupDetail().get(i).getSubCharge());
						obj.setSubscribeStatus(mygroup.getResponse().getGroupDetail().get(i).getSubscribeStatus());
						obj.setThreadId(mygroup.getResponse().getGroupDetail().get(i).getThreadId());
						arr_group.add(obj);
					}
					
					if(arr_group.size()==Integer.parseInt(total_count))
					{
						ll_loadmore.setVisibility(View.INVISIBLE);
						
					}
					else
					{
						ll_loadmore.setVisibility(View.VISIBLE);
						
					}
					list_group.setAdapter(new GroupAdapter());
					}
			}

		}
	}
	/** login task **/
	public class MyGroupTask extends AsyncTask<String, Integer, String> {
		ProgressDialog progressDialog;
		JSONObject obj;
		MyGroupBase mygroup;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(Mygroup.this, "", "Please Wait");

		}

		@Override
		protected String doInBackground(String... params) {

			// TODO Auto-generated method stub

			mygroup = WellconnectedParse.my_group(Mygroup.this, user_id, page_no_1+"");
			
			page_no_1++;

			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}

			if (mygroup != null) {
				if (mygroup.getResponse().getError() != null) {
					WellconnectedUtills.customDialog(Mygroup.this, mygroup.getResponse().getError());

				} else {
					
					 total_count=mygroup.getResponse().getTotal_records();
					
					System.out.println("total_count"+total_count);
					//arr_group=new ArrayList<com.wellconnected.bean.MygroupBean.GroupDetail>();
				//	arr_group=mygroup.getResponse().getGroupDetail();
					
					
					for(int i=0;i<mygroup.getResponse().getGroupDetail().size();i++)
					{
//						MygroupBean mMygroupBean = new MygroupBean();
//						GroupDetail mGroupDetail = mMygroupBean.new GroupDetail();
						GroupDetail obj=new com.wellconnected.bean.MygroupBean.GroupDetail();
						
						obj.setCreated(mygroup.getResponse().getGroupDetail().get(i).getCreated());
						obj.setGroupId(mygroup.getResponse().getGroupDetail().get(i).getGroupId());
						obj.setGroupImage(mygroup.getResponse().getGroupDetail().get(i).getGroupImage());
						obj.setGroupName(mygroup.getResponse().getGroupDetail().get(i).getGroupName());
						obj.setGroupOwnerId(mygroup.getResponse().getGroupDetail().get(i).getGroupOwnerId());
						obj.setGroupType(mygroup.getResponse().getGroupDetail().get(i).getGroupType());
						obj.setGroupUserTableId(mygroup.getResponse().getGroupDetail().get(i).getGroupUserTableId());
						obj.setIndividualCount(mygroup.getResponse().getGroupDetail().get(i).getIndividualCount());
						obj.setIntro(mygroup.getResponse().getGroupDetail().get(i).getIntro());
						obj.setJoin(mygroup.getResponse().getGroupDetail().get(i).getJoin());
						obj.setLatest(mygroup.getResponse().getGroupDetail().get(i).getLatest());
						obj.setPaidStatus(mygroup.getResponse().getGroupDetail().get(i).getPaidStatus());
						
						obj.setParent_id(mygroup.getResponse().getGroupDetail().get(i).getParent_id());
						obj.setRequest_status(mygroup.getResponse().getGroupDetail().get(i).getRequest_status());
						obj.setSpecial(mygroup.getResponse().getGroupDetail().get(i).getSpecial());
						
						
						obj.setStatus(mygroup.getResponse().getGroupDetail().get(i).getStatus());
						obj.setSubCharge(mygroup.getResponse().getGroupDetail().get(i).getSubCharge());
						obj.setSubscribeStatus(mygroup.getResponse().getGroupDetail().get(i).getSubscribeStatus());
						obj.setThreadId(mygroup.getResponse().getGroupDetail().get(i).getThreadId());
						arr_group.add(obj);
					}
					
					if(arr_group.size()==Integer.parseInt(total_count))
					{
						ll_loadmore.setVisibility(View.INVISIBLE);
						
					}
					else
					{
						ll_loadmore.setVisibility(View.VISIBLE);
						
					}
					list_group.setAdapter(new GroupAdapter());
					}
			}

		}
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId())
		{
		case R.id.ll_back:
		
			break;
		}
	}
	@Override
	public void onScrollStateChanged(AbsListView view, int scrollState) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void onScroll(AbsListView view, int firstVisibleItem,
			int visibleItemCount, int totalItemCount) {
		// TODO Auto-generated method stub
		
	}
	
}
