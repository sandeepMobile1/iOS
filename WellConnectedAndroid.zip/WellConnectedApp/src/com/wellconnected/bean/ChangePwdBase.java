package com.wellconnected.bean;

public class ChangePwdBase {

	private ChangePswdBean response;

	public ChangePswdBean getResponse() {
		return response;
	}

	public void setResponse(ChangePswdBean response) {
		this.response = response;
	}
	
}
