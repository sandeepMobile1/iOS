//
//  CommonFunction.h
//  MusicWorld
//
//  Created by Pankaj Tak on 06/08/10.
//  Copyright 2010 Thoughts in Reality. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface CommonFunction : NSObject {

	
	
}
-(void) checkAndCreateDatabase;
@end
