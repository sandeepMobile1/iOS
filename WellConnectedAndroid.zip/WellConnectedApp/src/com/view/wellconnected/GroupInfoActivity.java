package com.view.wellconnected;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.Request;
import com.facebook.Request.GraphUserCallback;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.SessionState;
import com.facebook.UiLifecycleHelper;
import com.facebook.model.GraphUser;
import com.wellconnected.bean.GropUserData;
import com.wellconnected.inapp.BillingHelper;
import com.wellconnected.inapp.BillingService;
import com.wellconnected.lazyload.ImageLoader_rounded;
import com.wellconnected.lazyload.ImageLoader_square;
import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.twitter.TwitterApp;
import com.wellconnected.twitter.TwitterApp.TwDialogListener;
import com.wellconnected.utills.JsonPostRequest1;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

public class GroupInfoActivity extends Activity  {
	private String Id,user_id,Join_status,Group_Type,special,key,ownerId,share_group_image,
	id,closeStatus,threadId,Share_GroupId,share_group_name,
	imageFilePath,imageType,Group_id,filePath="",twresult = "fail";
	private TextView txt_name,txt_intro,txt_trial,txt_free,
	txt_group_member,txt_group_number,txt_members;
	private ImageView img_pic;
	private ImageLoader_square img_loader;
	private ImageLoader_rounded img_loader_rounded;
	private Button btn_share_group,btn_join,btn_clear,btn_quit,btn_manage_group,btn_kick;
	private ImageButton img_star_1,img_star_2,img_star_3,
	img_star_4,img_star_5,img_rate_star_1,img_rate_star_2,
	img_rate_star_3,img_rate_star_4,img_rate_star_5,img_rate_owner_1,img_rate_owner_2,img_rate_owner_3,
	img_rate_owner_4,img_rate_owner_5;
	private LinearLayout ll_back,linear_container;
	MultiDirectionSlidingDrawer drawershere;
	private UiLifecycleHelper uiHelper;
	private static final List<String> PERMISSIONS = Arrays.asList("email","user_friends", "user_location", "user_hometown", "friends_hometown", "friends_location","read_friendlists");
	private Bitmap bitmap;
	private GridView grid_images;
	ArrayList<GropUserData> arr_groupss;
	GroupAsynTask task;
	TwitterApp mTwitter;
	
	private static final String TAG = "BillingService";

	private String plan = "";
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.groupinfo);
		
		startService(new Intent(GroupInfoActivity.this, BillingService.class));
		BillingHelper.setCompletedHandler(mTransactionHandler);
		
		WellconnectedConstant.ScreenName="";
		
		uiHelper = new UiLifecycleHelper(GroupInfoActivity.this, callback);
		uiHelper.onCreate(savedInstanceState);

		SharedPreferences	pref = this.getSharedPreferences("LoginInfo", this.MODE_WORLD_READABLE);
			
		user_id=pref.getString("User_id", "");
		
		/*if(WellconnectedConstant.groupInfoBitmap==null)
		{
			System.out.println("IMAGE NULL");
		}
		else
		{
			System.out.println("NOT NULL");
			//img_pic.setImageBitmap(WellconnectedConstant.groupInfoBitmap);
			WellconnectedConstant.groupInfoBitmap=null;
		}
		*/
		
		linear_container=(LinearLayout) findViewById(R.id.linear_container);
		img_loader=new ImageLoader_square(GroupInfoActivity.this);
		
		img_loader_rounded=new ImageLoader_rounded(GroupInfoActivity.this);
		drawershere = (MultiDirectionSlidingDrawer)findViewById(R.id.drawershere);
	    
	 	Button mCancel = (Button)findViewById(R.id.cancel_image_btn);
		mCancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				drawershere.animateClose();
			}
		});
		Button sms_image_btn = (Button)findViewById(R.id.sms_image_btn);

		sms_image_btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				drawershere.animateClose();
				String app_url="";
				TelephonyManager tMgr = (TelephonyManager)GroupInfoActivity.this.getSystemService(Context.TELEPHONY_SERVICE);
				String mPhoneNumber = tMgr.getLine1Number();
				
				 Uri sms_uri = Uri.parse("smsto:"+mPhoneNumber); 
		         Intent sms_intent = new Intent(Intent.ACTION_SENDTO, sms_uri); 
		         sms_intent.putExtra("sms_body", "I thought you would be interested to join this push-to-talk support group: " +share_group_name+
			         		"  First, install app WellConnected:"+app_url+"Then, search group #: "+Share_GroupId); 
			    
		         startActivity(sms_intent); 
			}
		});
		
		
		Button facebook_image_btn = (Button)findViewById(R.id.facebook_image_btn);

		facebook_image_btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				

				if (WellconnectedUtills.isNetworkAvailable(GroupInfoActivity.this)) {
					//isLoginWithFBClicked = true;
					drawershere.animateClose();
				Session session = Session.getActiveSession();

				if (!session.isOpened() && !session.isClosed()) {

					session.openForRead(new Session.OpenRequest(GroupInfoActivity.this).setPermissions(PERMISSIONS).setCallback(callback));

				} else {

					Session.openActiveSession(GroupInfoActivity.this, true, callback);
					
					//session.closeAndClearTokenInformation();
				}

				} else {
					WellconnectedUtills.customDialog(GroupInfoActivity.this, "Internet connection is not available");

			}
				
				
			
			}
		});
		Button twitter_image_btn = (Button)findViewById(R.id.twitter_image_btn);

		twitter_image_btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				loginTwitter();
				drawershere.animateClose();
			}
		});
		
		Button mail_btn = (Button)findViewById(R.id.mail_btn);
		mail_btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				drawershere.animateClose();

				Intent email = new Intent(Intent.ACTION_SEND);
				email.putExtra(Intent.EXTRA_EMAIL, new String[] { "" });
				email.putExtra(Intent.EXTRA_SUBJECT, "Push-to-talk support group for" + share_group_name);
				
				email.putExtra(Intent.EXTRA_TEXT, "I thought you would be interested to join this push-to-talk support group: " + share_group_name + "\nFirst, install app WellConnected" /*+ "app_url"*/ + "\nThen, search group #" + Share_GroupId+"\n\n\n"+"Sent from my android");
					email.setType("message/rfc822");
				startActivity(Intent.createChooser(email, "Choose an Email client :"));
					}
		});
		
		
		ll_back=(LinearLayout) findViewById(R.id.ll_back);
		ll_back.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				finish();
			}
		});
		
		Id=this.getIntent().getStringExtra("Id");
		user_id=this.getIntent().getStringExtra("user_id");
		Join_status=this.getIntent().getStringExtra("Join_status");
		Group_Type=this.getIntent().getStringExtra("Group_Type");

		if(Id==null&&user_id==null&&Join_status==null&&Group_Type==null)
		{
			Id=WellconnectedConstant.Id;
			user_id=WellconnectedConstant.user_id;
			Join_status=WellconnectedConstant.Join_status;
			Group_Type=WellconnectedConstant.Group_Type;
			
		}
		System.out.println("Id"+Id);
		
		if (WellconnectedUtills.isNetworkAvailable(GroupInfoActivity.this)) 
		{
			 task=new GroupAsynTask(GroupInfoActivity.this);
		task.execute(Id,user_id);
		}
		else
		{
			WellconnectedUtills.customDialog(GroupInfoActivity.this, "Internet connection is not available");
		
		}
	}
	
	
	public void callInAppPur(String periodType,String charge)
	{
		float chargee=Float.parseFloat(charge);
		int aa=(int) chargee;
		String charges=String.valueOf(aa);
		System.out.println("CHARGES"+charges);
		//make plan dynamic 
		if(periodType.equals("1"))
		{
			//monthly
			if(charges.equals("null"))
			{
				
			}
			else
			{
				  //if period type monthly or anually 
				 // condition according to plan
					if(charges.equals("1"))
					{
						plan = WellconnectedConstant.MONTH_PRODUCT_ID_1;
					}
					else if(charges.equals("2"))
					{
						plan = WellconnectedConstant.MONTH_PRODUCT_ID_2;
					}
					else if(charges.equals("5"))
					{
						plan = WellconnectedConstant.MONTH_PRODUCT_ID_5;
					}
					else if(charges.equals("10"))
					{
						plan = WellconnectedConstant.MONTH_PRODUCT_ID_10;
					}
					else if(charges.equals("20"))
					{
						plan = WellconnectedConstant.MONTH_PRODUCT_ID_20;
					}
					else if(charges.equals("50"))
					{
						plan = WellconnectedConstant.MONTH_PRODUCT_ID_50;
					}
					else if(charges.equals("100"))
					{
						plan = WellconnectedConstant.MONTH_PRODUCT_ID_100;
					}
			}
		}
		else
		{
			//anualyy
			if(charges.equals("null"))
			{
			}
			else
			{
					if(charges.equals("1"))
					{
						plan = WellconnectedConstant.YEAR_PRODUCT_ID_1;
					}
					else if(charges.equals("2"))
					{
						plan = WellconnectedConstant.YEAR_PRODUCT_ID_2;
					}
					else if(charges.equals("5"))
					{
						plan = WellconnectedConstant.YEAR_PRODUCT_ID_5;
					}
					else if(charges.equals("10"))
					{
						plan = WellconnectedConstant.YEAR_PRODUCT_ID_10;
					}
					else if(charges.equals("20"))
					{
						plan = WellconnectedConstant.YEAR_PRODUCT_ID_20;
					}
					else if(charges.equals("50"))
					{
						plan = WellconnectedConstant.YEAR_PRODUCT_ID_50;
					}
					else if(charges.equals("100"))
					{
						plan = WellconnectedConstant.YEAR_PRODUCT_ID_100;
					}
			}
			
		}
		System.out.println("PLAN"+plan);
		
		Toast.makeText(GroupInfoActivity.this, plan, Toast.LENGTH_SHORT).show();
		if (BillingHelper.isBillingSupported()) {
			//plan = WellconnectedConstant.MONTH_PRODUCT_ID_1;
			//Toast.makeText(GroupInfoActivity.this, plan, Toast.LENGTH_SHORT).show();
			
			System.out.println("productPlan: " + plan);

			BillingHelper.requestPurchase(getApplicationContext(), plan);

		} else {
			//Toast.makeText(GroupInfoActivity.this, "Your device is not supported InApp purchased please check your Google account", Toast.LENGTH_SHORT).show();
			Log.i("InApp", "Can't purchase on this device");
		}
	}
	public String loginTwitter() {
		mTwitter = new TwitterApp(GroupInfoActivity.this,WellconnectedUtills.CONSUMER_KEY,WellconnectedUtills. CONSUMER_SECRET);
		mTwitter.setListener(mTwLoginDialogListenerforPost);
		
		if (mTwitter.hasAccessToken()) {
		
			new PostPhotoToTwitterTask().execute();
		} else {
			
			mTwitter.authorize();
			new PostPhotoToTwitterTask().execute();
		}
		return twresult;
	}
	
	private TwDialogListener mTwLoginDialogListenerforPost = new TwDialogListener() {
		@Override
		public void onError(String value) {
			mTwitter.resetAccessToken();
		}

		@Override
		public void onComplete(String value) {
			//postReview(commentTextFb, imagePath);
			
		
			new PostPhotoToTwitterTask().execute();
			

		}
	};
	class PostPhotoToTwitterTask extends AsyncTask<Void, Void, Void> {
		ProgressDialog progressDialog;
		
		@Override
		public void onPreExecute() {
			progressDialog = ProgressDialog.show(GroupInfoActivity.this, "Share On Twitter", "Please Wait....");
		}

		@Override
		public Void doInBackground(Void... params) {
            try {
				filePath = WellconnectedUtills.DownloadFile(WellconnectedConstant.IMAGE_URL_4+share_group_image, "test.png");
			} catch (IOException e) {
				e.printStackTrace();
			}
			return null;
		}

		@Override
		public void onPostExecute(Void result) {
			progressDialog.dismiss();
			
			postReview("octaltest", filePath);
		//	postToTwitter("octaltest", filePath);
		}
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// return to the App's Home Activity
		// System.out.println("BACKKKKKKK");

		if ((keyCode == KeyEvent.KEYCODE_BACK)) {

			System.out.println("BACKKKKKKK");
			if(drawershere.isOpened())
			{
				drawershere.close();
			}
			else
			{
				finish();
			}
		}
		  return true;  
	}
	
	void postReview(String review, final String dropPinImageUrl) {

		final Dialog dialog = new Dialog(GroupInfoActivity.this);
		dialog.getWindow();
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.dialog_twitter);
		dialog.setTitle("StormPins");

		Button cancelBtn = (Button) dialog.findViewById(R.id.twiiter_cancelbutton);
		Button postBtn = (Button) dialog.findViewById(R.id.twiiter_postbutton);
		final EditText postEditText = (EditText) dialog.findViewById(R.id.editText);

		ImageView shareimge = (ImageView) dialog.findViewById(R.id.shareimageimageView);
		
				   try {
        URL url = new URL(WellconnectedConstant.IMAGE_URL_4+share_group_image);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setDoInput(true);
        connection.connect();
        InputStream input = connection.getInputStream();
        Bitmap myBitmap = BitmapFactory.decodeStream(input);
        shareimge.setImageBitmap(myBitmap);
    } catch (IOException e) {
        e.printStackTrace();
       
    }
		
		postEditText.setText(review);

		// Set Data
		try {
			if (!dropPinImageUrl.equals("") && !dropPinImageUrl.equalsIgnoreCase("null")) {
			//	imnew.displayImage("http://images.stormpins.com/images/" + dropPinImageUrl + "?s3path=/site-uploads/pin-Images/&size=100&square=true", shareimge, options);
			} else {
			//	imnew.displayImage("http://apps-test.stormpins.com/img/pinresponder/stormpins_logo_90x90.png", shareimge, options);

			}

		} catch (Exception e) {
		}

		// if button is clicked, close the custom dialog
		cancelBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});

		postBtn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {

				dialog.dismiss();

				String twitterShareTxt = postEditText.getText().toString().trim();
				try {
				
					postToTwitter(twitterShareTxt, filePath);

				} catch (Exception e) {
				}
			}
		});
		dialog.show();
	}
	
	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (msg.what == 0) {

				WellconnectedUtills.customDialog(GroupInfoActivity.this, "Thank you for sharing on twitter");

			} else if (msg.what == 1) {

				WellconnectedUtills.customDialog(GroupInfoActivity.this, "Twitter does not allow duplicate tweets !");
			} else if (msg.what == 2) {

				WellconnectedUtills.customDialog(GroupInfoActivity.this, "Internet connection not available");
			}
		}
	};
	private void postToTwitter(final String review, final String xx) {
		new Thread() {
			@Override
			public void run() {
				int what = 0;

				try {
					mTwitter.updateStatus(review, xx);
				} catch (Exception e) {
					what = 1;
					e.printStackTrace();
				}
				if (WellconnectedUtills.isNetworkAvailable(GroupInfoActivity.this)) {
					mHandler.sendMessage(mHandler.obtainMessage(what));
				} else {
					mHandler.sendMessage(mHandler.obtainMessage(2));
				}
			}
		}.start();
	}
	private boolean hasEmailPermission() {

		Session session = Session.getActiveSession();

		return session != null && session.getPermissions().contains("email");

	}
	private Session.StatusCallback callback = new Session.StatusCallback() {
		@Override
		public void call(Session session, final SessionState state, Exception exception) {

			if (session.isOpened()) {

				if (hasEmailPermission()) {

					Request.executeMeRequestAsync(session, new GraphUserCallback() {

						@Override
						public void onCompleted(GraphUser user, Response response) {
							System.out.println("user"+user);
							// TODO Auto-generated method stub
							if (user != null) {
								try {

									String registrantEmailSocial = response.getGraphObject().getInnerJSONObject().getString("email").toString();

									Log.d("registrantEmailSocial", registrantEmailSocial);

									String facebookID = user.getId();
									
									String fb_email = registrantEmailSocial;
									  
									String fb_username = user.getName();
								
									String  first_name =
									  user.getFirstName(); 
									String last_name =
									  user.getLastName();
									  
									  String stateName = "";
									 
									  String dob=user.getBirthday();
									//  String gender=user.get
									  String get_gender = (String) user.getProperty("gender");
									  
									String  imgurl="https://graph.facebook.com/"+user.getId()+"/picture?type=large";
									 // profile_url=imgurl; 
									
									  String facebook_friends="https://graph.facebook.com/"+user.getId()+"/friendlists";

									  WellconnectedUtills.publishFeedDialog(GroupInfoActivity.this, share_group_name,share_group_image,Share_GroupId);
									  
									//new FbLoginTask().execute(fb_email,facebookID,fb_username,dob,get_gender,imgurl);
									
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						}
					});
				} else if (!hasEmailPermission()) {
					session.requestNewPublishPermissions(new Session.NewPermissionsRequest(GroupInfoActivity.this, PERMISSIONS));

					Request request = Request.newStatusUpdateRequest(session, "Temple Hello Word Sample", new Request.Callback() {
						@Override
						public void onCompleted(Response response) {
							Log.d("", "fb:done = " + response.getGraphObject() + "," + response.getError());
						}
					});
					request.executeAsync();
				}

			}

		}
	};
	
	
	public Handler mTransactionHandler = new Handler() {

		public void handleMessage(android.os.Message msg) {

			try {
				Log.i(TAG, "Transaction complete");
				Log.i(TAG, "Transaction status: " + BillingHelper.latestPurchase.purchaseState);
				Log.i(TAG, "Item purchased is: " + BillingHelper.latestPurchase.productId);

				if (BillingHelper.isBillingSupported()) {

					System.out.println("secondPlan: " + plan);

					final String finalPlan = plan;

					new AlertDialog.Builder(GroupInfoActivity.this).setTitle("Buy").setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							BillingHelper.requestPurchase(getApplicationContext(), finalPlan);
						}
					}).show();

				} else {
					Log.i(TAG, "Can't purchase on this device");
				}
			} catch (Exception e) {

				Toast.makeText(GroupInfoActivity.this, "InApp Error.", Toast.LENGTH_LONG).show();

			}
		};
	};

	
	
	
	
	
	
	
	/*************************************************************************
	 * F A C E B O O K *
	 ************************************************************************/
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		   super.onActivityResult(requestCode, resultCode, data);
		   
		   System.out.println("Hi this is onActivityResult method"+resultCode);
		if(resultCode==Activity.RESULT_OK)
		{
				
			if(requestCode==1) 
			{
				 	
				try 
				{				
					Uri selectedimage = data.getData();
					String[] filepathcolumn = {MediaStore.Images.Media.DATA};

					Cursor cursor = getContentResolver().query(selectedimage,filepathcolumn, null, null, null);
					cursor.moveToFirst();

					int columnindex = cursor.getColumnIndex(filepathcolumn[0]);
					
					imageFilePath = cursor.getString(columnindex);				
					
					imageType = imageFilePath.substring(imageFilePath.lastIndexOf(".") + 1);										
					
					cursor.close();
					
					FileInputStream in;
					
					try 
					{
							
						in = new FileInputStream(imageFilePath);
						
						BitmapFactory.Options options = new BitmapFactory.Options();
						options.inSampleSize = 4;
						bitmap = BitmapFactory.decodeStream(in,null,options);
						  System.out.println("Hi this is onActivityResult method"+requestCode);
						  WellconnectedConstant.groupInfoBitmap=bitmap;
						//img_user_pic.setImageBitmap(bitmap);
						img_pic.setImageBitmap(bitmap);
						new UploadImageTask().execute();
							
					}
					catch (Exception e) 
					{
						Log.e("Error reading file", e.toString());
						
						if(e instanceof FileNotFoundException)
						{
							Toast.makeText(GroupInfoActivity.this,"Network Synchronized Image Does Not Exists", Toast.LENGTH_SHORT).show();
						}
					}				
					
				} 				
				catch (Exception e) 
				{					
					e.printStackTrace();
					
					if(e instanceof FileNotFoundException)
					{
						Toast.makeText(GroupInfoActivity.this,"Network Synchronized Image Does Not Exists", Toast.LENGTH_SHORT).show();
					}
				}
			}
			else if (requestCode == 2) 
			{			
				File Imagedirectory = new File(Environment.getExternalStorageDirectory()+ "/MyImage");
				if (!Imagedirectory.exists()) 
				{
					Imagedirectory.mkdir();
				}

				int quality = 5;
				String ssss = UUID.randomUUID().toString();
				File file = new File(Imagedirectory.getPath() + "/" + ssss + ".png");
				
				imageFilePath=file.getPath();
				imageType="png";
				
				try 
				{
					if (data.getExtras() != null) 
					{
						bitmap = (Bitmap) data.getExtras().get("data");

						try 
						{
							file.createNewFile();
							FileOutputStream fileOutputStream = new FileOutputStream(file);
							BufferedOutputStream bos = new BufferedOutputStream(fileOutputStream);
							bitmap.compress(CompressFormat.PNG, quality, bos);
							WellconnectedConstant.groupInfoBitmap=bitmap;
							//img_user_pic.setImageBitmap(bitmap);
							img_pic.setImageBitmap(WellconnectedUtills.getRoundedShape(bitmap));
									bos.flush();
							bos.close();
							new UploadImageTask().execute();
						} 
						catch (Exception e) 
						{
							e.printStackTrace();
						}												
					}
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}			
			}	
			else
			{
				System.out.println("FRAGMENT_ONACTIVITY");
				// facebook
				uiHelper.onActivityResult(requestCode, resultCode, data);

			}
		}
		
	}

	@Override
	public void onPause() {
		super.onPause();
		uiHelper.onPause();
	}

	@Override
	public void onResume() {
		super.onResume();
		uiHelper.onResume();
	}
	
	
	/** upload image **/
	
	public class UploadImageTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		String response;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(GroupInfoActivity.this, "", "Please Wait");
		}
		@Override
		protected String doInBackground(String... params) {
			
			ArrayList<String> fileArrayList = new ArrayList<String>();
			//image file path name
			
			if(imageFilePath==null||imageFilePath.equals(""))
			{
				imageFilePath="";
			}
			else
			{
				File file = new File(imageFilePath);
				fileArrayList.add(file.getPath());
			}
				
			ArrayList<String[]> dataArrayList = new ArrayList<String[]>();
			String[] a = new String[2];

			a[0] = "userId";
			a[1] = user_id;
			dataArrayList.add(a);

			String[] b = new String[2];

			b[0] = "groupId";
			b[1] = Group_id;
			dataArrayList.add(b);

			String URL = WellconnectedConstant.WEBSERVICE_URL + "groupEditImage";

			
			//give image name
			
			 response=new JsonPostRequest1().doPostWithFile1(URL, dataArrayList, fileArrayList, "testimage", "png");
			System.out.println("response"+response);
			
				Log.i("gotResponseeeeeeee", response);
			
			
			return null;
		}
		/* (non-Javadoc)
		 * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
		 */
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			
			if(response!=null)
			{
				JSONObject object,object_res = null;
				try {
					object = new JSONObject(response);
					 object_res=object.getJSONObject("response");
					
				} catch (JSONException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				if(object_res.has("success"))
				{/*
					String user_id,username,message,profile_image;

					try {
						user_id=object_res.getString("userId");
						
						try {
							profile_image=object_res.getString("userImage");
						} catch (Exception e) {
							// TODO: handle exception
						}
						SharedPreferences.Editor editor = pref.edit();
						
						//editor.putString("User_id", user_id);
						editor.putString("Resigter_email", email);
						editor.commit();
					
						WellconnectedUtills.customDialog_2(ResigterActivity.this,object_res.getString("success"),ResigterActivity.this);
						
						//	Intent intent=new Intent(ResigterActivity.this,MainActivity.class);
						//startActivity(intent);
						//finish();
				
						
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				*/}
				else
				{/*
					
					try {
						WellconnectedUtills.customDialog(ResigterActivity.this,object_res.getString("error"));
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				*/}
			}
		}
	}
	/** quit group **/
	
	public class QuitGroupTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		String chatbase;
;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(GroupInfoActivity.this, "", "Please Wait");
			
		}

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			chatbase = WellconnectedParse.QuitgroupTask(GroupInfoActivity.this,user_id,Id,ownerId,"0");

			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			
			if (chatbase != null) {
				JSONObject obj;
				try {
					obj = new JSONObject(chatbase);
					JSONObject obj_res=obj.getJSONObject("response");
					if(obj_res.has("success"))
					{
						
						WellconnectedUtills.customDialog(GroupInfoActivity.this, obj_res.getString("success"));
						
					}
					else
					{
						WellconnectedUtills.customDialog(GroupInfoActivity.this, obj_res.getString("error"));
						
					}
					
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	//clear all group messages
	public class ClearMsgTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		String chatbase;
;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(GroupInfoActivity.this, "", "Please Wait");
		}
		@Override
		protected String doInBackground(String... params) {
			
			chatbase = WellconnectedParse.ClearMsgTask(GroupInfoActivity.this,user_id,Id);
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			if (chatbase != null) {
				JSONObject obj;
				try {
					obj = new JSONObject(chatbase);
					JSONObject obj_res=obj.getJSONObject("response");
					if(obj_res.has("success"))
					{
						WellconnectedUtills.customDialog_2(GroupInfoActivity.this, "All messages has been deleted successfully",GroupInfoActivity.this);
						
						WellconnectedConstant.refrence.finish();
					}
					else
					{
						WellconnectedUtills.customDialog(GroupInfoActivity.this, obj_res.getString("error"));
					}
					
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	//join asyntaskk
	
	public class JoinTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		String chatbase;
;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(GroupInfoActivity.this, "", "Please Wait");
		}

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			chatbase = WellconnectedParse.JoinTask(GroupInfoActivity.this,key,user_id,Id,ownerId);

			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			if (chatbase != null) {
				JSONObject obj;
				try {
					obj = new JSONObject(chatbase);
					JSONObject obj_res=obj.getJSONObject("response");
					if(obj_res.has("success"))
					{
						WellconnectedUtills.customDialog(GroupInfoActivity.this, obj_res.getString("success"));
					}
					else
					{
						WellconnectedUtills.customDialog(GroupInfoActivity.this, obj_res.getString("error"));
					}
					
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
	@Override
	public Dialog onCreateDialog(int id,final Bundle args)
	{
		AlertDialog dialog=null;
		switch(id)
		{					
			/*case 0: 
			{
				return new DatePickerDialog(this, datePickerListener,Integer.parseInt(year), Integer.parseInt(month),Integer.parseInt(day));
			}	*/
			case 1:
			{
				String options[];
				               
				options=new String[]{"Gallery","Camera"};
				
				AlertDialog.Builder builder=new AlertDialog.Builder(this);
				builder.setSingleChoiceItems(options,-1, new DialogInterface.OnClickListener() 
				{					
					@Override
					public void onClick(DialogInterface dialog, int which) 
					{
						if(which==0)
						{							
							try 
							{
								
								task.cancel(true);
								Intent i = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI);
								startActivityForResult(i, 1);
							} 
							catch (Exception e) 
							{
								 e.printStackTrace();
							}
						}
						else if(which == 1)
						{														
							try 
							{
								task.cancel(true);
								Intent i = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
								startActivityForResult(i, 2);
							}
							catch (Exception e) 
							{
								 e.printStackTrace();
							}
						}						
						removeDialog(1);
					}					
				}).setTitle("Upload Image From");
				
				dialog=builder.create();
				break;
			}			
			default:
			{
				break;
			}
		}
		return dialog;
	}
	private class GroupAsynTask extends AsyncTask<String, Integer, String>{
		public ProgressDialog progressDialog;
		public Context context;
		public String response;
		
		
		public GroupAsynTask(Context context)
		{
			this.context=context;
		
		}
		@Override
		
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(context, "", "Please Wait");
			
		}
		
		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			response = WellconnectedParse.groupInfo(context, params[0], params[1]);

			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			progressDialog.dismiss();
			
			if(!response.equals(""))
			{
				System.out.println("RESPONSE"+result);
				try {
					JSONObject obj=new JSONObject(response);
					JSONObject obj_res=obj.getJSONObject("response");
					JSONArray arr=obj_res.getJSONArray("Group");
					JSONObject objj=arr.getJSONObject(0);
					
					String name,trial,
					periodType,intro,image,paidStatus,groupCode,Charge,type,
					status,created,memberCount,user_ids,
					rating,numberOfUserGroupRating,groupRating,ownerRating,
					privilege,parent_id,transactionId,kickout;
					
					id=objj.getString("id");
					Group_id=id;
					name=objj.getString("name");
					threadId=objj.getString("threadId");
					ownerId=objj.getString("ownerId");
					trial=objj.getString("trial");
					periodType=objj.getString("periodType");
					intro=objj.getString("intro");
					image=objj.getString("image");
					paidStatus=objj.getString("paidStatus");
					groupCode=objj.getString("groupCode");
					Charge=objj.getString("Charge");
					type=objj.getString("type");
					status=objj.getString("status");
					closeStatus=objj.getString("closeStatus");
					created=objj.getString("created");
					memberCount=objj.getString("memberCount");
					created=objj.getString("created");
					user_ids=objj.getString("user_ids");
					rating=objj.getString("rating");
					numberOfUserGroupRating=objj.getString("numberOfUserGroupRating");
					groupRating=objj.getString("groupRating");
					ownerRating=objj.getString("ownerRating");
					privilege=objj.getString("privilege");
					parent_id=objj.getString("parent_id");
					special=objj.getString("special");
					transactionId=objj.getString("transactionId");
					kickout=objj.getString("kickout");
					
					Share_GroupId=groupCode;
					share_group_name=name;
					share_group_image=image;
					
					System.out.println("PERIOD_TYPE"+periodType);
					System.out.println("PERIOD_TYPE"+periodType);
					
					
					JSONArray arr_group=objj.getJSONArray("groupUser");
					arr_groupss=new ArrayList<GropUserData>();
					for(int i=0;i<arr_group.length();i++)
					{
						JSONObject obj_group=arr_group.getJSONObject(i);
						GropUserData group=new GropUserData();
						group.setDisplay_name(obj_group.getString("display_name"));
						group.setUser_id(obj_group.getString("user_id"));
						group.setUser_image(obj_group.getString("user_image"));;
						arr_groupss.add(group);
					}
					
					if(Join_status.equals("0"))
					{
						getGroupInfoView(rating,name,intro,trial,groupCode,memberCount,
								periodType,image,Charge);
					}
					else if(Join_status.equals("1")&&(!ownerId.equals(user_id))&&privilege.equals("0"))
					{
						getGroupInfoView_2(name,image,rating,intro,trial,groupCode,memberCount,
								periodType,Charge,groupRating,ownerRating);
						 
					}
					else if(privilege.equals("1")&&Join_status.equals("1")&&(ownerId.equals(user_id))&&Group_Type.equals("0"))
							{
						
						getGroupInfoView_3(name,image,rating,intro,trial,groupCode,memberCount,
								periodType,Charge);
						
							}
					else if(privilege.equals("1")&&Join_status.equals("1")&&!(ownerId.equals(user_id)))
					{
						getGroupInfoView_6(name,image,rating,groupRating,ownerRating,periodType,Charge,intro,trial,groupCode,memberCount);
					}
					else if(Group_Type.equals("1")&&(ownerId.equals(user_id)))
							{
						
						getGroupInfoView_4(name,image,memberCount,periodType,Charge);
							}
					else if(Group_Type.equals("1")&&!(ownerId.equals(user_id)))
					{
						
						getGroupInfoView_5(image);
					}
					
				
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}



	}
	/*@Override
	public void onTaskComplete(String result) {
		// TODO Auto-generated method stub
		System.out.println("RESPONSE"+result);
		try {
			JSONObject obj=new JSONObject(result);
			JSONObject obj_res=obj.getJSONObject("response");
			JSONArray arr=obj_res.getJSONArray("Group");
			JSONObject objj=arr.getJSONObject(0);
			
			String name,trial,
			periodType,intro,image,paidStatus,groupCode,Charge,type,
			status,created,memberCount,user_ids,
			rating,numberOfUserGroupRating,groupRating,ownerRating,
			privilege,parent_id,transactionId,kickout;
			
			id=objj.getString("id");
			name=objj.getString("name");
			threadId=objj.getString("threadId");
			ownerId=objj.getString("ownerId");
			trial=objj.getString("trial");
			periodType=objj.getString("periodType");
			intro=objj.getString("intro");
			image=objj.getString("image");
			paidStatus=objj.getString("paidStatus");
			groupCode=objj.getString("groupCode");
			Charge=objj.getString("Charge");
			type=objj.getString("type");
			status=objj.getString("status");
			closeStatus=objj.getString("closeStatus");
			created=objj.getString("created");
			memberCount=objj.getString("memberCount");
			created=objj.getString("created");
			user_ids=objj.getString("user_ids");
			rating=objj.getString("rating");
			numberOfUserGroupRating=objj.getString("numberOfUserGroupRating");
			groupRating=objj.getString("groupRating");
			ownerRating=objj.getString("ownerRating");
			privilege=objj.getString("privilege");
			parent_id=objj.getString("parent_id");
			special=objj.getString("special");
			transactionId=objj.getString("transactionId");
			kickout=objj.getString("kickout");
			
			Share_GroupId=groupCode;
			share_group_name=name;
			share_group_image=image;
			
			JSONArray arr_group=objj.getJSONArray("groupUser");
			arr_groupss=new ArrayList<GropUserData>();
			for(int i=0;i<arr_group.length();i++)
			{
				JSONObject obj_group=arr_group.getJSONObject(i);
				GropUserData group=new GropUserData();
				group.setDisplay_name(obj_group.getString("display_name"));
				group.setUser_id(obj_group.getString("user_id"));
				group.setUser_image(obj_group.getString("user_image"));;
				arr_groupss.add(group);
			}
			
			if(Join_status.equals("0"))
			{
				getGroupInfoView(rating,name,intro,trial,groupCode,memberCount,
						periodType,image,Charge);
			}
			else if(Join_status.equals("1")&&(!ownerId.equals(user_id))&&privilege.equals("0"))
			{
				getGroupInfoView_2(name,image,rating,intro,trial,groupCode,memberCount,
						periodType,Charge,groupRating,ownerRating);
				
			}
			else if(privilege.equals("1")&&Join_status.equals("1")&&(ownerId.equals(user_id))&&Group_Type.equals("0"))
					{
				
				getGroupInfoView_3(name,image,rating,intro,trial,groupCode,memberCount,
						periodType,Charge);
				
					}
			else if(privilege.equals("1")&&Join_status.equals("1")&&!(ownerId.equals(user_id)))
			{
				getGroupInfoView_6(name,image,rating,groupRating,ownerRating,periodType,Charge);
			}
			else if(Group_Type.equals("1")&&(ownerId.equals(user_id)))
					{
				
				getGroupInfoView_4(name,image,memberCount);
					}
			else if(Group_Type.equals("1")&&!(ownerId.equals(user_id)))
			{
				
				getGroupInfoView_5(image);
			}
			
		
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}*/
	
	void rate_owner_function(String rating)
	
	{
		if(rating.equals("0"))
		{
			img_rate_owner_1.setBackgroundResource(R.drawable.grey_star);
			img_rate_owner_2.setBackgroundResource(R.drawable.grey_star);
			img_rate_owner_3.setBackgroundResource(R.drawable.grey_star);
			img_rate_owner_4.setBackgroundResource(R.drawable.grey_star);
			img_rate_owner_5.setBackgroundResource(R.drawable.grey_star);
		}
		else if(rating.equals("1"))
		{
			img_rate_owner_1.setBackgroundResource(R.drawable.white_star);
			img_rate_owner_2.setBackgroundResource(R.drawable.grey_star);
			img_rate_owner_3.setBackgroundResource(R.drawable.grey_star);
			img_rate_owner_4.setBackgroundResource(R.drawable.grey_star);
			img_rate_owner_5.setBackgroundResource(R.drawable.grey_star);
	
		}
		else if(rating.equals("2"))
		{
			img_rate_owner_1.setBackgroundResource(R.drawable.white_star);
			img_rate_owner_2.setBackgroundResource(R.drawable.white_star);
			img_rate_owner_3.setBackgroundResource(R.drawable.grey_star);
			img_rate_owner_4.setBackgroundResource(R.drawable.grey_star);
			img_rate_owner_5.setBackgroundResource(R.drawable.grey_star);
	
		}
		else if(rating.equals("3"))
		{
			img_rate_owner_1.setBackgroundResource(R.drawable.white_star);
			img_rate_owner_2.setBackgroundResource(R.drawable.white_star);
			img_rate_owner_3.setBackgroundResource(R.drawable.white_star);
			img_rate_owner_4.setBackgroundResource(R.drawable.grey_star);
			img_rate_owner_5.setBackgroundResource(R.drawable.grey_star);
	
		}
		else if(rating.equals("4"))
		{
			img_rate_owner_1.setBackgroundResource(R.drawable.white_star);
			img_rate_owner_2.setBackgroundResource(R.drawable.white_star);
			img_rate_owner_3.setBackgroundResource(R.drawable.white_star);
			img_rate_owner_4.setBackgroundResource(R.drawable.white_star);
			img_rate_owner_5.setBackgroundResource(R.drawable.grey_star);
	
		}
		else
		{
			img_rate_owner_1.setBackgroundResource(R.drawable.white_star);
			img_rate_owner_2.setBackgroundResource(R.drawable.white_star);
			img_rate_owner_3.setBackgroundResource(R.drawable.white_star);
			img_rate_owner_4.setBackgroundResource(R.drawable.white_star);
			img_rate_owner_5.setBackgroundResource(R.drawable.white_star);
	
		}
	}
	void rate_group_function(String rating)
	
	{
		if(rating.equals("0"))
		{
			img_rate_star_1.setBackgroundResource(R.drawable.grey_star);
			img_rate_star_2.setBackgroundResource(R.drawable.grey_star);
			img_rate_star_3.setBackgroundResource(R.drawable.grey_star);
			img_rate_star_4.setBackgroundResource(R.drawable.grey_star);
			img_rate_star_5.setBackgroundResource(R.drawable.grey_star);
		}
		else if(rating.equals("1"))
		{
			img_rate_star_1.setBackgroundResource(R.drawable.white_star);
			img_rate_star_2.setBackgroundResource(R.drawable.grey_star);
			img_rate_star_3.setBackgroundResource(R.drawable.grey_star);
			img_rate_star_4.setBackgroundResource(R.drawable.grey_star);
			img_rate_star_5.setBackgroundResource(R.drawable.grey_star);
	
		}
		else if(rating.equals("2"))
		{
			img_rate_star_1.setBackgroundResource(R.drawable.white_star);
			img_rate_star_2.setBackgroundResource(R.drawable.white_star);
			img_rate_star_3.setBackgroundResource(R.drawable.grey_star);
			img_rate_star_4.setBackgroundResource(R.drawable.grey_star);
			img_rate_star_5.setBackgroundResource(R.drawable.grey_star);
	
		}
		else if(rating.equals("3"))
		{
			img_rate_star_1.setBackgroundResource(R.drawable.white_star);
			img_rate_star_2.setBackgroundResource(R.drawable.white_star);
			img_rate_star_3.setBackgroundResource(R.drawable.white_star);
			img_rate_star_4.setBackgroundResource(R.drawable.grey_star);
			img_rate_star_5.setBackgroundResource(R.drawable.grey_star);
	
		}
		else if(rating.equals("4"))
		{
			img_rate_star_1.setBackgroundResource(R.drawable.white_star);
			img_rate_star_2.setBackgroundResource(R.drawable.white_star);
			img_rate_star_3.setBackgroundResource(R.drawable.white_star);
			img_rate_star_4.setBackgroundResource(R.drawable.white_star);
			img_rate_star_5.setBackgroundResource(R.drawable.grey_star);
	
		}
		else
		{
			img_rate_star_1.setBackgroundResource(R.drawable.white_star);
			img_rate_star_2.setBackgroundResource(R.drawable.white_star);
			img_rate_star_3.setBackgroundResource(R.drawable.white_star);
			img_rate_star_4.setBackgroundResource(R.drawable.white_star);
			img_rate_star_5.setBackgroundResource(R.drawable.white_star);
	
		}
	}
	void rating_function(String rating)
	
	{
		if(rating.equals("0"))
		{
			img_star_1.setBackgroundResource(R.drawable.grey_star);
			img_star_2.setBackgroundResource(R.drawable.grey_star);
			img_star_3.setBackgroundResource(R.drawable.grey_star);
			img_star_4.setBackgroundResource(R.drawable.grey_star);
			img_star_5.setBackgroundResource(R.drawable.grey_star);
		}
		else if(rating.equals("1"))
		{
			img_star_1.setBackgroundResource(R.drawable.white_star);
			img_star_2.setBackgroundResource(R.drawable.grey_star);
			img_star_3.setBackgroundResource(R.drawable.grey_star);
			img_star_4.setBackgroundResource(R.drawable.grey_star);
			img_star_5.setBackgroundResource(R.drawable.grey_star);
	
		}
		else if(rating.equals("2"))
		{
			img_star_1.setBackgroundResource(R.drawable.white_star);
			img_star_2.setBackgroundResource(R.drawable.white_star);
			img_star_3.setBackgroundResource(R.drawable.grey_star);
			img_star_4.setBackgroundResource(R.drawable.grey_star);
			img_star_5.setBackgroundResource(R.drawable.grey_star);
	
		}
		else if(rating.equals("3"))
		{
			img_star_1.setBackgroundResource(R.drawable.white_star);
			img_star_2.setBackgroundResource(R.drawable.white_star);
			img_star_3.setBackgroundResource(R.drawable.white_star);
			img_star_4.setBackgroundResource(R.drawable.grey_star);
			img_star_5.setBackgroundResource(R.drawable.grey_star);
	
		}
		else if(rating.equals("4"))
		{
			img_star_1.setBackgroundResource(R.drawable.white_star);
			img_star_2.setBackgroundResource(R.drawable.white_star);
			img_star_3.setBackgroundResource(R.drawable.white_star);
			img_star_4.setBackgroundResource(R.drawable.white_star);
			img_star_5.setBackgroundResource(R.drawable.grey_star);
	
		}
		else
		{
			img_star_1.setBackgroundResource(R.drawable.white_star);
			img_star_2.setBackgroundResource(R.drawable.white_star);
			img_star_3.setBackgroundResource(R.drawable.white_star);
			img_star_4.setBackgroundResource(R.drawable.white_star);
			img_star_5.setBackgroundResource(R.drawable.white_star);
	
		}
	}
	void getGroupInfoView_6(String name,String image,String rating,String groupRating,
			String ownerRating,final String periodType,final String charge, String intro,String trial,String groupCode,String memberCount)
	{
		if(linear_container.getChildCount()>0)
		{
			linear_container.removeAllViews();
		}
		//quit from group replasee
		
		View row=View.inflate(GroupInfoActivity.this, R.layout.groupinfo_3, null);
		
		
		Button btn_subscribe=(Button) row.findViewById(R.id.btn_subscribe);
		btn_subscribe.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				callInAppPur(periodType,charge);
			}
		});
	txt_trial=(TextView)row.findViewById(R.id.txt_trial);
		
	//txt_group_number=(TextView)row.findViewById(R.id.txt_group_number);
	//txt_group_number.setText(groupCode);

//	txt_group_member=(TextView) row.findViewById(R.id.txt_group_member);
	//txt_group_member.setText(memberCount);
		if(trial.equals("0")||trial.equals("null"))
		{
			txt_trial.setVisibility(View.GONE);
		}
		else
		{
			txt_trial.setVisibility(View.VISIBLE);
			txt_trial.setText(trial+" "+"MONTH TRIAL,");
		}
		
		txt_intro=(TextView)row.findViewById(R.id.txt_intro);
		txt_intro.setText(intro);
		txt_members=(TextView) row.findViewById(R.id.txt_members);
		
		txt_name=(TextView) row.findViewById(R.id.txt_name);
		txt_name.setText(name.trim());
		img_pic=(ImageView)row. findViewById(R.id.img_pic);
		
	img_pic.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				showDialog(1);
			}
		});
		img_loader.DisplayImage(WellconnectedConstant.IMAGE_URL_4+image, img_pic);
	
		img_star_1=(ImageButton)  row.findViewById(R.id.img_star_1);
		img_star_2=(ImageButton) row. findViewById(R.id.img_star_2);
		img_star_3=(ImageButton)  row.findViewById(R.id.img_star_3);
		img_star_4=(ImageButton)  row.findViewById(R.id.img_star_4);
		img_star_5=(ImageButton)  row.findViewById(R.id.img_star_5);
	
		rating_function(rating);
		
		img_rate_star_1=(ImageButton)  row.findViewById(R.id.img_rate_star_1);
		img_rate_star_2=(ImageButton) row. findViewById(R.id.img_rate_star_2);
		img_rate_star_3=(ImageButton)  row.findViewById(R.id.img_rate_star_3);
		img_rate_star_4=(ImageButton)  row.findViewById(R.id.img_rate_star_4);
		img_rate_star_5=(ImageButton)  row.findViewById(R.id.img_rate_star_5);
		
		rate_group_function(groupRating);
		
		
		img_rate_owner_1=(ImageButton)  row.findViewById(R.id.img_rate_owner_1);
		img_rate_owner_2=(ImageButton) row. findViewById(R.id.img_rate_owner_2);
		img_rate_owner_3=(ImageButton)  row.findViewById(R.id.img_rate_owner_3);
		img_rate_owner_4=(ImageButton)  row.findViewById(R.id.img_rate_owner_4);
		img_rate_owner_5=(ImageButton)  row.findViewById(R.id.img_rate_owner_5);
		
		rate_owner_function(ownerRating);
	
		txt_free=(TextView) row.findViewById(R.id.txt_free);
		if(periodType.equals("1"))
		{
			//monthly
			if(charge.equals("null"))
			{
				 txt_free.setText("FREE");
				 btn_subscribe.setVisibility(View.GONE);
			}
			else
			{
				 txt_free.setText("$"+charge+" "+"MONTHLY FEE");
				 btn_subscribe.setVisibility(View.VISIBLE);
			}
		 
		}
		else
		{
			if(charge.equals("null"))
			{
				  txt_free.setText("FREE");
				  
				  btn_subscribe.setVisibility(View.GONE);
			}
			else
			{
				  txt_free.setText("$"+charge+" "+"ANNUAL FEE");
				  btn_subscribe.setVisibility(View.VISIBLE);
					
			}
			//anualyy
			}
		if(trial.equals("0"))
		{
			 btn_subscribe.setVisibility(View.VISIBLE);
		}
		else
		{
			 btn_subscribe.setVisibility(View.GONE);
		}
		btn_manage_group=(Button) row.findViewById(R.id.btn_manage_group);
		btn_manage_group.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
					Intent intent=new Intent(GroupInfoActivity.this,ManageGroups.class);
					intent.putExtra("Manage_group",closeStatus);
					System.out.println("closeStatus"+closeStatus);
					intent.putExtra("GroupId", id);
					intent.putExtra("threadId", threadId);
					intent.putExtra("OwnerId", ownerId);
					startActivity(intent);
					
			}
		});
		btn_kick=(Button) row.findViewById(R.id.btn_kick);
		btn_kick.setText("Quit From Group");
		btn_kick.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
					//clear all msg from db also
				
				new QuitGroupTask().execute();
				
			}
		});
		
	btn_share_group=(Button) row.findViewById(R.id.btn_share_group);
		
		btn_share_group.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				drawershere.open();
				
				
			}
		});
		grid_images=(GridView) row.findViewById(R.id.grid_images);
		
		btn_clear=(Button) row.findViewById(R.id.btn_clear);
		btn_clear.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(GroupInfoActivity.this);
				 myAlertDialog.setMessage("Are you sure you want to clear group chat message?");
				 myAlertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {

					  public void onClick(DialogInterface arg0, int arg1) {
					  // do something when the OK button is clicked
							
							if (WellconnectedUtills.isNetworkAvailable(GroupInfoActivity.this)) {
								new ClearMsgTask().execute();
							} else {
								WellconnectedUtills.customDialog(GroupInfoActivity.this, "Internet connection is not available");

							}
					  }});
					 myAlertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
					       
					  public void onClick(DialogInterface arg0, int arg1) {
					  // do something when the Cancel button is clicked
					  }});
					 myAlertDialog.show();
				
				//clear all msg from db also
			}
		});
		grid_images.setAdapter(new GridAdapter(arr_groupss));
		
		linear_container.addView(row);
	}
	
	void getGroupInfoView_5(String image)
	{
		if(linear_container.getChildCount()>0)
		{
			linear_container.removeAllViews();
		}
		//quit from group replasee
		View row=View.inflate(GroupInfoActivity.this, R.layout.groupinfo_4, null);
		
		Button btn_subscribe=(Button) row.findViewById(R.id.btn_subscribe);
		btn_subscribe.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
			//	callInAppPur(periodType,charge);
			}
		});
		
		img_pic=(ImageView)row. findViewById(R.id.img_pic);
		txt_members=(TextView) row.findViewById(R.id.txt_members);
		
		img_pic.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					showDialog(1);
				}
			});
			img_loader.DisplayImage(WellconnectedConstant.IMAGE_URL_4+image, img_pic);
		
		btn_kick=(Button) row.findViewById(R.id.btn_kick);
		btn_kick.setText("Quit From Group");
		btn_kick.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
					//clear all msg from db also
				
				new QuitGroupTask().execute();
				
			}
		});
		
		linear_container.addView(row);
	}
	
	void getGroupInfoView_4(String name,String image,String memberCount,final String periodtype,final String charge)
	{
		if(linear_container.getChildCount()>0)
		{
			linear_container.removeAllViews();
		}
		
		View row=View.inflate(GroupInfoActivity.this, R.layout.groupinfo_4, null);
		
		Button btn_subscribe=(Button) row.findViewById(R.id.btn_subscribe);
		btn_subscribe.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				callInAppPur(periodtype,charge);
			}
		});
		txt_members=(TextView) row.findViewById(R.id.txt_members);
		
		txt_name=(TextView) row.findViewById(R.id.txt_name);
		txt_name.setText(name.trim());
		img_pic=(ImageView)row. findViewById(R.id.img_pic);
		
	img_pic.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				showDialog(1);
			}
		});
		img_loader.DisplayImage(WellconnectedConstant.IMAGE_URL_4+image, img_pic);
		txt_group_member=(TextView) row.findViewById(R.id.txt_group_member);
		txt_group_member.setText(memberCount);
	
		btn_clear=(Button) row.findViewById(R.id.btn_clear);
		btn_clear.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(GroupInfoActivity.this);
				 myAlertDialog.setMessage("Are you sure you want to clear group chat message?");
				 myAlertDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {

					  public void onClick(DialogInterface arg0, int arg1) {
					  // do something when the OK button is clicked
							
							if (WellconnectedUtills.isNetworkAvailable(GroupInfoActivity.this)) {
								new ClearMsgTask().execute();
							} else {
								WellconnectedUtills.customDialog(GroupInfoActivity.this, "Internet connection is not available");

							}
					  }});
					 myAlertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					       
					  public void onClick(DialogInterface arg0, int arg1) {
					  // do something when the Cancel button is clicked
					  }});
					 myAlertDialog.show();
				
				//clear all msg from db also
			}
		});
		
		btn_kick=(Button) row.findViewById(R.id.btn_kick);
		btn_kick.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
					//clear all msg from db also
				WellconnectedConstant.isPrevilage="0";
				
				Intent intent=new Intent(GroupInfoActivity.this,KickLayout.class);
				intent.putExtra("OwnerId", ownerId);
				intent.putExtra("GroupId", id);
				intent.putExtra("ThreadId", threadId);
				startActivityForResult(intent, 0);
				
			}
		});
		linear_container.addView(row);
	}
	
	void getGroupInfoView_3(String name,String image,String rating, String intro, String trial, String groupCode, String memberCount, final String periodType, final String charge)
	{
		if(linear_container.getChildCount()>0)
		{
			linear_container.removeAllViews();
		}
		
		View row=View.inflate(GroupInfoActivity.this, R.layout.groupinfo_2, null);
		
		Button btn_subscribe=(Button) row.findViewById(R.id.btn_subscribe);
		btn_subscribe.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				callInAppPur(periodType,charge);
			}
		});
		txt_name=(TextView) row.findViewById(R.id.txt_name);
		txt_name.setText(name.trim());
		img_pic=(ImageView)row. findViewById(R.id.img_pic);
		txt_members=(TextView) row.findViewById(R.id.txt_members);
		
		txt_intro=(TextView)row.findViewById(R.id.txt_intro);
		txt_intro.setText(intro);
		
		txt_trial=(TextView)row.findViewById(R.id.txt_trial);
		
		if(trial.equals("0")||trial.equals("null"))
		{
			txt_trial.setVisibility(View.GONE);

		}
		else
		{
			txt_trial.setVisibility(View.VISIBLE);

			txt_trial.setText(trial+" "+"MONTH TRIAL,");

		}
	   img_pic.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				showDialog(1);
			}
		});
		img_loader.DisplayImage(WellconnectedConstant.IMAGE_URL_4+image, img_pic);
	
		img_star_1=(ImageButton)  row.findViewById(R.id.img_star_1);
		img_star_2=(ImageButton) row. findViewById(R.id.img_star_2);
		img_star_3=(ImageButton)  row.findViewById(R.id.img_star_3);
		img_star_4=(ImageButton)  row.findViewById(R.id.img_star_4);
		img_star_5=(ImageButton)  row.findViewById(R.id.img_star_5);
	
		rating_function(rating);
		
		txt_free=(TextView) row.findViewById(R.id.txt_free);
		if(periodType.equals("1"))
		{
			if(charge.equals("null"))
			{
				  txt_free.setText("FREE");
				  btn_subscribe.setVisibility(View.GONE);
			}
			else
			{
				  txt_free.setText("$"+charge+" "+"MONTHLY FEE");
				  btn_subscribe.setVisibility(View.VISIBLE);
			}
			//monthly
		
		}
		else
		{
			if(charge.equals("null"))
			{
				  txt_free.setText("FREE");
				  btn_subscribe.setVisibility(View.GONE);
					
			}
			else
			{
				  txt_free.setText("$"+charge+" "+"ANNUAL FEE");
				  btn_subscribe.setVisibility(View.VISIBLE);
					
			}
			//anualyy
		}
		if(trial.equals("0"))
		{
			 btn_subscribe.setVisibility(View.VISIBLE);
		}
		else
		{
			 btn_subscribe.setVisibility(View.GONE);
		}
		txt_group_member=(TextView) row.findViewById(R.id.txt_group_member);
		txt_group_number=(TextView)row.findViewById(R.id.txt_group_number);
		txt_group_number.setText(groupCode);
		txt_group_member.setText(memberCount);
		
		btn_share_group=(Button) row.findViewById(R.id.btn_share_group);
		
		btn_share_group.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				drawershere.open();
				
				
			}
		});
		btn_clear=(Button) row.findViewById(R.id.btn_clear);
		btn_clear.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(GroupInfoActivity.this);
				 myAlertDialog.setMessage("Are you sure you want to clear group chat message?");
				 myAlertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {

					  public void onClick(DialogInterface arg0, int arg1) {
					  // do something when the OK button is clicked
							
							if (WellconnectedUtills.isNetworkAvailable(GroupInfoActivity.this)) {
								new ClearMsgTask().execute();
							} else {
								WellconnectedUtills.customDialog(GroupInfoActivity.this, "Internet connection is not available");

							}
					  }});
					 myAlertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
					       
					  public void onClick(DialogInterface arg0, int arg1) {
					  // do something when the Cancel button is clicked
					  }});
					 myAlertDialog.show();
				
				//clear all msg from db also
			}
		});
		
		btn_manage_group=(Button) row.findViewById(R.id.btn_manage_group);
		btn_manage_group.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub]
		
		Intent intent=new Intent(GroupInfoActivity.this,ManageGroups.class);
		intent.putExtra("Manage_group",closeStatus);
		System.out.println("closeStatus"+closeStatus);
		intent.putExtra("GroupId", id);
		intent.putExtra("threadId", threadId);
		intent.putExtra("OwnerId", ownerId);
		
		intent.putExtra("Id", Id);
		intent.putExtra("user_id", user_id);
		intent.putExtra("Join_status", Join_status);
		intent.putExtra("Group_Type", Group_Type);
		
		
		startActivityForResult(intent, 0);
		finish();
					/*Intent intent=new Intent(GroupInfoActivity.this,ManageGroups.class);
					intent.putExtra("Manage_group",closeStatus);
					intent.putExtra("GroupId", id);
					intent.putExtra("threadId", threadId);
					intent.putExtra("OwnerId", ownerId);
					startActivity(intent);
					*/
			}
		});
		btn_kick=(Button) row.findViewById(R.id.btn_kick);
		btn_kick.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
					//clear all msg from db also
				WellconnectedConstant.isPrevilage="0";
				
				Intent intent=new Intent(GroupInfoActivity.this,KickLayout.class);
				intent.putExtra("OwnerId", ownerId);
				intent.putExtra("GroupId", id);
				intent.putExtra("ThreadId", threadId);
				startActivity(intent);
				finish();
			}
		});
		
		grid_images=(GridView) row.findViewById(R.id.grid_images);
		if(arr_groupss.isEmpty())
		{
			txt_members.setVisibility(View.GONE);
		}
		else
		{
			txt_members.setVisibility(View.VISIBLE);
			
		}
		grid_images.setAdapter(new GridAdapter(arr_groupss));
		linear_container.addView(row);
	}
	
	void getGroupInfoView_2(String name,String image,String rating,String intro, String trial, String groupCode, String memberCount, final String periodType, final String charge, String groupRating, String ownerRating)
	{
		if(linear_container.getChildCount()>0)
		{
			linear_container.removeAllViews();
		}
		View row=View.inflate(GroupInfoActivity.this, R.layout.groupinfo_1, null);
		
		Button btn_subscribe=(Button) row.findViewById(R.id.btn_subscribe);
		btn_subscribe.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				callInAppPur(periodType,charge);
			}
		});
		txt_name=(TextView) row.findViewById(R.id.txt_name);
		txt_name.setText(name.trim());
		img_pic=(ImageView)row. findViewById(R.id.img_pic);
		txt_members=(TextView) row.findViewById(R.id.txt_members);
		
	img_pic.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				showDialog(1);
			}
		});
		img_loader.DisplayImage(WellconnectedConstant.IMAGE_URL_4+image, img_pic);
		
		img_star_1=(ImageButton)  row.findViewById(R.id.img_star_1);
		img_star_2=(ImageButton) row. findViewById(R.id.img_star_2);
		img_star_3=(ImageButton)  row.findViewById(R.id.img_star_3);
		img_star_4=(ImageButton)  row.findViewById(R.id.img_star_4);
		img_star_5=(ImageButton)  row.findViewById(R.id.img_star_5);
		
		
		img_rate_star_1=(ImageButton)  row.findViewById(R.id.img_rate_star_1);
		img_rate_star_2=(ImageButton) row. findViewById(R.id.img_rate_star_2);
		img_rate_star_3=(ImageButton)  row.findViewById(R.id.img_rate_star_3);
		img_rate_star_4=(ImageButton)  row.findViewById(R.id.img_rate_star_4);
		img_rate_star_5=(ImageButton)  row.findViewById(R.id.img_rate_star_5);
		
		rate_group_function(groupRating);
		
		
		img_rate_owner_1=(ImageButton)  row.findViewById(R.id.img_rate_owner_1);
		img_rate_owner_2=(ImageButton) row. findViewById(R.id.img_rate_owner_2);
		img_rate_owner_3=(ImageButton)  row.findViewById(R.id.img_rate_owner_3);
		img_rate_owner_4=(ImageButton)  row.findViewById(R.id.img_rate_owner_4);
		img_rate_owner_5=(ImageButton)  row.findViewById(R.id.img_rate_owner_5);
		
		rate_owner_function(ownerRating);
		
		txt_intro=(TextView)row.findViewById(R.id.txt_intro);
		txt_intro.setText(intro);
		
		rating_function(rating);
		
		txt_trial=(TextView)row.findViewById(R.id.txt_trial);
		txt_free=(TextView) row.findViewById(R.id.txt_free);
		txt_group_member=(TextView) row.findViewById(R.id.txt_group_member);
		txt_group_number=(TextView)row.findViewById(R.id.txt_group_number);
		
		if(trial.equals("0")||trial.equals("null"))
		{
			txt_trial.setVisibility(View.GONE);

		}
		else
		{
			txt_trial.setVisibility(View.VISIBLE);

			txt_trial.setText(trial+" "+"MONTH TRIAL,");

		}
		txt_group_number.setText(groupCode);
		txt_group_member.setText(memberCount);
		if(periodType.equals("1"))
		{
			if(charge.equals("null"))
			{
				  txt_free.setText("FREE");
				  btn_subscribe.setVisibility(View.GONE);
			}
			else
			{
				  txt_free.setText("$"+charge+" "+"MONTHLY FEE");
				  btn_subscribe.setVisibility(View.VISIBLE);
			}
			//monthly
		
		}
		else
		{
			if(charge.equals("null"))
			{
				  txt_free.setText("FREE");
				  btn_subscribe.setVisibility(View.GONE);
			}
			else
			{
				  txt_free.setText("$"+charge+" "+"ANNUAL FEE");
				  btn_subscribe.setVisibility(View.VISIBLE);
			}
			//anualyy
			
		}
		if(trial.equals("0"))
		{
			 btn_subscribe.setVisibility(View.VISIBLE);
		}
		else
		{
			 btn_subscribe.setVisibility(View.GONE);
		}
	btn_share_group=(Button) row.findViewById(R.id.btn_share_group);
		
		btn_share_group.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				drawershere.open();
				
				
			}
		});
		btn_clear=(Button) row.findViewById(R.id.btn_clear);
		btn_clear.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(GroupInfoActivity.this);
				 myAlertDialog.setMessage("Are you sure you want to clear group chat message?");
				 myAlertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {

					  public void onClick(DialogInterface arg0, int arg1) {
					  // do something when the OK button is clicked
							
							if (WellconnectedUtills.isNetworkAvailable(GroupInfoActivity.this)) {
								new ClearMsgTask().execute();
							} else {
								WellconnectedUtills.customDialog(GroupInfoActivity.this, "Internet connection is not available");

							}
					  }});
					 myAlertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
					       
					  public void onClick(DialogInterface arg0, int arg1) {
					  // do something when the Cancel button is clicked
					  }});
					 myAlertDialog.show();
				
			}
		});
		
		btn_quit=(Button) row.findViewById(R.id.btn_quit);
		btn_quit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				new QuitGroupTask().execute();
			}
		});
		
		
		grid_images=(GridView) row.findViewById(R.id.grid_images);
		
		if(arr_groupss.isEmpty())
		{
			txt_members.setVisibility(View.GONE);
		}
		else
		{
			txt_members.setVisibility(View.VISIBLE);
			
		}
		grid_images.setAdapter(new GridAdapter(arr_groupss));
	
		linear_container.addView(row);
	}
	
	void getGroupInfoView(String rating, String name, String intro, String trial, String groupCode, String memberCount, final String periodType, String image, final String charge)
	{
		if(linear_container.getChildCount()>0)
		{
			linear_container.removeAllViews();
		}
		View row=View.inflate(GroupInfoActivity.this, R.layout.groupinfo_row, null);
		
		Button btn_subscribe=(Button) row.findViewById(R.id.btn_subscribe);
		btn_subscribe.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				callInAppPur(periodType,charge);
			}
		});
		txt_name=(TextView) row.findViewById(R.id.txt_name);
		
		txt_members=(TextView) row.findViewById(R.id.txt_members);
		
		txt_intro=(TextView)row.findViewById(R.id.txt_intro);
		txt_trial=(TextView)row.findViewById(R.id.txt_trial);
		txt_free=(TextView) row.findViewById(R.id.txt_free);
		txt_group_member=(TextView) row.findViewById(R.id.txt_group_member);
		txt_group_number=(TextView)row.findViewById(R.id.txt_group_number);
		img_pic=(ImageView)row. findViewById(R.id.img_pic);
		img_pic.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				showDialog(1);
			}
		});
	
		btn_join=(Button)row. findViewById(R.id.btn_join);
		btn_join.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if(special.equals("1"))
				{
					key="userSendSpecialGroupInvitation";
				}
				else
				{
					key="userSendGroupInvitation";
					
				}
				new JoinTask().execute();
			}
		});
		btn_share_group=(Button) row.findViewById(R.id.btn_share_group);
		
		btn_share_group.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				drawershere.open();
				
			
			}
		});
		
		txt_name.setText(name.trim());
		txt_intro.setText(intro);
		if(trial.equals("0")||trial.equals("null"))
		{
			txt_trial.setVisibility(View.GONE);

		}
		else
		{
			txt_trial.setVisibility(View.VISIBLE);

			txt_trial.setText(trial+" "+"MONTH TRIAL,");

		}
		img_loader.DisplayImage(WellconnectedConstant.IMAGE_URL_4+image, img_pic);
		
		img_star_1=(ImageButton)  row.findViewById(R.id.img_star_1);
		img_star_2=(ImageButton) row. findViewById(R.id.img_star_2);
		img_star_3=(ImageButton)  row.findViewById(R.id.img_star_3);
		img_star_4=(ImageButton)  row.findViewById(R.id.img_star_4);
		img_star_5=(ImageButton)  row.findViewById(R.id.img_star_5);
	
		rating_function(rating);
		
		
		txt_group_number.setText(groupCode);
		txt_group_member.setText(memberCount);
		
		if(periodType.equals("1"))
		{
			//monthly
			if(charge.equals("null"))
			{
				  txt_free.setText("FREE");
				  btn_subscribe.setVisibility(View.GONE);
			}
			else
			{
				  txt_free.setText("$"+charge+" "+"MONTHLY FEE");
				  btn_subscribe.setVisibility(View.VISIBLE);
			}
		
		}
		else
		{
			//anualyy
			if(charge.equals("null"))
			{
				  txt_free.setText("FREE");
				  btn_subscribe.setVisibility(View.GONE);
					
			}
			else
			{
				  txt_free.setText("$"+charge+" "+"ANNUAL FEE");
				  btn_subscribe.setVisibility(View.VISIBLE);
					
			}
			
		}
		if(trial.equals("0"))
		{
			 btn_subscribe.setVisibility(View.VISIBLE);
		}
		else
		{
			 btn_subscribe.setVisibility(View.GONE);
		}
		grid_images=(GridView) row.findViewById(R.id.grid_images);
		
		if(arr_groupss.isEmpty())
		{
			txt_members.setVisibility(View.GONE);
		}
		else
		{
			txt_members.setVisibility(View.VISIBLE);
			
		}
		grid_images.setAdapter(new GridAdapter(arr_groupss));
		
		grid_images.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				
				Intent intent=new Intent(GroupInfoActivity.this,UserInfoActivity.class);
				intent.putExtra("Friend_id",arr_groupss.get(arg2).getUser_id());
				intent.putExtra("thread_id","");
				
			}
		});
		linear_container.addView(row);
	}
	
	class GridAdapter extends BaseAdapter
	{
		public ArrayList<GropUserData> arr_groupss; 

		public GridAdapter(ArrayList<GropUserData> arr_groupss) {
			// TODO Auto-generated constructor stub
			this.arr_groupss=arr_groupss;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return arr_groupss.size();
		}

		@Override
		public Object getItem(int arg0) {
			// TODO Auto-generated method stub
			return arg0;
		}

		@Override
		public long getItemId(int arg0) {
			// TODO Auto-generated method stub
			return arg0;
		}

		@Override
		public View getView(int arg0, View arg1, ViewGroup arg2) {
			// TODO Auto-generated method stub
			
			View row=View.inflate(GroupInfoActivity.this, R.layout.groupinfo_member_row, null);
			ImageView img_pic=(ImageView) row.findViewById(R.id.img_pic);
			
			System.out.println("IMAGE_URLIMAGE_URL"+WellconnectedConstant.IMAGE_URL_3+arr_groupss.get(arg0).getUser_image());
			img_loader_rounded.DisplayImage(WellconnectedConstant.IMAGE_URL_3+arr_groupss.get(arg0).getUser_image(), img_pic);
			
			img_pic.setTag(arg0);
			img_pic.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					int pos=(Integer) arg0.getTag();
					// TODO Auto-generated method stub
					Intent intent=new Intent(GroupInfoActivity.this,UserInfoActivity.class);
					intent.putExtra("Friend_id",arr_groupss.get(pos).getUser_id());
					intent.putExtra("thread_id","");
					startActivity(intent);
				}
			});
			return row;
		}
		
	}
}
