package com.images;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.provider.MediaStore.Images;
import android.provider.MediaStore.MediaColumns;
import android.util.Log;


/**
 * Bimtap encoding/decoding helper methods based on BitmapFactory
 * 
 * @author Ramkailash
 */
public class BitmapUtil {

    private static final int UNCONSTRAINED = -1;

    private static String TAG = "ImageUtil";
    private static boolean DEBUG = true;


    public static Bitmap decodeByteArray( byte[] bytes, int maxNumOfPixels) {
        
        if (bytes == null) return null;
        
        try {
            BitmapFactory.Options option = new BitmapFactory.Options();
            // Decode only image size
            option.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(bytes, 0, bytes.length, option);

            option.inJustDecodeBounds = false;
            option.inSampleSize = computeSampleSize(option, UNCONSTRAINED,
                    maxNumOfPixels);

            return BitmapFactory.decodeByteArray(bytes, 0, bytes.length, option);

        } catch (OutOfMemoryError oom) {

            Log.w(TAG, oom);
            return null;
        }
    }
    
    
    public static Bitmap decodeStream(InputStream is, int maxNumOfPixels) {

        if (is == null) return null;
        
        try {
            return decodeByteArray( readStream(is), maxNumOfPixels);

        } catch (IOException e) {
            Log.w(TAG, e);
            return null;
        }
    }
    
    
    public static Bitmap decodeFile(String filePath, int maxNumOfPixels) {
        
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(new File(filePath));
            return decodeByteArray(readStream(fis), maxNumOfPixels);

        } catch (IOException e) {
            Log.w(TAG, e);
            return null;
        }
        finally {
            if(fis != null) {
                try { fis.close(); } catch (IOException e) {}
            }
        }
        
    }
    
    
    /*
    public static Bitmap decodeByteArray(byte[] bytes, int requestWidth, int requestHeight) {
        
        if (bytes == null)  return null;
        
        try {
            BitmapFactory.Options option = new BitmapFactory.Options();
            // Decode only image size
            option.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(bytes, 0, bytes.length, option);

            option.inJustDecodeBounds = false;
            option.inSampleSize = calculateInSampleSize(option, requestWidth, requestHeight);

            return BitmapFactory.decodeByteArray(bytes, 0, bytes.length, option);

        } catch (OutOfMemoryError oom) {

            Log.w(TAG, oom);
            return null;
        }
    }

    
    public static Bitmap decodeStream(InputStream is, int width, int height) {
        if (is == null) return null;
        
        try {
            return decodeByteArray( readStream(is), width, height);

        } catch (IOException e) {
            Log.w(TAG, e);
            return null;
        }
    }
    
    
    public static Bitmap decodeFile(String filePath, int repWidth, int repHeight) {
        
        BitmapFactory.Options option = new BitmapFactory.Options();
        option.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(filePath, option);

        option.inJustDecodeBounds = false;
        option.inSampleSize = calculateInSampleSize(option, repWidth, repHeight);
        try {
            return BitmapFactory.decodeFile(filePath, option);
        } catch (OutOfMemoryError oom) {
            Log.w(TAG, oom);

            return null;
        }
    }
    
    
    
    public static void saveBitmapToFile(Bitmap bitmap, File file) {
        FileOutputStream outputStream = null;
        
        try {
            
            if (!file.getParentFile().exists()) {
                file.getParentFile().mkdirs();
            }
            outputStream = new FileOutputStream(file);
            if(!bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)) {
                throw new RuntimeException("failed to compress bitmap");
            }
        }
        catch (IOException e) {
            if(DEBUG) Log.e(TAG, "error storing bitmap", e);
        }
        finally {
            if(outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {}
            }
        }
    }
    
    
    public static byte[] pngCompress(Bitmap bmp) {
        
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        if(bmp.compress(Bitmap.CompressFormat.PNG, 100, baos)) {
            return  baos.toByteArray();
        }
        
        return null;
    }
    
    
    public static byte[] jpegCompress(Bitmap bmp) {
        
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        if(bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos)) {
            return  baos.toByteArray();
        }
        
        return null;
    }
    */
    
    /*
     * Compute the sample size as a function of minSideLength and
     * maxNumOfPixels. minSideLength is used to specify that minimal width or
     * height of a bitmap. maxNumOfPixels is used to specify the maximal size in
     * pixels that is tolerable in terms of memory usage.
     * 
     * The function returns a sample size based on the constraints. Both size
     * and minSideLength can be passed in as IImage.UNCONSTRAINED, which
     * indicates no care of the corresponding constraint. The functions prefers
     * returning a sample size that generates a smaller bitmap, unless
     * minSideLength = IImage.UNCONSTRAINED.
     * 
     * Also, the function rounds up the sample size to a power of 2 or multiple
     * of 8 because BitmapFactory only honors sample size this way. For example,
     * BitmapFactory downsamples an image by 2 even though the request is 3. So
     * we round up the sample size to avoid OOM.
     */
    private static int computeSampleSize(BitmapFactory.Options options,
            int minSideLength, int maxNumOfPixels) {
        int initialSize = computeInitialSampleSize(options, minSideLength,
                maxNumOfPixels);

        int roundedSize;
        if (initialSize <= 8) {
            roundedSize = 1;
            while (roundedSize < initialSize) {
                roundedSize <<= 1;
            }
        } else {
            roundedSize = (initialSize + 7) / 8 * 8;
        }

        return roundedSize;
    }
    

    private static int computeInitialSampleSize(BitmapFactory.Options options,
            int minSideLength, int maxNumOfPixels) {
        double w = options.outWidth;
        double h = options.outHeight;

        int lowerBound = (maxNumOfPixels == UNCONSTRAINED) ? 1 : (int) Math
                .ceil(Math.sqrt(w * h / maxNumOfPixels));
        int upperBound = (minSideLength == UNCONSTRAINED) ? 128 : (int) Math
                .min(Math.floor(w / minSideLength),
                        Math.floor(h / minSideLength));

        if (upperBound < lowerBound) {
            // return the larger one when there is no overlapping zone.
            return lowerBound;
        }

        if ((maxNumOfPixels == UNCONSTRAINED)
                && (minSideLength == UNCONSTRAINED)) {
            return 1;
        } else if (minSideLength == UNCONSTRAINED) {
            return lowerBound;
        } else {
            return upperBound;
        }
    }

    
    private static byte[] readStream(InputStream is) throws IOException {
        int len;
        byte[] buf;

        if (is instanceof ByteArrayInputStream) {
            int size = is.available();
            buf = new byte[size];
            len = is.read(buf, 0, size);
        } else {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            buf = new byte[1024];
            while ((len = is.read(buf, 0, 1024)) != -1)
                bos.write(buf, 0, len);
            buf = bos.toByteArray();
        }
        
        return buf;
    }
    
    public void setRequiredSize(int desiredWidth,String IMAGE_FILE_URL){
    	
    	try{
    	// Get the source image's dimensions
    	  BitmapFactory.Options options = new BitmapFactory.Options();
    	  // This does not download the actual image, just downloads headers.
    	  options.inJustDecodeBounds = true; 
    	  BitmapFactory.decodeFile(IMAGE_FILE_URL, options);
    	  // The actual width of the image.
    	  int srcWidth = options.outWidth;  
    	  // The actual height of the image.
    	  int srcHeight = options.outHeight;  

    	  // Only scale if the source is bigger than the width of the destination view.
    	  if(desiredWidth > srcWidth)
    	    desiredWidth = srcWidth;

    	  // Calculate the correct inSampleSize/scale value. This helps reduce memory use. It should be a power of 2.
    	  int inSampleSize = 1;
    	  while(srcWidth / 2 > desiredWidth){
    	    srcWidth /= 2;
    	    srcHeight /= 2;
    	    inSampleSize *= 2;
    	  }

    	  float desiredScale = (float) desiredWidth / srcWidth;

    	  // Decode with inSampleSize
    	  options.inJustDecodeBounds = false;
    	  options.inDither = false;
    	  options.inSampleSize = inSampleSize;
    	  options.inScaled = false;
    	  // Ensures the image stays as a 32-bit ARGB_8888 image.
    	  // This preserves image quality.
    	  options.inPreferredConfig = Bitmap.Config.ARGB_8888;  
    	                                                        
    	  Bitmap sampledSrcBitmap = BitmapFactory.decodeFile(IMAGE_FILE_URL, options);

    	  // Resize
    	  Matrix matrix = new Matrix();
    	  matrix.postScale(desiredScale, desiredScale);
    	  Bitmap scaledBitmap = Bitmap.createBitmap(sampledSrcBitmap, 0, 0,
    	      sampledSrcBitmap.getWidth(), sampledSrcBitmap.getHeight(), matrix, true);
    	  sampledSrcBitmap = null;

    	  // Save
    	  String LOCAL_PATH_TO_STORE_IMAGE = "/data/data/com.lara.fragments/Images";
    	  FileOutputStream out = new FileOutputStream(LOCAL_PATH_TO_STORE_IMAGE);
    	  scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
    	  scaledBitmap = null;
    	  
    	}catch(Exception ex){
    	}
    }
    public static int getCameraPhotoOrientation(Context context,String imagePath){
		int rotate = 0;
		try {
			
			File imageFile = new File(imagePath);
			ExifInterface exif = new ExifInterface(
					imageFile.getAbsolutePath());
			int orientation = exif.getAttributeInt(
					ExifInterface.TAG_ORIENTATION,
					ExifInterface.ORIENTATION_NORMAL);

			switch (orientation) {
			case ExifInterface.ORIENTATION_ROTATE_270:
				rotate = 270;
				break;
			case ExifInterface.ORIENTATION_ROTATE_180:
				rotate = 180;
				break;
			case ExifInterface.ORIENTATION_ROTATE_90:
				rotate = 90;
				break;
			}


			Log.v("ORIENTATION", "Exif orientation: " + orientation);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// rotate=90;
		return rotate;

		//  return rotate;
	}
    public static Bitmap loadBitmap(String path, int orientation, final int targetWidth, final int targetHeight) {
		Bitmap bitmap = null;
		try {
			// First decode with inJustDecodeBounds=true to check dimensions
			final BitmapFactory.Options options = new BitmapFactory.Options();
			options.inJustDecodeBounds = true;
			BitmapFactory.decodeFile(path, options);

			// Adjust extents
			int sourceWidth, sourceHeight;
			if (orientation == 90 || orientation == 270) {
				sourceWidth = options.outHeight;
				sourceHeight = options.outWidth;
			} else {
				sourceWidth = options.outWidth;
				sourceHeight = options.outHeight;
			}

			// Calculate the maximum required scaling ratio if required and load the bitmap
			if (sourceWidth > targetWidth || sourceHeight > targetHeight) {
				float widthRatio = (float)sourceWidth / (float)targetWidth;
				float heightRatio = (float)sourceHeight / (float)targetHeight;
				float maxRatio = Math.max(widthRatio, heightRatio);
				options.inJustDecodeBounds = false;
				options.inSampleSize = (int)maxRatio;
				bitmap = BitmapFactory.decodeFile(path, options);
			} else {
				bitmap = BitmapFactory.decodeFile(path);
			}

			// Rotate the bitmap if required
			if (orientation > 0) {
				Matrix matrix = new Matrix();
				matrix.postRotate(orientation);
				bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
			}

			// Re-scale the bitmap if necessary
			sourceWidth = bitmap.getWidth();
			sourceHeight = bitmap.getHeight();
			if (sourceWidth != targetWidth || sourceHeight != targetHeight) {
				float widthRatio = (float)sourceWidth / (float)targetWidth;
				float heightRatio = (float)sourceHeight / (float)targetHeight;
				float maxRatio = Math.max(widthRatio, heightRatio);
				sourceWidth = (int)((float)sourceWidth / maxRatio);
				sourceHeight = (int)((float)sourceHeight / maxRatio);
				bitmap = Bitmap.createScaledBitmap(bitmap, sourceWidth, sourceHeight, true);
			}
		} catch (Exception e) {
			//bitmap.recycle()
		}
		return bitmap;
	}
    public static Uri getImageUri(Context inContext, Bitmap inImage) {
	    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
	    inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
	    String path = Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
	    return Uri.parse(path);
	}
    public static String getAbsolutePath(Uri uri, Context ctx) {
        String[] projection = { MediaColumns.DATA };
        @SuppressWarnings("deprecation")
        Cursor cursor = ((Activity) ctx).managedQuery(uri, projection, null, null, null);
        if (cursor != null) {
            int column_index = cursor.getColumnIndexOrThrow(MediaColumns.DATA);
            cursor.moveToFirst();
            return cursor.getString(column_index);
        } else
            return null;
    }
}
