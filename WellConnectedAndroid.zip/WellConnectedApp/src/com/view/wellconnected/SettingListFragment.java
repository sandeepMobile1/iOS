package com.view.wellconnected;


import org.json.JSONObject;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.wellconnected.bean.ChangePwdBase;
import com.wellconnected.bean.NotificationBase;
import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

public class SettingListFragment extends Fragment implements OnClickListener{
	RelativeLayout rl_blockList,rl_change_pwd,rl_aboutus,rl_myprofile;
	ImageView btn_toggle;
	private String user_id,enabled;
	private boolean is_toggle=false;
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		
		View view = inflater.inflate(R.layout.setting, null);
		
		SharedPreferences	pref = getActivity().getSharedPreferences("LoginInfo", getActivity().MODE_WORLD_READABLE);
		
		WellconnectedConstant.ScreenName="";
		user_id=pref.getString("User_id", "");
		
		rl_myprofile=(RelativeLayout) view.findViewById(R.id.rl_myprofile);
		rl_myprofile.setOnClickListener(this);
		
		
		rl_blockList=(RelativeLayout) view.findViewById(R.id.rl_blockList);
		rl_blockList.setOnClickListener(this);
		
		
		rl_change_pwd=(RelativeLayout) view.findViewById(R.id.rl_change_pwd);
		rl_change_pwd.setOnClickListener(this);
		
				
		rl_aboutus=(RelativeLayout) view.findViewById(R.id.rl_aboutus);
		rl_aboutus.setOnClickListener(this);
		
		btn_toggle=(ImageView) view.findViewById(R.id.btn_toggle);
		btn_toggle.setOnClickListener(this);
		btn_toggle.setBackgroundResource(R.drawable.off_btn);
		
		if (WellconnectedUtills.isNetworkAvailable(getActivity())) 
		{
			new NotificationTask().execute();
		}
		else
		{
			WellconnectedUtills.customDialog(getActivity(), "Internet connection is not available");
			
		
		}
		return view;
   
	}
	//noti update task
	/** change pwd task **/
	public class NotificationUpdateTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		ChangePwdBase chatbase;
;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(getActivity(), "", "Please Wait");
			
		}

		@Override
		protected String doInBackground(String... params) {
			
			// TODO Auto-generated method stub
			chatbase = WellconnectedParse.UpdateNotification_status(getActivity() , user_id,enabled);

				//response=CCRApplicationParse.ChangePwd(ChangePasswordActivity.this, user_id, ed_password.getText().toString(), ed_new_pwd.getText().toString());
			
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			
			if (chatbase != null) {
				if (chatbase.getResponse()!=null) {
					WellconnectedUtills.customDialog(getActivity(), chatbase.getResponse().getSuccess());

					System.out.println("RESPONSE"+chatbase.getResponse().getSuccess());
				} else {
					
				
				}
			}
		}
	}
	
	//notificaion task
	
	/** change pwd task **/
	public class NotificationTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		NotificationBase chatbase;
;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(getActivity(), "", "Please Wait");
			
		}

		@Override
		protected String doInBackground(String... params) {
			
			// TODO Auto-generated method stub
			chatbase = WellconnectedParse.getNotification_status(getActivity() , user_id);

				//response=CCRApplicationParse.ChangePwd(ChangePasswordActivity.this, user_id, ed_password.getText().toString(), ed_new_pwd.getText().toString());
			
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			
			if (chatbase != null) {
				if (chatbase.getResponse()==null) {
					//WellconnectedUtills.customDialog(ChangePasswordActivity.this, chatbase.getResponse().getError());

				} else {
					
					String noti_status=chatbase.getResponse().getNotificationStatus();
					
					if(noti_status.equals("1"))
					{
						btn_toggle.setBackgroundResource(R.drawable.on_btn);
						is_toggle=true;
						
					}
					else
					{
						btn_toggle.setBackgroundResource(R.drawable.off_btn);
						is_toggle=false;
						
					}
				}
			}
		}
	}
	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
	
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent=null;
		switch(v.getId())
		{
		case R.id.rl_myprofile:
			 intent=new Intent(getActivity(),MyProfileActivity.class);
			startActivityForResult(intent, 0);
			break;
		case R.id.btn_toggle:
			if(is_toggle)
			{
				is_toggle=false;
				btn_toggle.setBackgroundResource(R.drawable.off_btn);
				enabled="0";
				new NotificationUpdateTask().execute();
			}
			else
			{
				is_toggle=true;
				
				btn_toggle.setBackgroundResource(R.drawable.on_btn);
				enabled="1";
				new NotificationUpdateTask().execute();
				
			}
			break;
		case R.id.rl_blockList:
			intent=new Intent(getActivity(),BlockContactList.class);
			startActivity(intent);
			
			
			break;
			case R.id.rl_change_pwd:
						
				intent=new Intent(getActivity(),ChangePasswordActivity.class);
				startActivity(intent);
				
						break;
			case R.id.rl_aboutus:
				intent=new Intent(getActivity(),AboutUsActivity.class);
				startActivity(intent);
				
				break;
		}
	}
}
