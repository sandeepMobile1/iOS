package com.wellconnected.bean;

import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SeekBar;

public class ButtonValueBean {
	
	public ImageButton getBtn_audio() {
		return btn_audio;
	}
	public void setBtn_audio(ImageButton btn_audio) {
		this.btn_audio = btn_audio;
	}
	public SeekBar getVoluBar() {
		return voluBar;
	}
	public void setVoluBar(SeekBar voluBar) {
		this.voluBar = voluBar;
	}
	public String getChat_type() {
		return chat_type;
	}
	public void setChat_type(String chat_type) {
		this.chat_type = chat_type;
	}
	public String getImage_audio_value() {
		return image_audio_value;
	}
	public void setImage_audio_value(String image_audio_value) {
		this.image_audio_value = image_audio_value;
	}
	public boolean isValue() {
		return Value;
	}
	public void setValue(boolean value) {
		Value = value;
	}
	public ImageButton btn_audio;
	public SeekBar voluBar;
	public String chat_type;
	public String image_audio_value;
	boolean Value=false;
	int tag;
	public int getTag() {
		return tag;
	}
	public void setTag(int tag) {
		this.tag = tag;
	}
	

}
