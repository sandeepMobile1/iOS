package com.wellconnected.bean;

import java.util.ArrayList;

public class ChangePswdBean {
	public String success;
	public String getSuccess() {
		return success;
	}
	public void setSuccess(String success) {
		this.success = success;
	}
	public String error;
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}

	
	
}
