package com.view.wellconnected;

public interface AsynTaskListener {
public void onTaskComplete(String result);
}
