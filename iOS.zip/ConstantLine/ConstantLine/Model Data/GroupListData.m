//
//  GroupListData.m
//  ConstantLine
//
//  Created by octal i-phone2 on 9/17/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "GroupListData.h"

@implementation GroupListData

@synthesize groupTitle;
@synthesize groupImage;
@synthesize groupRating;
@synthesize groupCreated;
@synthesize groupCharge;
@synthesize groupSubPeriod;
@synthesize groupType;
@synthesize groupUniqueNumber;
@synthesize groupId;
@synthesize groupMember;
@synthesize groupOwnerId;
@synthesize groupIntro;
@synthesize groupReadStatus;
@synthesize groupMemberId;
@synthesize subscribeStatus;
@synthesize groupParentId;
@synthesize groupSpecialType;

@end
