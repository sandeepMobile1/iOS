package com.view.wellconnected;

import java.io.File;
import java.util.ArrayList;
import java.util.Random;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.wellconnected.bean.Button_circle_state;
import com.wellconnected.bean.ContactBase;
import com.wellconnected.bean.ContactBean.contacts;
import com.wellconnected.lazyload.ImageLoader;
import com.wellconnected.lazyload.ImageLoader_rounded;
import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.utills.JsonPostRequest1;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

public class ContactActivity extends Activity {
	private LinearLayout ll_back;
	private SharedPreferences pref;
	private String user_id ,name_1,id_1,imageFilePath="";
	private ArrayList<contacts>arrDetail;
	private ListView list_contact;
	private ImageLoader_rounded imgLoader;
	ImageButton [] img_cirle;
	private TextView txt_done;
	int clickState[];
	int count =0;
	private String random_Number, friend_id,Friend_name,Friend_image;;
	private ArrayList<String>array_position;
	private ArrayList<Button_circle_state>arr_btn_state;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		setContentView(R.layout.contact);
		WellconnectedConstant.ScreenName="";
		array_position=new ArrayList<String>();
		 random_Number=getRandomNumber();
			
		txt_done=(TextView) findViewById(R.id.txt_done);
		txt_done.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				//if one user then direct else call webservice
				
				for(int i=0;i<clickState.length;i++)
				{
					if(clickState[i]==0)
					{
						
					}
					else
					{
						count++;
					}
				}
				
				String name="",id="";
				if(count>1)
				{
					//create group webservice
					for(int i=0;i<clickState.length;i++)
					{
						if(clickState[i]==1)
						{
							name=name+","+arrDetail.get(i).getUser_name();
							id=id+","+arrDetail.get(i).getId();
							
						}
					}
					
					 name_1=name.substring(1, name.length());
					System.out.println("name_1"+name_1);
					
					 id_1=id.substring(1, id.length());
					System.out.println("id_1"+id_1);
					new ContactDonneTask().execute();
				}
				else
				{
					if(count==0)
					{
						
					}
					else
					{
						
						 img_cirle=new ImageButton[ arrDetail.size()];
						 clickState=new int[ arrDetail.size()];
						 for(int i=0;i<arrDetail.size();i++)
						 {
							 clickState[i]=0;
							 arr_btn_state.get(i).getBtn_circle().setBackgroundResource(R.drawable.gray_circle);
							 //
						 }
						 count =0;
						 
							Intent intent=new Intent(ContactActivity.this,GroupChatActivity.class);
						WellconnectedConstant.is_group_chat="0";
						WellconnectedConstant.is_chat_screen="1";
						intent.putExtra("friend_id",friend_id);
						intent.putExtra("Friend_name", Friend_name);
						intent.putExtra("Friend_image", Friend_image);
						intent.putExtra("Group_id","0");
						intent.putExtra("Group_type","0");
						startActivity(intent);
					
					}
					
				}
				}
		});
		imgLoader=new ImageLoader_rounded(ContactActivity.this);
		
		
		pref = this.getSharedPreferences("LoginInfo", this.MODE_WORLD_READABLE);
		
		user_id=pref.getString("User_id", "");
		
		ll_back = (LinearLayout) findViewById(R.id.ll_back);
		
		list_contact=(ListView) findViewById(R.id.list_contact);

		ll_back.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				finish();
			}
		});
		
		
		if (WellconnectedUtills.isNetworkAvailable(ContactActivity.this)) {
			new ContactTask().execute();

		} else {
			WellconnectedUtills.customDialog(ContactActivity.this, "Internet connection is not available");

		}
	}

	public String getRandomNumber()
	{
		
		char[] chars = "abcdefghijklmnopqrstuvwxyz0123456789".toCharArray();
		StringBuilder sb = new StringBuilder();
		Random random = new Random();
		for (int i = 0; i < 40; i++) {
		    char c = chars[random.nextInt(chars.length)];
		    sb.append(c);
		}
		String output = sb.toString();
		System.out.println(output);
		return output;
	}
	public class ContactDonneTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		String response;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(ContactActivity.this, "", "Please Wait");
			
		}

		@Override
		protected String doInBackground(String... params) {
			
			ArrayList<String> fileArrayList = new ArrayList<String>();
			//image file path name
			
			if(imageFilePath==null||imageFilePath.equals(""))
			{
				imageFilePath="";
			}
			else
			{
				File file = new File(imageFilePath);
				
				fileArrayList.add(file.getPath());
			}
				
			ArrayList<String[]> dataArrayList = new ArrayList<String[]>();
				String[] c = new String[2];

			c[0] = "userId";
			c[1] = user_id;
			dataArrayList.add(c);

			String[] d = new String[2];

			d[0] = "groupTitle";
			d[1] = name_1 ;
			dataArrayList.add(d);

			String[] e = new String[2];

			e[0] = "groupIntro";
			e[1] = "";
			dataArrayList.add(e);

			String[] f = new String[2];

			f[0] = "subscriptionCharge";
			f[1] = "";
			dataArrayList.add(f);
		
			String[] fdevice_type = new String[2];

			fdevice_type[0] = "subscriptionPeriod";
			fdevice_type[1] = "";
			dataArrayList.add(fdevice_type);

			String[] g = new String[2];

			g[0] = "groupMember";
			g[1] = id_1;
			dataArrayList.add(g);

			
			String[] h = new String[2];

			h[0] = "threadId";
			h[1] = random_Number;
			dataArrayList.add(h);

			String[] i = new String[2];

			i[0] = "groupType";
			i[1] = "1";
			dataArrayList.add(i);

			
			String[] j = new String[2];

			j[0] = "periodType";
			j[1] = "";
			dataArrayList.add(j);

		
			String URL = WellconnectedConstant.WEBSERVICE_URL + "create_group";
			
			//give image name
			
			 response=new JsonPostRequest1().doPostWithFile1(URL, dataArrayList, fileArrayList, "testimage", "png");
			System.out.println("response"+response);
			
				Log.i("gotResponseeeeeeee", response);
			
			
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			
			if(response!=null)
			{
				JSONObject object,object_res = null;
				try {
					object = new JSONObject(response);
					 object_res=object.getJSONObject("response");
					
				} catch (JSONException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				if(object_res.has("success"))
				{
					
			
					try {
						
						String group_id=object_res.getString("groupId");
						String groupCode=object_res.getString("groupCode");
						
						WellconnectedUtills.customDialog(ContactActivity.this,object_res.getString("message"));
						
						} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
				//	finish();
				}
				else
				{
					
					try {
						WellconnectedUtills.customDialog(ContactActivity.this,object_res.getString("error"));
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
					
				}
				
			
			}
			
		}
	}
	public class ContactTask extends AsyncTask<String, Integer, String> {
		ProgressDialog progressDialog;
		JSONObject obj;
		ContactBase chatbase;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(ContactActivity.this, "", "Please Wait");

		}

		@Override
		protected String doInBackground(String... params) {

			// TODO Auto-generated method stub

			chatbase = WellconnectedParse.getContact(ContactActivity.this, user_id);

			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}

			if (chatbase != null) {
				if (chatbase.getResponse()==null) {
					//WellconnectedUtills.customDialog(ChatActivity.this, chatbase.getResponse().getError());

				} else {
					
					arrDetail=new ArrayList<contacts>();
					
					//arrDetail=chatbase.getResponse().getsuccess().getContacts();
					
					for(int i=0;i<chatbase.getResponse().getsuccess().getContacts().size();i++)
					{
						if(chatbase.getResponse().getsuccess().getContacts().get(i).getRequest_status().equals("2")&&!chatbase.getResponse().getsuccess().getContacts().get(i).getUser_id().equals("100"))
						{
							contacts obj=new contacts();
							obj.setId(chatbase.getResponse().getsuccess().getContacts().get(i).getId());
							obj.setIntro(chatbase.getResponse().getsuccess().getContacts().get(i).getIntro());
							obj.setRequest_status(chatbase.getResponse().getsuccess().getContacts().get(i).getRequest_status());
							obj.setUser_id(chatbase.getResponse().getsuccess().getContacts().get(i).getUser_id());
							obj.setUser_image(chatbase.getResponse().getsuccess().getContacts().get(i).getUser_image());
							obj.setUser_name(chatbase.getResponse().getsuccess().getContacts().get(i).getUser_name());
							
							arrDetail.add(obj);
						}
					}
				
					System.out.println("arrDetail"+arrDetail.size());
					arr_btn_state=new ArrayList<Button_circle_state>();
					
					
					 img_cirle=new ImageButton[ arrDetail.size()];
					 clickState=new int[ arrDetail.size()];
					 for(int i=0;i<arrDetail.size();i++)
					 {
						 clickState[i]=0;
						 Button_circle_state obj=new Button_circle_state();
						 obj.setBtn_circle(null);
						 obj.setIs_selected("false");
						 arr_btn_state.add(obj);
						 
					 }
					
					
					list_contact.setAdapter(new ContactlistAdapter()); 
				}
			}

		}
	}
	class ContactlistAdapter extends BaseAdapter
	{
		
		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return arrDetail.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			View row=View.inflate(ContactActivity.this, R.layout.contact_row, null);
			
			ImageView img_contact_image=(ImageView)row.findViewById(R.id.img_contact_image);
			TextView txt_contact_name=(TextView) row.findViewById(R.id.txt_contact_name);
			final ImageButton btn_circle=(ImageButton) row.findViewById(R.id.btn_circle);
			
			 Button_circle_state obj=new Button_circle_state();
			obj.setBtn_circle(btn_circle);
			obj.setIs_selected("false");
			arr_btn_state.set(position, obj);
			
			 txt_contact_name.setText(arrDetail.get(position).getUser_name().trim());
			 
			 if(arrDetail.get(position).getUser_image()!=null)
			 {
				 
				 System.out.println("Image"+WellconnectedConstant.IMAGE_URL_1+arrDetail.get(position).getUser_image());
				 
				 imgLoader.DisplayImage(WellconnectedConstant.IMAGE_URL_1+arrDetail.get(position).getUser_image(),  img_contact_image);
					 
			 }
			 else
			 {
				 img_contact_image.setBackgroundResource(R.drawable.phone_pic_bg);
			 }
			
			// img_cirle[position]=btn_circle;
			 btn_circle.setTag(position);
			 btn_circle.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					int pos=(Integer) arg0.getTag();
					 System.out.println("pos"+pos);
					 count=0;
					if( clickState[pos]==0)
					{
						
						 
						btn_circle.setBackgroundResource(R.drawable.orange_circle);
						clickState[pos]=1;

						 friend_id=arrDetail.get(pos).getUser_id();
						 Friend_name=arrDetail.get(pos).getUser_name();
						 Friend_image=arrDetail.get(pos).getUser_image();
					}
					else
					{
						
						btn_circle.setBackgroundResource(R.drawable.gray_circle);
						clickState[pos]=0;
					}
					//img_cirle[pos].setBackgroundResource(R.drawable.back_arrow);
					
				}
			});
			return row;
	}
	}
	class ContactAdapter extends BaseAdapter
	{
		
		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return arrDetail.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			
			ViewHolder viewHolder=null;
			if(convertView==null)
			{
				LayoutInflater inflater=ContactActivity.this.getLayoutInflater();
				convertView=inflater.inflate(R.layout.contact_row, null);
				  viewHolder = new ViewHolder();
				  
				  viewHolder.img_contact_image=(ImageView)convertView.findViewById(R.id.img_contact_image);
				  viewHolder.txt_contact_name=(TextView) convertView.findViewById(R.id.txt_contact_name);
				  viewHolder.btn_circle=(ImageButton) convertView.findViewById(R.id.btn_circle);
				 
				 convertView.setTag(viewHolder);
			}
			else
			{
				viewHolder = (ViewHolder)convertView.getTag();
				
			}
			 viewHolder.txt_contact_name.setText(arrDetail.get(position).getUser_name());
			 
			 System.out.println("getUser_image"+(arrDetail.get(position).getUser_image()));
				
			 
			 if(arrDetail.get(position).getUser_image()!=null)
			 {
				 
				 System.out.println("Image"+WellconnectedConstant.IMAGE_URL_1+arrDetail.get(position).getUser_image());
				 
				 imgLoader.DisplayImage(WellconnectedConstant.IMAGE_URL_1+arrDetail.get(position).getUser_image(),  viewHolder.img_contact_image);
					 
			 }
			 img_cirle[position]=viewHolder.btn_circle;
			 img_cirle[position].setTag(position);
			 img_cirle[position].setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					int pos=(Integer) arg0.getTag();
					
					 
					 System.out.println("pos"+pos);
				
						
					img_cirle[pos].setBackgroundResource(R.drawable.back_arrow);
					
				}
			});
			return convertView;
	}
	}
	class ViewHolder
	{
		
		ImageView img_contact_image;
		TextView txt_contact_name;
		ImageButton btn_circle;
		/*ImageView img_group_image,img_online;
		TextView txt_group_name,txt_detail,txt_date;
		LinearLayout linear_images;
		Button btn_share;*/
	}
}