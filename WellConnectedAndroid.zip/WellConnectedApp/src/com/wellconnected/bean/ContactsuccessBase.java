package com.wellconnected.bean;

public class ContactsuccessBase {

	private ContactBean success;

	public ContactBean getsuccess() {
		return success;
	}

	public void setResponse(ContactBean success) {
		this.success = success;
	}
	
}
