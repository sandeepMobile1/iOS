package com.wellconnected.bean;

public class MyGroupBase {

	private MygroupBean response;

	public MygroupBean getResponse() {
		return response;
	}

	public void setResponse(MygroupBean response) {
		this.response = response;
	}
	
}
