//
//  ContactListData.m
//  ConstantLine
//
//  Created by octal i-phone2 on 8/13/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "ContactListData.h"

@implementation ContactListData

@synthesize name,image,userId,phoneNo,img,status,deleteId,userName,email;

@end
