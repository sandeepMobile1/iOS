package com.view.wellconnected;


import com.wellconnected.utills.WellconnectedConstant;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class HelpFragment extends Fragment{
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		
		
		View view = inflater.inflate(R.layout.help, null);
        
		WellconnectedConstant.ScreenName="";
	      WebView web_view=(WebView) view.findViewById(R.id.web_view);
	      
	      web_view.getSettings().setJavaScriptEnabled(true); // enable javascript

	      web_view.setWebViewClient(new WebViewClient() {
	            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
	               // Toast.makeText(activity, description, Toast.LENGTH_SHORT).show();
	            }
	        });

	      web_view .loadUrl("http://wellconnected.ehealthme.com/help");
	       
		return view;
         
	}
	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		
	}
}
