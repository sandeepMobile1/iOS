package com.view.wellconnected;

import java.util.Random;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.util.Log;

import com.google.android.gcm.GCMBaseIntentService;
import com.wellconnected.utills.MyApplication;
import com.wellconnected.utills.WellconnectedUtills;


public class GCMIntentService extends GCMBaseIntentService{
	private MyApplication appDelegate;
	private SharedPreferences pref;

	public GCMIntentService(){
		super(WellconnectedUtills.GCMSenderId);
	}

	@Override
	protected void onError(Context context, String regId) {
		// TODO Auto-generated method stub
		Log.e("", "error registration id : "+regId);
	}

	@Override
	protected void onMessage(Context context, Intent intent) {
		// TODO Auto-generated method stub
		handleMessage(context, intent);
	}

	@Override
	protected void onRegistered(Context context, String regId) {
		// TODO Auto-generated method stub
//		Log.e("", "registration id : "+regId);
		handleRegistration(context, regId);
	}

	@Override
	protected void onUnregistered(Context context, String regId) {
		// TODO Auto-generated method stub
		
	}

	@SuppressWarnings({ "deprecation", "static-access" })
	private void handleMessage(Context context, Intent intent) {
		// TODO Auto-generated method stub
		WellconnectedUtills.notiMsg = intent.getStringExtra("message");
		WellconnectedUtills.notiTitle = intent.getStringExtra("title");
		WellconnectedUtills.notiType = intent.getStringExtra("type");
		
		appDelegate = (MyApplication)this.getApplicationContext();
		
		System.out.println("notiType"+WellconnectedUtills.notiType);
		pref = this.getSharedPreferences("LoginInfo",this.MODE_WORLD_READABLE);
		
		//increase count and save in sharedpref
		if(WellconnectedUtills.notiType.equals("chat"))
		{
			String chat_count=pref.getString("chatCount", "");
			int chat_countn=0;
			if(chat_count.equals(""))
			{
				chat_countn=1;
				
				SharedPreferences.Editor editor = pref.edit();
				editor.putString("chatCount", String.valueOf(chat_countn));
				editor.commit();
				
				appDelegate.getChangePic().sendEmptyMessage(11);
			}
			else
			{
				chat_countn=Integer.parseInt(chat_count)+1;
				System.out.println("chat_countn"+chat_countn);
				SharedPreferences.Editor editor = pref.edit();
				editor.putString("chatCount", String.valueOf(chat_countn));
					editor.commit();
				
				appDelegate.getChangePic().sendEmptyMessage(11);
			
			}
		}
		else if(WellconnectedUtills.notiType.equals("contact"))
		{
			String contact_count=pref.getString("contactCount", "");
			int contact_countn=Integer.parseInt(contact_count)+1;
			
			System.out.println("contact_countn"+contact_countn);
			SharedPreferences.Editor editor = pref.edit();
			editor.putString("contactCount", String.valueOf(contact_countn));
			editor.commit();
				
				if(appDelegate!=null)
				{
					appDelegate.getContactRefreshHandler().sendEmptyMessage(11);
				}
				else
				{
					System.out.println("appDelegate is null");
				}
			appDelegate.getChangePic().sendEmptyMessage(11);
		}
		else if(WellconnectedUtills.notiType.equals("groupchat"))
		{
			String groupCount=pref.getString("groupCount", "");
			int groupCountn=Integer.parseInt(groupCount)+1;
			
			System.out.println("groupCount"+groupCount);
			SharedPreferences.Editor editor = pref.edit();
			editor.putString("groupCount", String.valueOf(groupCountn));
				editor.commit();
			
			appDelegate.getChangePic().sendEmptyMessage(11);
		}
		
		WellconnectedUtills.notiUrl = intent.getStringExtra("url");
		if(	WellconnectedUtills.notiType.equals("contact"))
		{
			
		}
		else if(WellconnectedUtills.notiType.equals("groupchat")||WellconnectedUtills.notiType.equals("chat"))
		{
			
		}
		appDelegate = ((MyApplication) context.getApplicationContext());
		Handler mHandler = appDelegate.getmHandler();
		if (mHandler != null)
		{
			Message msg = Message.obtain();
			Bundle bundle=new Bundle();;
			
			System.out.println("Print The Value :"+WellconnectedUtills.notiType);
			bundle.putString("ChatType", WellconnectedUtills.notiType);
			msg.setData(bundle);
			mHandler.sendMessage(msg);
	
		}
			else
			System.out.println("Handler Not Found ");
	
		int icon = R.drawable.ic_launcher;        // icon from resources
		CharSequence tickerText = WellconnectedUtills.notiTitle;//intent.getStringExtra("me");              // ticker-text
		
		long when = System.currentTimeMillis();         // notification time
		CharSequence contentTitle = ""+WellconnectedUtills.notiMsg; //intent.getStringExtra("me");  // message title

	/*	Random random = new Random();
		int pendinIntentId = random.nextInt(100);
	*/	
		NotificationManager notificationManager =
				(NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
		Notification notification = new Notification(icon, tickerText, when);
		Intent notificationIntent = new Intent(context,GCMIntentService.class);
		PendingIntent pendingIntent = PendingIntent.getActivity(context,0, notificationIntent, 0);

		notification.setLatestEventInfo(context, contentTitle, "", pendingIntent);
	
		notification.flags|=notification.FLAG_AUTO_CANCEL;
		
	
		notification.vibrate=new long[] {100L, 100L, 200L, 500L};
		
		notificationManager.notify(1, notification);
		
		WellconnectedUtills.notificationReceived=true;
		PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
		WakeLock wl = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP, "TAG");
		wl.acquire();

		
	}
	
	private void handleRegistration(Context context, String regId) {
		// TODO Auto-generated method stub
		WellconnectedUtills.registrationId = regId;
			Log.e("", "registration id : "+regId);
			
	}
}
