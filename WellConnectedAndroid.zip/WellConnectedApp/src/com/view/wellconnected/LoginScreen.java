package com.view.wellconnected;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import com.wellconnected.utills.WellconnectedConstant;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.Signature;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;


public class LoginScreen extends Activity implements OnClickListener{
	private ImageButton img_login,img_register;
	private RelativeLayout rl_skip;
	private LinearLayout linear_terms,linear_privacy;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		 
		setContentView(R.layout.loginscreen);
		
		WellconnectedConstant.ScreenName="";
		linear_terms=(LinearLayout) findViewById(R.id.linear_terms);
		linear_terms.setOnClickListener(this);
		
		
		linear_privacy=(LinearLayout) findViewById(R.id.linear_privacy);
		linear_privacy.setOnClickListener(this);
	
		img_login=(ImageButton) findViewById(R.id.img_login);
		img_login.setOnClickListener(this);
		
		
		img_register=(ImageButton) findViewById(R.id.img_register);
		img_register.setOnClickListener(this);
		
		
		rl_skip=(RelativeLayout) findViewById(R.id.rl_skip);
		rl_skip.setOnClickListener(this);
		
		PackageInfo packageInfo;
        try {
        packageInfo = getPackageManager().getPackageInfo("com.view.wellconnected", 
PackageManager.GET_SIGNATURES);
        for (Signature signature : packageInfo.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                String key = new String(Base64.encode(md.digest(), 0));
                // String key = new String(Base64.encodeBytes(md.digest()));
                Log.e("Hash key", key);
        } 
        }
        catch (NameNotFoundException e1) {
        	Log.e("Name not found", e1.toString());
        }
 
        catch (NoSuchAlgorithmException e) {
        	Log.e("No such an algorithm", e.toString());
        }
        catch (Exception e){
        	Log.e("Exception", e.toString());
        }
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent=null;

		switch(v.getId())
			{
		case R.id.linear_privacy:
			intent=new Intent(LoginScreen.this,Term_n_use.class);
			intent.putExtra("TEARMS", "Privacy Policy");
			intent.putExtra("URL", "http://wellconnected.ehealthme.com/privacy_policy");
			startActivity(intent);
		
			
			break;
		case R.id.linear_terms:
			intent=new Intent(LoginScreen.this,Term_n_use.class);
			intent.putExtra("TEARMS", "Terms of Service");
			intent.putExtra("URL", "http://wellconnected.ehealthme.com/terms_condition");
			
			startActivity(intent);
		
			break;
		case R.id.rl_skip:
			intent=new Intent(LoginScreen.this,SkipActivity.class);
			startActivity(intent);
			//finish();
		
			break;
		case R.id.img_login:
			
			intent=new Intent(LoginScreen.this,LoginActivity2.class);
			startActivity(intent);
			//finish();
			break;
	case R.id.img_register:
			
			intent=new Intent(LoginScreen.this,ResigterActivity.class);
			startActivity(intent);
			//finish();
			break;
		}
	}
}
