package com.wellconnected.utills;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.entity.BufferedHttpEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.ByteArrayBuffer;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Paint.Style;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import com.facebook.FacebookException;
import com.facebook.FacebookOperationCanceledException;
import com.facebook.Session;
import com.facebook.android.R;
import com.facebook.widget.WebDialog;
import com.facebook.widget.WebDialog.OnCompleteListener;




public class WellconnectedUtills {
	 private static final String password = "test";
	    private static String salt;
	    private static int pswdIterations = 65536  ;
	    private static int keySize = 256;
	    private byte[] ivBytes;
	//public static String GCMSenderId = "952894475204";//382254532533//925719931085
	//552651380820
	public static String GCMSenderId = "764796163103"/*"552651380820"*//*,"529630683889"*//*"529630683889"*/;
	public static boolean notificationReceived;
	public static String notiTitle="",notiType="",notiMsg="StormPins",notiUrl="",registrationId = "";
	//public static ArrayList<FacebookFriendList> arrFbfriendsData;
	public static boolean isEmptyString(String text) 
	{
		return (text == null ||text.trim().equals("null")|| text.trim().length() <= 0);
	}
	 public String generateSalt() {
	        SecureRandom random = new SecureRandom();
	        byte bytes[] = new byte[20];
	        random.nextBytes(bytes);
	        String s = new String(bytes);
	        return s;
	    }
	
	
	 public final static String CONSUMER_KEY = "KUTU3EYOzrnxGKIHqUCjtideC";//Twitter consumer key
		public final static String CONSUMER_SECRET = "qRbjGj1hvebo4Duokf38LtGtvdZVf0jIdhQnoHUaH78nqm7qcT";//Twitter consumer secret key

	public static final Pattern EMAIL_ADDRESS_PATTERN = Pattern.compile("[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}");
		// to check string is alphanumeric
		public static boolean isAlphaNumeric(String s) {
		String pattern = "^[a-zA-Z0-9]*$";
		
		if (s.matches(pattern)) 
		{
			return true;
		}
		return false;
		}
		public static boolean isValidEmail(String email) {
			return EMAIL_ADDRESS_PATTERN.matcher(email).matches();
		}
	/**
	 *  Converts an input stream to string. Used in ServerCommunication class.
	 */
		
		public static Bitmap getRoundedBitmap_2(Bitmap scaleBitmap)
		{
			int w = 80;                                          
			int h = 80;                                         

			int radius = Math.min(h / 2, w / 2);                                
			Bitmap output = Bitmap.createBitmap(w + 8, h + 8, Config.ARGB_8888);

			Paint p = new Paint();                                              
			p.setAntiAlias(true);                                               

			Canvas c = new Canvas(output);                                      
			c.drawARGB(0, 0, 0, 0);                                             
			p.setStyle(Style.FILL);                                             

			c.drawCircle((w / 2) + 4, (h / 2) + 4, radius, p);                  

			p.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));                 

			c.drawBitmap(scaleBitmap, 4, 4, p);    
			
			p.setXfermode(null);                                                
			p.setStyle(Style.STROKE);                                           
			p.setColor(Color.WHITE);                                            
			p.setStrokeWidth(3);                                                
			c.drawCircle((w / 2) + 4, (h / 2) + 4, radius, p);                  

			return output;  
		}
		
		public static Bitmap getRoundedShape(Bitmap scaleBitmapImage) {
			// TODO Auto-generated method stub

			int targetWidth = 80;
			int targetHeight =80;
			Bitmap targetBitmap = Bitmap.createBitmap(targetWidth, targetHeight,
					Bitmap.Config.ARGB_8888);
			Canvas canvas = new Canvas(targetBitmap);
			Path path = new Path();

			path.addCircle(((float) targetWidth) / 2, ((float) targetHeight) / 2,
					(Math.min(((float) targetWidth), ((float) targetHeight)) / 2),
					Path.Direction.CW);
			Paint paint = new Paint();
			paint.setColor(Color.GRAY);
			// paint.setStyle(Paint.Style.STROKE);
			paint.setStyle(Paint.Style.FILL);
			paint.setAntiAlias(true);
			paint.setDither(true);
			paint.setFilterBitmap(true);
			
			
			canvas.drawOval(new RectF(0, 0, targetWidth, targetHeight), paint);
			canvas.clipPath(path);
			Bitmap sourceBitmap = scaleBitmapImage;

			canvas.drawBitmap(sourceBitmap, new Rect(0, 0, sourceBitmap.getWidth(),
					sourceBitmap.getHeight()), new RectF(0, 0, targetWidth,
					targetHeight), paint);

		

			return targetBitmap;

		}
		
		public static String DownloadFile(String imageURL, String fileName) throws IOException {

			URL url = new URL(imageURL); //you can write here any link
	        File file = new File(Environment.getExternalStorageDirectory()+"/Well/Twitter/"+"file.jpg");

	            //Create parent directory if it doesn't exists
	            if(!new File(file.getParent()).exists())
	            {
	                System.out.println("Path is created " + new File(file.getParent()).mkdirs());
	            }
	            
	            file = new File(Environment.getExternalStorageDirectory()+"/Well/Twitter/"+"file.jpg"); 
	            
	            
	            file.createNewFile();
	            
	            /* Open a connection to that URL. */
	            URLConnection ucon = url.openConnection();
	    		InputStream is = ucon.getInputStream();
	    		BufferedInputStream bufferinstream = new BufferedInputStream(is);

	    		ByteArrayBuffer baf = new ByteArrayBuffer(5000);
	    		int current = 0;
	    		while((current = bufferinstream.read()) != -1){
	    			baf.append((byte) current);
	    		}

	    		FileOutputStream fos = new FileOutputStream( file);
	    		fos.write(baf.toByteArray());
	    		fos.flush();
	    		fos.close();
	    		
	    		
	    		String filePath = Environment.getExternalStorageDirectory()+"/Well/Twitter/"+"file.jpg";
	    		
	    		return filePath;
		}
		
		public static Bitmap getBitmap(String profile_image)
		{
			 URL img_value = null;
				Bitmap  myBitmap=null;
			 try {
				img_value = new URL(profile_image);
				  myBitmap = BitmapFactory.decodeStream(img_value.openConnection().getInputStream());
			       
				  
				  HttpGet httpRequest = new HttpGet(URI.create(profile_image) );
	                HttpClient httpclient = new DefaultHttpClient();
	                HttpResponse response = (HttpResponse) httpclient.execute(httpRequest);
	                HttpEntity entity = response.getEntity();
	                BufferedHttpEntity bufHttpEntity = new BufferedHttpEntity(entity);
	                myBitmap = BitmapFactory.decodeStream(bufHttpEntity.getContent());
	                httpRequest.abort();
				
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				return myBitmap;

		}
		public static Bitmap getRoundedShape_boarder(Bitmap scaleBitmapImage) {
			// TODO Auto-generated method stub

			int targetWidth = 50;
			int targetHeight = 50;
			Bitmap targetBitmap = Bitmap.createBitmap(targetWidth, targetHeight,
					Bitmap.Config.ARGB_8888);
			Canvas canvas = new Canvas(targetBitmap);
			Path path = new Path();

			path.addCircle(((float) targetWidth) / 2, ((float) targetHeight) / 2,
					(Math.min(((float) targetWidth), ((float) targetHeight)) / 2),
					Path.Direction.CW);
			Paint paint = new Paint();
			paint.setColor(Color.GRAY);
			// paint.setStyle(Paint.Style.STROKE);
			paint.setStyle(Paint.Style.FILL);
			paint.setStrokeWidth(1);
			paint.setAntiAlias(true);
			paint.setDither(true);
			paint.setFilterBitmap(true);
			
			
			canvas.drawOval(new RectF(0, 0, targetWidth, targetHeight), paint);
			canvas.clipPath(path);
			Bitmap sourceBitmap = scaleBitmapImage;
			canvas.drawColor(Color.BLACK);
			canvas.drawBitmap(sourceBitmap, new Rect(0, 0, sourceBitmap.getWidth()-2,
					sourceBitmap.getHeight()-2), new RectF(0, 0, targetWidth,
					targetHeight), paint);
		
			//canvas.drawPath(path, paint);

			return targetBitmap;

		}
		
	/*	public static void setArray_player_tringle(Context context, String str,
				ArrayList<FacebookFriendList> data) {
			SharedPreferences prefs = context.getSharedPreferences("location_name",
					Context.MODE_PRIVATE);
			Editor editor = prefs.edit();
			try {
				editor.putString(str, serialize(data));
				editor.commit();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}*/

	/*	@SuppressWarnings("unchecked")
		public static ArrayList<FacebookFriendList> getArray(Context context,
				String str) {
			ArrayList<FacebookFriendList> articles = new ArrayList<FacebookFriendList>();
			try {
				articles = (ArrayList<FacebookFriendList>) deserialize(context
						.getSharedPreferences("location_name", Context.MODE_PRIVATE)
						.getString(str,
								serialize(new ArrayList<FacebookFriendList>())));
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
			}
			return articles;
		}
		*/
		public static String serialize(Serializable obj) throws IOException {
			if (obj == null) {
				return "";
			}
			ByteArrayOutputStream serialObj = new ByteArrayOutputStream();
			try {
				ObjectOutputStream objStream = new ObjectOutputStream(serialObj);
				objStream.writeObject(obj);
				objStream.close();
			} catch (Exception e) {
				e.printStackTrace();
				// throw WrappedIOException.wrap("Serialization error: " +
				// e.getMessage(), e);
			}
			return encodeBytes(serialObj.toByteArray());
		}

		public static Object deserialize(String str) throws IOException,
				ClassNotFoundException {
			if (str == null || str.length() == 0) {
				return null;
			}
			ByteArrayInputStream serialObj = null;
			ObjectInputStream objStream = null;
			try {
				serialObj = new ByteArrayInputStream(decodeBytes(str));
				objStream = new ObjectInputStream(serialObj);
			} catch (Exception e) {
				// throw WrappedIOException.wrap("Deserialization error: " +
				// e.getMessage(), e);
			}
			return objStream.readObject();
		}

		public static String encodeBytes(byte[] bytes) {
			StringBuffer strBuf = new StringBuffer();

			for (int i = 0; i < bytes.length; i++) {
				strBuf.append((char) (((bytes[i] >> 4) & 0xF) + ((int) 'a')));
				strBuf.append((char) (((bytes[i]) & 0xF) + ((int) 'a')));
			}
			return strBuf.toString();
		}

		public static byte[] decodeBytes(String str) {
			byte[] bytes = new byte[str.length() / 2];
			for (int i = 0; i < str.length(); i += 2) {
				char c = str.charAt(i);
				bytes[i / 2] = (byte) ((c - 'a') << 4);
				c = str.charAt(i + 1);
				bytes[i / 2] += (c - 'a');
			}
			return bytes;
		}

	public static boolean hasSpecialCharacter(String text)
	{
		if(isEmptyString(text))
		{
			return false;
		}
		else
		{
			if(text.contains("<")||text.contains(">")||text.contains(";")||text.contains("%")||text.contains("\"")||text.contains("\'")
					||text.contains(",")||text.contains("#")||text.contains("&")||text.contains(":")||text.contains("?")||text.contains("!")
					||text.contains("+")||text.contains("-")||text.contains("=")||text.contains("@")||text.contains("^")||text.contains("*")
					||text.contains("(")||text.contains(")")||text.contains("{")||text.contains("}")||text.contains("[")||text.contains("]"))
			{
				return true;		
			}
			else
			{
				return false;
			}
		}
	}
	
	
	
	public static String sha256(String base) {
	    try{
	        MessageDigest digest = MessageDigest.getInstance("SHA-256");
	        byte[] hash = digest.digest(base.getBytes("UTF-8"));
	        StringBuffer hexString = new StringBuffer();

	        for (int i = 0; i < hash.length; i++) {
	            String hex = Integer.toHexString(0xff & hash[i]);
	            if(hex.length() == 1) hexString.append('0');
	            hexString.append(hex);
	        }

	        return hexString.toString();
	    } catch(Exception ex){
	       throw new RuntimeException(ex);
	    }
	}
	public static String inputSteamToString(InputStream is) {
		String response;
		StringBuffer responseInBuffer = new StringBuffer();
		byte[] b = new byte[4028];
		try {
			for (int n; (n = is.read(b)) != -1;) {
				responseInBuffer.append(new String(b, 0, n));
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		response = new String(responseInBuffer.toString());
		return response;
	}
	/**
	 * Checking if a String matches desired Regex pattern. Used for validating emails.
	 */
	
	public static boolean isMatch(String text, String pattern) 
	{
		try 
		{
			Pattern patt = Pattern.compile(pattern);
			Matcher matcher = patt.matcher(text);
			return matcher.matches();
		}
		catch (RuntimeException e) 
		{
			return false;
		}
	}
	
	/**
	 * Checking if a string contains another string ignoring their case.
	 */
	
	public static boolean containsIgnoreCaseString(String original, String tobeChecked)
	{
	     return original.toLowerCase().contains(tobeChecked.toLowerCase());
	}
	
	/**
	 * Converts dp to pixels
	 */
	
	public static float convertDpToPixel(float dp,Context context)
	{
	    Resources resources = context.getResources();
	    DisplayMetrics metrics = resources.getDisplayMetrics();
	    float px = dp * (metrics.densityDpi/160f);
	    return px;
	}

	/**
	 * Converts pixels to dp
	 */
	
	public static float convertPixelsToDp(float px,Context context)
	{
	    Resources resources = context.getResources();
	    DisplayMetrics metrics = resources.getDisplayMetrics();
	    float dp = px / (metrics.densityDpi / 160f);
	    return dp;
	}
	
	/**
	 * Return a string array containing each chracter of the given string.
	 */
	
	public static String[] breakStringIntoCharacters(String data)
	{
		if(!WellconnectedUtills.isEmptyString(data))
		{
			String output[]=new String[data.length()];
			for(int i=0;i<data.length();i++)
			{
				output[i]=String.valueOf(data.charAt(i));
			}
			return output;
		}	
		else
		{
			return new String[]{};
		}
	}
	
	/**
	 * Get device registered email.	 
	 */
	
	public static String getEmail(Context context) 
	{
	    AccountManager accountManager = AccountManager.get(context); 
	    Account account = getAccount(accountManager);
	    if (account == null) 
	    {
	      return "";
	    }
	    else 
	    {
	      return account.name;
	    }
	}

	/**
	 * Get device account. Used by getEmail() 
	 */
	
	private static Account getAccount(AccountManager accountManager) 
	{
		Account[] accounts = accountManager.getAccountsByType("com.google");
	    Account account;
	    if (accounts.length > 0) 
	    {
	    	account = accounts[0];      
	    } 
	    else 
	    {
	      account = null;
	    }
	    return account;
	}	
	
	/**
	 * Utility method to hide soft keyboard in an activity
	 */
	
	public static void hideSoftKeyboard(Activity activity) 
	{
	    InputMethodManager inputMethodManager = (InputMethodManager)  activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
	    inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
	}
	
	/**
	 * Utility method to get activity running on top of activity stack.	
	 */
	
	public static String getCurrentTopActivity(Context context) 
    {
        ActivityManager mActivityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> RunningTask = mActivityManager.getRunningTasks(1);
        ActivityManager.RunningTaskInfo ar = RunningTask.get(0);
        return ar.topActivity.getClassName().toString();
    }
	
	/**
	 * Utility method to get First letter capital	
	 */
	
	public static String capitalizeFirstLetter(String original)
	{	  		
		if(isEmptyString(original))
	    {
	    	return original;
	    }
		
		return original.substring(0, 1).toUpperCase() + original.substring(1);
	}
	
  public static void customDialog(Context ctx,String Message){
		
		//dialog.getWindow().setTitle()
		 AlertDialog dialog;
		 Builder builder = new AlertDialog.Builder(ctx);
	      builder.setMessage(Message);
	      builder.setCancelable(true);
	      builder.setPositiveButton("OK", new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				
				dialog.dismiss();
			}
		});
	      dialog = builder.create();
	      dialog.show();
	}
  
  public static void customDialog_2(Context ctx,String Message,final Activity a){
		
		//dialog.getWindow().setTitle()
		 AlertDialog dialog;
		 Builder builder = new AlertDialog.Builder(ctx);
	      builder.setMessage(Message);
	      builder.setCancelable(true);
	      builder.setPositiveButton("OK", new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				a.finish();
				dialog.dismiss();
			}
		});
	      dialog = builder.create();
	      dialog.show();
	}

  public static boolean isNetworkAvailable(Context context) 
	{
		ConnectivityManager cm = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo networkInfo = cm.getActiveNetworkInfo();	
		if (networkInfo != null && networkInfo.isConnected()) 
		{
			return true;
		}
		return false;
	} 
  
  public static Bitmap getfbuserProfilrpic(String profile_image)
  {
	  HttpGet httpRequest = new HttpGet(URI.create(profile_image) );
      HttpClient httpclient = new DefaultHttpClient();
      HttpResponse response;
      Bitmap myBitmap=null;
	try {
		response = (HttpResponse) httpclient.execute(httpRequest);
		 HttpEntity entity = response.getEntity();
	      BufferedHttpEntity bufHttpEntity = new BufferedHttpEntity(entity);
	      myBitmap = BitmapFactory.decodeStream(bufHttpEntity.getContent());
	      httpRequest.abort();
	      
	} catch (ClientProtocolException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     
      return myBitmap;
  }
  
	public static Bitmap getRoundedCornerBitmap(Bitmap bitmap) {
		 /*
		  * Change here this method 
		  * 5/16/2013
		  */
		 
		 if(!(bitmap==null)){   
		    Bitmap output = Bitmap.createBitmap(bitmap.getWidth(),
		         bitmap.getHeight(), Config.ARGB_8888);
		    Canvas canvas = new Canvas(output);

		    final int color = 0xff424242;
		    final Paint paint = new Paint();
		    final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
		    final RectF rectF = new RectF(rect);
		    final float roundPx = 10;

		    paint.setAntiAlias(true);
		    canvas.drawARGB(0, 0, 0, 0);
		    paint.setColor(color);

		    canvas.drawRoundRect(rectF, roundPx, roundPx, paint);

		   paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
		    canvas.drawBitmap(bitmap, rect, rect, paint);

		    
		   /* Bitmap bmpWithBorder = Bitmap.createBitmap(output.getWidth() + 10 * 2, output.getHeight() + 10 * 2, output.getConfig());
		    Canvas canvass = new Canvas(bmpWithBorder);
		    canvass.drawColor(Color.WHITE);
		    final Rect rectt = new Rect(0, 0, bitmap.getWidth()+10, bitmap.getHeight()+10);
		    final RectF rectFF = new RectF(rectt);
		    canvass.drawRoundRect(rectFF, roundPx, roundPx, paint);

		  //  canvass.drawBitmap(output, 10, 10, null);
		    return bmpWithBorder;
		    */
		   return output;
		 }
		 return null;
		    }
	
	public static void publishFeedDialog(final Activity activity,String Group_name , String wellconnectedImage,String group_code) {
		try {
			Session session = Session.getActiveSession();
			final Resources resources = activity.getResources();

			if (session != null) {

				Bundle params = new Bundle();

				String Comment = "Join this push-to-talk support group:" + Group_name;

				//String URL = StormPinUtils.getShortURL(StormConstants.URL_64+"reports?id=" + clicked_droppinid);
				
				String URL="";
				System.out.println("Click Url" + URL);

				params.putString("name", "WellConnected Alert");
				
				params.putString("description", "Join this push-to-talk support group: " + Group_name+"first install app WellConnected"+URL+" Then, search group #:"+group_code);
				
			/*	if(commentText.equals("")){
					
					
					params.putString("description", type + " posted by " + dropPinUserName + " (" + dropPinTime + ")");
				}else
				{
					System.out.println("dropPinUserName"+dropPinUserName);
					params.putString("description", commentText+" "+URL);
				}*/
			
				params.putString("caption", "WellConnected by android");
				params.putString("link", URL);

				if (!"null".equalsIgnoreCase(wellconnectedImage) && !wellconnectedImage.equalsIgnoreCase("")) {
					if (wellconnectedImage.contains("http")) {
						params.putString("picture", wellconnectedImage);
					} else {
						//params.putString("picture", "http://images.stormpins.com/images/" + wellconnectedImage + "?s3path=/site-uploads/pin-Images/&size=600&square=true");
						
						params.putString("picture", WellconnectedConstant.IMAGE_URL_4+ wellconnectedImage);
						
						System.out.println("picture"+WellconnectedConstant.IMAGE_URL_4+ wellconnectedImage);
					}
				} else {
					 params.putString("picture","http://stormpinsapp.elasticbeanstalk.com/img/pinresponder/stormpins_logo_90x90.png");
					params.putString("picture",WellconnectedConstant.DEFAULT_GROUP_PIC);
				}
				WebDialog feedDialog = (new WebDialog.FeedDialogBuilder(activity, Session.getActiveSession(), params)).setOnCompleteListener(new OnCompleteListener() {

					@Override
					public void onComplete(Bundle values, FacebookException error) {
						if (error == null) {
							// When the story is posted, echo the success
							// and the post Id.
							final String postId = values.getString("post_id");

							if (postId != null) {

								Toast.makeText(activity, "Thank you for sharing on facebook.", Toast.LENGTH_SHORT).show();

							} else {
								// User clicked the Cancel button
								Toast.makeText(activity.getApplicationContext(), "Publish cancelled", Toast.LENGTH_SHORT).show();
							}
						} else if (error instanceof FacebookOperationCanceledException) {
							// User clicked the "x" button
							Toast.makeText(activity.getApplicationContext(), "Publish cancelled", Toast.LENGTH_SHORT).show();
						} else {
							// Generic, ex: network error
							Toast.makeText(activity.getApplicationContext(), "Error posting story", Toast.LENGTH_SHORT).show();
						}
					}

				}).build();
				feedDialog.show();
			}
		} catch (Exception E) {
			E.printStackTrace();
		}
	}
}
