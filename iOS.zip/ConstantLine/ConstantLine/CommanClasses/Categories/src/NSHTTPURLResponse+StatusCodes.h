//
//  NSHTTPURLResponse+StatusCodes.h
//  IdeaScale
//
//  Created by Jeremy Przasnyski on 11/11/09.
//  Copyright 2009 Cavoort, LLC. All rights reserved.
//
#import <Foundation/Foundation.h>
@interface NSHTTPURLResponse (StatusCodes)
-(BOOL)is200OK;
-(BOOL)isOK;
-(BOOL)isRedirect;
-(BOOL)isClientError;
-(BOOL)isServerError;
@end
