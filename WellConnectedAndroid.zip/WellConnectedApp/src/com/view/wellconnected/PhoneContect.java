package com.view.wellconnected;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.view.wellconnected.ContactListFragment.ChatAdapter;
import com.wellconnected.bean.PhoneContactBean;
import com.wellconnected.bean.ContactBean.contacts;
import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.utills.WellconnectedConstant;

public class PhoneContect extends Activity {
	private EditText ed_search;
	LinearLayout ll_back,ll_search;
	private String 	user_id,phone_no,user_name,User_name;
	private ArrayList<PhoneContactBean>arr,arr_temp;
	private ListView list_wellconnected;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		setContentView(R.layout.phone_contact_user);
		
		WellconnectedConstant.ScreenName="";
		SharedPreferences	pref = this.getSharedPreferences("LoginInfo", this.MODE_WORLD_READABLE);
		ed_search=(EditText) findViewById(R.id.ed_search);
		
		user_id=pref.getString("User_id", "");
		user_name=pref.getString("display_name", "");
		
		list_wellconnected=(ListView) findViewById(R.id.list_wellconnected);
		
		list_wellconnected.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				//show dialogg 
				phone_no=arr.get( arg2).getPhoneNumber();
				User_name=arr.get(arg2).getName();
				 AlertDialog dialog;

				AlertDialog.Builder builder=new AlertDialog.Builder(PhoneContect.this);
				builder.setMessage("Do you want to add this member in your contact list");
				
				builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						// TODO Auto-generated method stub
						//webserviceeee
						
						new sendPhoneNoTask().execute();
						
					}
				});
				builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
			           public void onClick(DialogInterface dialog, int id) {
			               // User cancelled the dialog
			           }
			       });
				dialog = builder.create();
			      dialog.show();
				
			}
		});
	
		TextView txt_heading=(TextView) findViewById(R.id.txt_heading);
		txt_heading.setText("Phone Contacts");
		
		getContactList();
		
		
		ll_back=(LinearLayout) findViewById(R.id.ll_back);
		ll_back.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				finish();
			}
		});
		
		ed_search.setOnEditorActionListener(new TextView.OnEditorActionListener() {
		    @Override
		    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
		        if (actionId == EditorInfo.IME_ACTION_SEARCH) {
		        	
		        	 InputMethodManager inputMethodManager = (InputMethodManager)  PhoneContect.this.getSystemService(Activity.INPUT_METHOD_SERVICE);
		        	    inputMethodManager.hideSoftInputFromWindow(PhoneContect.this.getCurrentFocus().getWindowToken(), 0);
		        
		            return true;
		        }
		        return false;
		    }
		});
		ed_search.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
				// TODO Auto-generated method stub
				
				
				arr_temp=new ArrayList<PhoneContactBean>();
				for(int i=0;i<arr.size();i++)
				{
					if(arr.get(i).getName().toLowerCase().contains(arg0.toString().toLowerCase()))
					{
						PhoneContactBean obj=new PhoneContactBean();
						obj.setIdContact(arr.get(i).getIdContact());
						obj.setName(arr.get(i).getName());
						obj.setPhoneNumber(arr.get(i).getPhoneNumber());
						
						arr_temp.add(obj);

					}
				}
				if(arg0.equals(""))
				{
					list_wellconnected.setAdapter(new WellconnectedAdapter(arr));
				}
				else
				{
					list_wellconnected.setAdapter(new WellconnectedAdapter(arr_temp)); 
				}
			}
			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void afterTextChanged(Editable arg0) {
				// TODO Auto-generated method stub
				
			}
		});
	}
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		InputMethodManager imm = (InputMethodManager)getSystemService(
			      this.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(ed_search.getWindowToken(), 0);
	}
	/** send phone no **/
	public class sendPhoneNoTask extends AsyncTask<String, Integer, String> 
	{
		ProgressDialog progressDialog;
		JSONObject obj;
		String chatbase;
;
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(PhoneContect.this, "", "Please Wait");
			
		}

		@Override
		protected String doInBackground(String... params) {
			
			// TODO Auto-generated method stub
			chatbase = WellconnectedParse.sendPhoneNo(PhoneContect.this,user_id,phone_no,user_name);

				//response=CCRApplicationParse.ChangePwd(ChangePasswordActivity.this, user_id, ed_password.getText().toString(), ed_new_pwd.getText().toString());
			
			return null;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			
			if (chatbase != null) {
				
				if(!chatbase.equals(""))
				{
					try {
						JSONObject obj=new JSONObject(chatbase);
						JSONObject obj_res=obj.getJSONObject("response");
						if(obj_res.has("error"))
						{
							Uri sms_uri = Uri.parse("smsto:"+phone_no);
							Intent sms_intent = new Intent(Intent.ACTION_SENDTO, sms_uri);
							sms_intent.putExtra("sms_body", "Hello from WellConnected");
							startActivity(sms_intent);

							
						/*	Intent sendIntent = new Intent(Intent.Uri sms_uri = Uri.parse("smsto:61000");
							Intent sms_intent = new Intent(Intent.ACTION_SENDTO, sms_uri);
							sms_intent.putExtra("sms_body", numberStrVal);
							startActivity(sms_intent);
, Uri.parse( "sms:" + phone_no"12222222"));

							//sendIntent.putExtra("to", User_name);
							sendIntent.putExtra("sms_body", "Hello from WellConnected"); 
							sendIntent.setType("vnd.android-dir/mms-sms");
							startActivity(sendIntent);*/
						//send message 
						}
						else
						{
							//add friend
							
						}
			             } catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
	}
	void getContactList()
	{
		arr=new ArrayList<PhoneContactBean>();
		Cursor cursor = null;
	    try {
	        cursor = PhoneContect.this.getContentResolver().query(Phone.CONTENT_URI, null, null, null, null);
	        int contactIdIdx = cursor.getColumnIndex(Phone._ID);
	        int nameIdx = cursor.getColumnIndex(Phone.DISPLAY_NAME);
	        int phoneNumberIdx = cursor.getColumnIndex(Phone.NUMBER);
	        int photoIdIdx = cursor.getColumnIndex(Phone.PHOTO_ID);
	        cursor.moveToFirst();
	        do {
	            String idContact = cursor.getString(contactIdIdx);
	            String name = cursor.getString(nameIdx);
	            String phoneNumber = cursor.getString(phoneNumberIdx);
	            
	            System.out.println("name"+name);
	            
	            PhoneContactBean bean=new PhoneContactBean();
	            bean.setIdContact(idContact);
	            bean.setName(name);
	            bean.setPhoneNumber(phoneNumber);
	            arr.add(bean);
	            
	            //...
	        } while (cursor.moveToNext());  
	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        if (cursor != null) {
	            cursor.close();
	        }
	    }
	    
	    list_wellconnected.setAdapter(new WellconnectedAdapter(arr));
	}
	
	class ViewHolder
	{
		ImageView img_chat_image,img_online;
		TextView txt_group_name,txt_friend_name;
		LinearLayout linear_images;
		Button btn_Add;
	}
	class WellconnectedAdapter extends BaseAdapter
	{
		private ArrayList<PhoneContactBean>arr;
		public WellconnectedAdapter(ArrayList<PhoneContactBean> arr_temp) {
			// TODO Auto-generated constructor stub
			this.arr=arr_temp;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return arr.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			
			ViewHolder viewHolder=null;
			if(convertView==null)
			{
				LayoutInflater inflater=PhoneContect.this.getLayoutInflater();
				convertView=inflater.inflate(R.layout.wellconected_row, null);
				  viewHolder = new ViewHolder();
				  viewHolder.img_chat_image=(ImageView)convertView.findViewById(R.id.img_chat_image);
				  viewHolder.txt_friend_name=(TextView) convertView.findViewById(R.id.txt_friend_name);
				  viewHolder.img_online=(ImageView) convertView.findViewById(R.id.img_online);
				  viewHolder.btn_Add=(Button) convertView.findViewById(R.id.btn_add);
				 convertView.setTag(viewHolder);
			}
			else
			{
				viewHolder = (ViewHolder)convertView.getTag();
			}
			 viewHolder.txt_friend_name.setText(arr.get(position).getName().trim());
			 viewHolder.img_chat_image.setBackgroundResource(R.drawable.phone_pic_bg);
			/* System.out.println("URL"+WellconnectedConstant.IMAGE_URL_1+arr_wellconnected.get(position).getUser_image());
				
				imgLoader.DisplayImage(WellconnectedConstant.IMAGE_URL_1+arr_wellconnected.get(position).getUser_image(),  viewHolder.img_chat_image);
				viewHolder.btn_Add.setTag(position);
		*/	return convertView;
		}
	}
}
