/**
 * Copyright OCTAL INFO SOLUTIONS PVT LTD.
 * 
 * Apr 16, 2013 6:15:24 PM
 * 
 * @author kamalkant
 * 
 * Name : MyApplication
 * 
 * Description : This class is the main application class of app use to show image from server.
 */
package com.wellconnected.utills;

import android.app.Application;
import android.graphics.Bitmap;
import android.os.Handler;

import com.images.FileSystemPersistence;
import com.images.HttpImageManager;

public class MyApplication extends Application {
			
	private Handler mHandler;
	private Handler changePic;
	private Handler ContactRefreshHandler;
	

	public Handler getContactRefreshHandler() {
		return ContactRefreshHandler;
	}

	public void setContactRefreshHandler(Handler contactRefreshHandler) {
		ContactRefreshHandler = contactRefreshHandler;
	}

	public Handler getmHandler() {
		return mHandler;
	}

	public void setmHandler(Handler mHandler) {
		this.mHandler = mHandler;
	}

	public HttpImageManager mHttpImageManager;
	public static final String BASEDIR = "/sdcard/httpimage";
	
	@Override
	public void onCreate() {
		super.onCreate();

		mHttpImageManager = new HttpImageManager(HttpImageManager.createDefaultMemoryCache(), new FileSystemPersistence(BASEDIR));
	}

	public HttpImageManager getHttpImageManagerInstance() {

		return mHttpImageManager;
	}

	public static MyApplication instance;
	public static Bitmap edit_profile_bitmap=null;
	public static String is_edit_pic="0";
	public static String is_edit_profile="0";

	public MyApplication() {
		instance = this;
	}

	public Handler getChangePic() {
		return changePic;
	}

	public void setChangePic(Handler changePic) {
		this.changePic = changePic;
	}

	
}
