package com.view.wellconnected;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.json.JSONObject;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.facebook.Request;
import com.facebook.Request.GraphUserCallback;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.SessionState;
import com.facebook.UiLifecycleHelper;
import com.facebook.model.GraphUser;
import com.wellconnected.bean.MyGroupBase;
import com.wellconnected.bean.MygroupBean.GroupDetail;
import com.wellconnected.lazyload.ImageLoader;
import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.twitter.TwitterApp;
import com.wellconnected.twitter.TwitterApp.TwDialogListener;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

public class SkipActivity extends Activity {
	
	private LinearLayout linear_skip_layout,ll_loadmore;
	private RelativeLayout rl_main_layout;
	private EditText ed_skip_search,ed_search;
	private String user_id,total_count,sdard_path,
	search_name,Share_GroupId,share_group_name,share_group_image,twresult="fail";
	private ListView list_group;
	private int page_no_1=1,search_page,load_more_pos=0;
	private static final List<String> PERMISSIONS = Arrays.asList("email","user_friends", "user_location", "user_hometown", "friends_hometown", "friends_location","read_friendlists");
	private UiLifecycleHelper uiHelper;
	private TextView txt_skip_new;
	MultiDirectionSlidingDrawer drawershere;
	private ImageLoader imgLoader;
	TwitterApp mTwitter;
	String filePath = "";
	private boolean is_search=false;
	private Button btn_skip_Search,btn_skip_cancel,btn_Help;
	private ArrayList<com.wellconnected.bean.MygroupBean.GroupDetail> arr_group;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		setContentView(R.layout.skipgroup);
		
		WellconnectedConstant.ScreenName="";
		SharedPreferences myPrefs = SkipActivity.this.getSharedPreferences("LoginInfo",
				SkipActivity.this.MODE_WORLD_READABLE);
		
		uiHelper = new UiLifecycleHelper(SkipActivity.this, callback);
		uiHelper.onCreate(savedInstanceState);

    	user_id=myPrefs.getString("User_id", "");
      	ll_loadmore=(LinearLayout)findViewById(R.id.ll_loadmore);
    	list_group=(ListView)findViewById(R.id.list_group);
    	
		ed_skip_search=(EditText) findViewById(R.id.ed_skip_search);
		ed_skip_search.setOnEditorActionListener(new TextView.OnEditorActionListener() {
		    @Override
		    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
		        if (actionId == EditorInfo.IME_ACTION_SEARCH) {
		        	
		        	InputMethodManager imm = (InputMethodManager)getSystemService(
		        			SkipActivity.this.INPUT_METHOD_SERVICE);
		        		imm.hideSoftInputFromWindow(ed_skip_search.getWindowToken(), 0);
		        		is_search=true;
		        	String value=ed_skip_search.getText().toString().trim();
					System.out.println("value"+value);
					if(value.length()>0)
					{
						search_name=value;
						search_page=1;
					new SearchTask().execute();
				
					}
		            return true;
		        }
		        return false;
		    }
		});
		ed_search=(EditText) findViewById(R.id.ed_search);
		ed_search.setOnEditorActionListener(new TextView.OnEditorActionListener() {
		    @Override
		    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
		        if (actionId == EditorInfo.IME_ACTION_SEARCH) {
		        	
		        	InputMethodManager imm = (InputMethodManager)getSystemService(
		        			SkipActivity.this.INPUT_METHOD_SERVICE);
		        		imm.hideSoftInputFromWindow(ed_search.getWindowToken(), 0);
		        		is_search=true;
			        	String value=ed_skip_search.getText().toString().trim();
						System.out.println("value"+value);
						if(value.length()>0)
						{
							search_name=value;
							search_page=1;
						new SearchTask().execute();
					
						}                                                                                
		            return true;
		        }
		        return false;
		    }
		});
		btn_Help=(Button)findViewById(R.id.btn_Help);
		btn_Help.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(SkipActivity.this,Term_n_use.class);
				intent.putExtra("TEARMS", "Help");
				intent.putExtra("URL", "http://wellconnected.ehealthme.com/help");
				startActivity(intent);
			
				/* HelpFragment fragment2 = new HelpFragment();
				    FragmentManager fragmentManager = getFragmentManager();
				    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
				    fragmentTransaction.replace(R.id.activity_main_content_fragment, fragment2);
				    fragmentTransaction.commit();
		*/
			}
		});
		btn_skip_Search=(Button) findViewById(R.id.btn_skip_Search);
		btn_skip_Search.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub]
				
	        	InputMethodManager imm = (InputMethodManager)getSystemService(
	        			SkipActivity.this.INPUT_METHOD_SERVICE);
	        		imm.hideSoftInputFromWindow(ed_skip_search.getWindowToken(), 0);
	        
				String value=ed_skip_search.getText().toString().trim();
				System.out.println("value"+value);
				is_search=true;
				arr_group=new ArrayList<com.wellconnected.bean.MygroupBean.GroupDetail>();
				
				if(value.length()>0)
				{
					search_name=value;
					search_page=1;
				new SearchTask().execute();
			
				}
			}
		});
		btn_skip_cancel=(Button) findViewById(R.id.btn_skip_cancel);
		btn_skip_cancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				ed_skip_search.setText("");
			}
		});
    	
    	txt_skip_new=(TextView) findViewById(R.id.txt_skip_new);
    	txt_skip_new.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				WellconnectedUtills.customDialog_2(SkipActivity.this, "Please Login First", SkipActivity.this);
				
			}
		});
    	
    	arr_group=new ArrayList<com.wellconnected.bean.MygroupBean.GroupDetail>();
    	
    	drawershere = (MultiDirectionSlidingDrawer)findViewById(R.id.drawershere);
    	Button mCancel = (Button) findViewById(R.id.cancel_image_btn);

		mCancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				drawershere.animateClose();
			}
		});
		
		Button sms_image_btn = (Button)findViewById(R.id.sms_image_btn);

		sms_image_btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
			
				String app_url="";
				
				TelephonyManager tMgr = (TelephonyManager)SkipActivity.this.getSystemService(Context.TELEPHONY_SERVICE);
				String mPhoneNumber = tMgr.getLine1Number();
				
				 Uri sms_uri = Uri.parse("smsto:"+mPhoneNumber); 
		         Intent sms_intent = new Intent(Intent.ACTION_SENDTO, sms_uri); 
		         sms_intent.putExtra("sms_body", "I thought you would be interested to join this push-to-talk support group:" +share_group_name+
		         		"  First, install app WellConnected:"+app_url+"Then, search group #: "+Share_GroupId); 
		         startActivity(sms_intent); 
			}
		});
		
		Button facebook_image_btn = (Button)findViewById(R.id.facebook_image_btn);

		facebook_image_btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (WellconnectedUtills.isNetworkAvailable(SkipActivity.this)) {
					//isLoginWithFBClicked = true;
					drawershere.animateClose();
				Session session = Session.getActiveSession();

				if (!session.isOpened() && !session.isClosed()) {

					session.openForRead(new Session.OpenRequest(SkipActivity.this).setPermissions(PERMISSIONS).setCallback(callback));

				} else {

					Session.openActiveSession(SkipActivity.this, true, callback);
					
					//session.closeAndClearTokenInformation();
				}

				} else {
					WellconnectedUtills.customDialog(SkipActivity.this, "Internet connection is not available");

			}
				
			}
		});
		Button twitter_image_btn = (Button)findViewById(R.id.twitter_image_btn);

		twitter_image_btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				drawershere.close();
				loginTwitter();
			}
		});
		
		Button mail_btn = (Button) findViewById(R.id.mail_btn);
		mail_btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {


				Intent email = new Intent(Intent.ACTION_SEND);
				email.putExtra(Intent.EXTRA_EMAIL, new String[] { "" });
				email.putExtra(Intent.EXTRA_SUBJECT, "Push-to-talk support group for" + share_group_name);
				
				email.putExtra(Intent.EXTRA_TEXT, "I thought you would be interested to join this push-to-talk support group: " + share_group_name + "\nFirst, install app WellConnected" /*+ "app_url"*/ + "\nThen, search group #" + Share_GroupId+"\n\n\n"+"Sent from my android");
							email.setType("message/rfc822");
				startActivity(Intent.createChooser(email, "Choose an Email client :"));
			}
		});
		
    	imgLoader=new ImageLoader(SkipActivity.this);
    	
			rl_main_layout=(RelativeLayout) findViewById(R.id.rl_main_layout);
			linear_skip_layout=(LinearLayout) findViewById(R.id.linear_skip_layout);
			
			ed_skip_search=(EditText) findViewById(R.id.ed_skip_search);
			rl_main_layout.setVisibility(View.GONE);
			linear_skip_layout.setVisibility(View.GONE);
			
			if (WellconnectedUtills.isNetworkAvailable(SkipActivity.this)) {
				new MyGroupTask().execute();

			} else {
				WellconnectedUtills.customDialog(SkipActivity.this, "Internet connection is not available");

			}
			
			list_group.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					
					
					WellconnectedUtills.customDialog_2(SkipActivity.this, "Please Login First", SkipActivity.this);
		
				}
			});
			
			ll_loadmore.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					//ed_search.setText("");
					/*if(arr_group.size()<Integer.parseInt(total_count))
					{
						ll_loadmore.setVisibility(View.VISIBLE);
						new MyGroupTask().execute();
					}
					else
					{
						ll_loadmore.setVisibility(View.VISIBLE);
						
					}*/
				}
			});
			
			/**
			 *  Add Load More
			 * */

			((LoadMoreListViewCode) list_group).setOnLoadMoreListener(new LoadMoreListViewCode.OnLoadMoreListener() {
				
				@Override
				public void onLoadMore() {
					// TODO Auto-generated method stub
					System.out.println("LOAD MORE"+search_name);
					System.out.println("arr_group.size() MORE"+arr_group.size());
					System.out.println("total_count"+total_count);
					search_page=search_page+1;
					load_more_pos=arr_group.size();
					
					if(arr_group.size()<Integer.parseInt(total_count))
					{
						ll_loadmore.setVisibility(View.VISIBLE);
						if(is_search)
						{
							new SearchTask().execute();
							
						}
						else
						{
							new MyGroupTask().execute();
						}
					}
					else
					{
						ll_loadmore.setVisibility(View.VISIBLE);
						
					}
				}
			});
	}
	public String loginTwitter() {
		mTwitter = new TwitterApp(SkipActivity.this,WellconnectedUtills.CONSUMER_KEY,WellconnectedUtills. CONSUMER_SECRET);
		mTwitter.setListener(mTwLoginDialogListenerforPost);
		
		if (mTwitter.hasAccessToken()) {
		

			new PostPhotoToTwitterTask().execute();
		} else {
			
			mTwitter.authorize();
			new PostPhotoToTwitterTask().execute();
		}
		return twresult;
	}
	

	// Asynck TAsk use for like any photo

	class PostPhotoToTwitterTask extends AsyncTask<Void, Void, Void> {
		ProgressDialog progressDialog;
		
		@Override
		public void onPreExecute() {
			progressDialog = ProgressDialog.show(SkipActivity.this, "Share On Twitter", "Please Wait....");
		}

		@Override
		public Void doInBackground(Void... params) {
            try {
				filePath = WellconnectedUtills.DownloadFile(WellconnectedConstant.IMAGE_URL_4+share_group_image, "test.png");
			} catch (IOException e) {
				e.printStackTrace();
			}
			return null;
		}

		@Override
		public void onPostExecute(Void result) {
			progressDialog.dismiss();
			
			postReview("octaltest", filePath);
		//	postToTwitter("octaltest", filePath);
		}
	}
	
	private TwDialogListener mTwLoginDialogListenerforPost = new TwDialogListener() {
		@Override
		public void onError(String value) {
			mTwitter.resetAccessToken();
		}

		@Override
		public void onComplete(String value) {
			//postReview(commentTextFb, imagePath);
			
		
			new PostPhotoToTwitterTask().execute();
			

		}
	};

	void postReview(String review, final String dropPinImageUrl) {

		final Dialog dialog = new Dialog(SkipActivity.this);
		dialog.getWindow();
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.dialog_twitter);
		dialog.setTitle("StormPins");

		Button cancelBtn = (Button) dialog.findViewById(R.id.twiiter_cancelbutton);
		Button postBtn = (Button) dialog.findViewById(R.id.twiiter_postbutton);
		final EditText postEditText = (EditText) dialog.findViewById(R.id.editText);

		ImageView shareimge = (ImageView) dialog.findViewById(R.id.shareimageimageView);
		
				   try {
        URL url = new URL(WellconnectedConstant.IMAGE_URL_4+share_group_image);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setDoInput(true);
        connection.connect();
        InputStream input = connection.getInputStream();
        Bitmap myBitmap = BitmapFactory.decodeStream(input);
        shareimge.setImageBitmap(myBitmap);
    } catch (IOException e) {
        e.printStackTrace();
       
    }
		
		postEditText.setText(review);

		// Set Data
		try {
			if (!dropPinImageUrl.equals("") && !dropPinImageUrl.equalsIgnoreCase("null")) {
			//	imnew.displayImage("http://images.stormpins.com/images/" + dropPinImageUrl + "?s3path=/site-uploads/pin-Images/&size=100&square=true", shareimge, options);
			} else {
			//	imnew.displayImage("http://apps-test.stormpins.com/img/pinresponder/stormpins_logo_90x90.png", shareimge, options);

			}

		} catch (Exception e) {
		}

		// if button is clicked, close the custom dialog
		cancelBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});

		postBtn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {

				dialog.dismiss();

				String twitterShareTxt = postEditText.getText().toString().trim();
				try {
				
					postToTwitter(twitterShareTxt, filePath);

				} catch (Exception e) {
				}
			}
		});
		dialog.show();
	}
	
	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (msg.what == 0) {

				WellconnectedUtills.customDialog(SkipActivity.this, "Thank you for sharing on twitter");

			} else if (msg.what == 1) {

				WellconnectedUtills.customDialog(SkipActivity.this, "Twitter does not allow duplicate tweets !");
			} else if (msg.what == 2) {

				WellconnectedUtills.customDialog(SkipActivity.this, "Internet connection not available");
			}

		}
	};

	private void postToTwitter(final String review, final String xx) {
		new Thread() {
			@Override
			public void run() {
				int what = 0;

				try {
					mTwitter.updateStatus(review, xx);
				} catch (Exception e) {
					what = 1;
					e.printStackTrace();
				}
				if (WellconnectedUtills.isNetworkAvailable(SkipActivity.this)) {
					mHandler.sendMessage(mHandler.obtainMessage(what));
				} else {
					mHandler.sendMessage(mHandler.obtainMessage(2));
				}

			}
		}.start();
	}
	private boolean hasEmailPermission() {

		Session session = Session.getActiveSession();

		return session != null && session.getPermissions().contains("email");

	}
	// Method for face book login
		private Session.StatusCallback callback = new Session.StatusCallback() {
			@Override
			public void call(Session session, final SessionState state, Exception exception) {

				if (session.isOpened()) {

					if (hasEmailPermission()) {

						Request.executeMeRequestAsync(session, new GraphUserCallback() {

							@Override
							public void onCompleted(GraphUser user, Response response) {
								System.out.println("user"+user);
								// TODO Auto-generated method stub
								if (user != null) {
									try {

										String registrantEmailSocial = response.getGraphObject().getInnerJSONObject().getString("email").toString();

										Log.d("registrantEmailSocial", registrantEmailSocial);

										String facebookID = user.getId();
										
										String fb_email = registrantEmailSocial;
										  
										String fb_username = user.getName();
									
										String  first_name =
										  user.getFirstName(); 
										String last_name =
										  user.getLastName();
										  
										  String stateName = "";
										 
										  String dob=user.getBirthday();
										//  String gender=user.get
										  String get_gender = (String) user.getProperty("gender");
										  
										String  imgurl="https://graph.facebook.com/"+user.getId()+"/picture?type=large";
										 // profile_url=imgurl; 
										
										  String facebook_friends="https://graph.facebook.com/"+user.getId()+"/friendlists";

										  WellconnectedUtills.publishFeedDialog(SkipActivity.this, share_group_name,share_group_image,Share_GroupId);
										  
										//new FbLoginTask().execute(fb_email,facebookID,fb_username,dob,get_gender,imgurl);
										
									} catch (Exception e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								}
							}
						});
					} else if (!hasEmailPermission()) {
						session.requestNewPublishPermissions(new Session.NewPermissionsRequest(SkipActivity.this, PERMISSIONS));

						Request request = Request.newStatusUpdateRequest(session, "Temple Hello Word Sample", new Request.Callback() {
							@Override
							public void onCompleted(Response response) {
								Log.d("", "fb:done = " + response.getGraphObject() + "," + response.getError());
							}
						});
						request.executeAsync();
					}

				}

			}
		};
		
		/*************************************************************************
		 * F A C E B O O K *
		 ************************************************************************/
		@Override
		public void onActivityResult(int requestCode, int resultCode, Intent data) {

			System.out.println("FRAGMENT_ONACTIVITY");
			// facebook
			uiHelper.onActivityResult(requestCode, resultCode, data);

		}

		@Override
		public void onPause() {
			super.onPause();
			uiHelper.onPause();
		}

		@Override
		public void onResume() {
			super.onResume();
			uiHelper.onResume();
		}

	 @Override  
	    public boolean onKeyDown(int keyCode, KeyEvent event)  
	  {  
	         //replaces the default 'Back' button action  
	         if(keyCode==KeyEvent.KEYCODE_BACK)  
	         {  
	        	 if(drawershere.isOpened())
	     		{
	     			drawershere.animateClose();
	     		}
	        	 else
	        	 {
	        		 finish();
	        	 }

	         }  
	         return true;  
	   }  
	/*@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
		if(drawershere.isOpened())
		{
			drawershere.animateClose();
		}
	}*/
	public class SearchTask extends AsyncTask<String, Integer, String> {
		ProgressDialog progressDialog;
		JSONObject obj;
		MyGroupBase mygroup;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(SkipActivity.this, "", "Please Wait");

		}

		@Override
		protected String doInBackground(String... params) {

			// TODO Auto-generated method stubfg

			mygroup = WellconnectedParse.my_group_search(SkipActivity.this, user_id, search_page+"",search_name);
			
			
			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}

			if (mygroup != null) {
				if (mygroup.getResponse().getError() != null) {
					WellconnectedUtills.customDialog(SkipActivity.this, mygroup.getResponse().getError());

				} else {
					ed_search.setText(search_name);
					 total_count=mygroup.getResponse().getTotalRecord();
					
					System.out.println("total_count"+total_count);
				//	arr_group=mygroup.getResponse().getGroupDetail();
					
					if(Integer.parseInt(total_count)>0)
					{
						rl_main_layout.setVisibility(View.VISIBLE);
						linear_skip_layout.setVisibility(View.GONE);
						
					}
					else
					{
						WellconnectedUtills.customDialog(SkipActivity.this, "No results are found.You may want to create a new group");
						
						linear_skip_layout.setVisibility(View.VISIBLE);
						rl_main_layout.setVisibility(View.GONE);
						
					}
					
					for(int i=0;i<mygroup.getResponse().getGroupDetail().size();i++)
					{
						
//						MygroupBean mMygroupBean = new MygroupBean();
//						GroupDetail mGroupDetail = mMygroupBean.new GroupDetail();
						GroupDetail obj=new com.wellconnected.bean.MygroupBean.GroupDetail();
						
						obj.setCreated(mygroup.getResponse().getGroupDetail().get(i).getCreated());
						obj.setGroupId(mygroup.getResponse().getGroupDetail().get(i).getGroupId());
						obj.setGroupCode(mygroup.getResponse().getGroupDetail().get(i).getGroupCode());
						
						obj.setGroupImage(mygroup.getResponse().getGroupDetail().get(i).getGroupImage());
						obj.setGroupName(mygroup.getResponse().getGroupDetail().get(i).getGroupName());
						obj.setGroupOwnerId(mygroup.getResponse().getGroupDetail().get(i).getGroupOwnerId());
						obj.setGroupType(mygroup.getResponse().getGroupDetail().get(i).getGroupType());
						obj.setGroupUserTableId(mygroup.getResponse().getGroupDetail().get(i).getGroupUserTableId());
						obj.setIndividualCount(mygroup.getResponse().getGroupDetail().get(i).getIndividualCount());
						obj.setIntro(mygroup.getResponse().getGroupDetail().get(i).getIntro());
						obj.setJoin(mygroup.getResponse().getGroupDetail().get(i).getJoin());
						obj.setLatest(mygroup.getResponse().getGroupDetail().get(i).getLatest());
						obj.setPaidStatus(mygroup.getResponse().getGroupDetail().get(i).getPaidStatus());
						
						obj.setParent_id(mygroup.getResponse().getGroupDetail().get(i).getParent_id());
						obj.setRequest_status(mygroup.getResponse().getGroupDetail().get(i).getRequest_status());
						obj.setSpecial(mygroup.getResponse().getGroupDetail().get(i).getSpecial());
						
						obj.setMessage(mygroup.getResponse().getGroupDetail().get(i).getMessage());
						obj.setStatus(mygroup.getResponse().getGroupDetail().get(i).getStatus());
						obj.setSubCharge(mygroup.getResponse().getGroupDetail().get(i).getSubCharge());
						obj.setSubscribeStatus(mygroup.getResponse().getGroupDetail().get(i).getSubscribeStatus());
						obj.setThreadId(mygroup.getResponse().getGroupDetail().get(i).getThreadId());
						arr_group.add(obj);
					}
					
					System.out.println("arr_group.size()"+arr_group.size());
					if(arr_group.size()==Integer.parseInt(total_count))
					{
						ll_loadmore.setVisibility(View.INVISIBLE);
						
					}
					else
					{
						ll_loadmore.setVisibility(View.VISIBLE);
						
					}
					((LoadMoreListViewCode)list_group).onLoadMoreComplete();
					list_group.setAdapter(new GroupAdapter());
					
					list_group.setSelection(load_more_pos);
					}
			}

		}
	}
	public class MyGroupTask extends AsyncTask<String, Integer, String> {
		ProgressDialog progressDialog;
		JSONObject obj;
		MyGroupBase mygroup;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(SkipActivity.this, "", "Please Wait");

		}

		@Override
		protected String doInBackground(String... params) {

			// TODO Auto-generated method stub

			mygroup = WellconnectedParse.my_group(SkipActivity.this, user_id, page_no_1+"");
			
			page_no_1++;

			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}
			
			try {
				if (mygroup != null) {
					if (mygroup.getResponse().getError() != null) {
						WellconnectedUtills.customDialog(SkipActivity.this, mygroup.getResponse().getError());

					} else {
						
						 total_count=mygroup.getResponse().getTotal_records();
						
						System.out.println("total_count"+total_count);
				
						if(Integer.parseInt(total_count)>0)
						{
							rl_main_layout.setVisibility(View.VISIBLE);
						}
						else
						{
							linear_skip_layout.setVisibility(View.VISIBLE);
							
						}
						
						for(int i=0;i<mygroup.getResponse().getGroupDetail().size();i++)
						{
//							MygroupBean mMygroupBean = new MygroupBean();
//							GroupDetail mGroupDetail = mMygroupBean.new GroupDetail();
							GroupDetail obj=new com.wellconnected.bean.MygroupBean.GroupDetail();
							
							obj.setCreated(mygroup.getResponse().getGroupDetail().get(i).getCreated());
							obj.setGroupId(mygroup.getResponse().getGroupDetail().get(i).getGroupId());
							obj.setGroupCode(mygroup.getResponse().getGroupDetail().get(i).getGroupCode());
							
							obj.setGroupImage(mygroup.getResponse().getGroupDetail().get(i).getGroupImage());
							obj.setGroupName(mygroup.getResponse().getGroupDetail().get(i).getGroupName());
							obj.setGroupOwnerId(mygroup.getResponse().getGroupDetail().get(i).getGroupOwnerId());
							obj.setGroupType(mygroup.getResponse().getGroupDetail().get(i).getGroupType());
							obj.setGroupUserTableId(mygroup.getResponse().getGroupDetail().get(i).getGroupUserTableId());
							obj.setIndividualCount(mygroup.getResponse().getGroupDetail().get(i).getIndividualCount());
							obj.setIntro(mygroup.getResponse().getGroupDetail().get(i).getIntro());
							obj.setJoin(mygroup.getResponse().getGroupDetail().get(i).getJoin());
							obj.setLatest(mygroup.getResponse().getGroupDetail().get(i).getLatest());
							obj.setPaidStatus(mygroup.getResponse().getGroupDetail().get(i).getPaidStatus());
							obj.setMessage(mygroup.getResponse().getGroupDetail().get(i).getMessage());
							
							obj.setParent_id(mygroup.getResponse().getGroupDetail().get(i).getParent_id());
							obj.setRequest_status(mygroup.getResponse().getGroupDetail().get(i).getRequest_status());
							obj.setSpecial(mygroup.getResponse().getGroupDetail().get(i).getSpecial());
							
							
							obj.setStatus(mygroup.getResponse().getGroupDetail().get(i).getStatus());
							obj.setSubCharge(mygroup.getResponse().getGroupDetail().get(i).getSubCharge());
							obj.setSubscribeStatus(mygroup.getResponse().getGroupDetail().get(i).getSubscribeStatus());
							obj.setThreadId(mygroup.getResponse().getGroupDetail().get(i).getThreadId());
							arr_group.add(obj);
						}
						
						if(arr_group.size()==Integer.parseInt(total_count))
						{
							ll_loadmore.setVisibility(View.INVISIBLE);
							
						}
						else
						{
							ll_loadmore.setVisibility(View.VISIBLE);
							
						}
						
						((LoadMoreListViewCode)list_group).onLoadMoreComplete();
						list_group.setAdapter(new GroupAdapter());
						}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			

		}
	}
	
/**search task **/
	
	class GroupAdapter extends BaseAdapter
	{
		Bitmap globalBitmap;
		LayoutInflater inflater;
		public GroupAdapter() {
			// TODO Auto-generated constructor stub
			Drawable drawable = SkipActivity.this.getResources().getDrawable(R.drawable.group_pic);
			globalBitmap = ((BitmapDrawable)drawable).getBitmap();
			inflater = (LayoutInflater)SkipActivity.this.getSystemService(SkipActivity.this.LAYOUT_INFLATER_SERVICE);
		}
		@Override
		public int getCount() {
			return arr_group.size();
		}

		@Override
		public Object getItem(int position) {
			return position;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			
			/*if(convertView==null)
			{
				LayoutInflater inflater=SkipActivity.this.getLayoutInflater();
				convertView=inflater.inflate(R.layout.mygroup_row, null);
				  viewHolder = new ViewHolder();
				  viewHolder.img_group_image=(ImageView)convertView.findViewById(R.id.img_group_image);
				  viewHolder.txt_group_name=(TextView) convertView.findViewById(R.id.txt_group_name);
				  viewHolder.txt_detail=(TextView)convertView. findViewById(R.id.txt_detail);
				  viewHolder.txt_date=(TextView) convertView.findViewById(R.id.txt_date);
					//viewHolder.linear_images=(LinearLayout) convertView.findViewById(R.id.linear_images);
				  viewHolder.img_online=(ImageView) convertView.findViewById(R.id.img_online);
				  viewHolder.btn_share=(Button) convertView.findViewById(R.id.btn_share);
				  
				  
				 convertView.setTag(viewHolder);
			}
			else
			{
				viewHolder = (ViewHolder)convertView.getTag();
				
			}*/
			
			LayoutInflater inflater=SkipActivity.this.getLayoutInflater();
			convertView=inflater.inflate(R.layout.mygroup_row, null);
			  
			ImageView img_group_image=(ImageView)convertView.findViewById(R.id.img_group_image);
			TextView txt_group_name=(TextView) convertView.findViewById(R.id.txt_group_name);
			TextView txt_detail=(TextView)convertView. findViewById(R.id.txt_detail);
			TextView txt_date=(TextView) convertView.findViewById(R.id.txt_date);
				//viewHolder.linear_images=(LinearLayout) convertView.findViewById(R.id.linear_images);
			ImageView img_online=(ImageView) convertView.findViewById(R.id.img_online);
			Button btn_share=(Button) convertView.findViewById(R.id.btn_share);
			  
		
			
			if(arr_group.get(position).getStatus().equals("read")||arr_group.get(position).getStatus().equals("1"))
			{
		
			
				 img_online.setVisibility(View.INVISIBLE);
			}
			else
			{
				
				 img_online.setVisibility(View.VISIBLE);
			
			}
			if(arr_group.get(position).getIntro()==null)
			{
			txt_detail.setText(arr_group.get(position).getMessage());
				
			}
			else
			{
				txt_detail.setText(arr_group.get(position).getIntro());
				
			}
			btn_share.setTag(position);
			btn_share.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					int pos=(Integer) arg0.getTag();
					Share_GroupId=arr_group.get(pos).getGroupCode();
					share_group_name=arr_group.get(pos).getGroupName();
					share_group_image=arr_group.get(pos).getGroupImage();
				
					if (!drawershere.isOpened())
						drawershere.animateOpen();
				}
			});
		txt_group_name.setText(arr_group.get(position).getGroupName());
		
			txt_date.setText(arr_group.get(position).getCreated());
			System.out.println("URLL"+WellconnectedConstant.IMAGE_URL_4+arr_group.get(position).getGroupImage());
		if(arr_group.get(position).getJoin().equals("0"))
		{
			btn_share.setVisibility(View.VISIBLE);
		}
		else
		{
			btn_share.setVisibility(View.GONE);
		}
		
	
		if(arr_group.get(position).getGroupImage()==null)
		{
			img_group_image.setBackgroundResource(R.drawable.group_pic);
		}
		else
		{
			 imgLoader.DisplayImage(WellconnectedConstant.IMAGE_URL_4+arr_group.get(position).getGroupImage(),  img_group_image);
		}
			return convertView;
		}
	}
	
	class ViewHolder
	{
		ImageView img_group_image,img_online;
		TextView txt_group_name,txt_detail,txt_date;
		LinearLayout linear_images;
		Button btn_share;
	}
}
