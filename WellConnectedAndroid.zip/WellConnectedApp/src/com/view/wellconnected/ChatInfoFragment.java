package com.view.wellconnected;

import java.util.ArrayList;

import org.json.JSONObject;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

import com.wellconnected.bean.ChatDetailBean.ChatDetail;
import com.wellconnected.bean.ChatGroupBase;
import com.wellconnected.lazyload.ImageLoader_rounded;
import com.wellconnected.parse.WellconnectedParse;
import com.wellconnected.utills.MyApplication;
import com.wellconnected.utills.WellconnectedConstant;
import com.wellconnected.utills.WellconnectedUtills;

public class ChatInfoFragment extends Fragment{
	
	private String user_id,search_name,unReadCount;
	private ArrayList<ChatGroupBase>arr;
	private ArrayList<ChatDetail>arrDetail;
	private ListView list_chat;
	private ImageLoader_rounded imgLoader;
	private ImageView img_menu;
	private EditText ed_search;
	private LinearLayout ll_search;
	private MyApplication appDelegate;
	private SharedPreferences pref;

	@Override
	public void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		WellconnectedConstant.ScreenName="";
		
		appDelegate = (MyApplication) getActivity().getApplicationContext();
		pref = getActivity().getSharedPreferences("LoginInfo", getActivity().MODE_WORLD_READABLE);

		if (WellconnectedUtills.isNetworkAvailable(getActivity())) {
			new ChatTask().execute();

		} else {
			WellconnectedUtills.customDialog(getActivity(), "Internet connection is not available");

		}
		
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
	
		View view = inflater.inflate(R.layout.chat, null);
	       
		arr=new ArrayList<ChatGroupBase>();
		
		search_name="";
		
		ed_search=(EditText)view. findViewById(R.id.ed_search);
		list_chat=(ListView) view.findViewById(R.id.list_chat);
				
		list_chat.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				if(arrDetail.get(arg2).getFriend_id()!=null)
				{
					WellconnectedConstant.is_group_chat="0";
					Intent intent=new Intent(getActivity(),GroupChatActivity.class);
					intent.putExtra("friend_id", arrDetail.get(arg2).getFriend_id());
					intent.putExtra("Friend_name", arrDetail.get(arg2).getFriend_name());
					intent.putExtra("Friend_image", arrDetail.get(arg2).getFriend_image());
					intent.putExtra("Group_type", arrDetail.get(arg2).getGroupType());
					intent.putExtra("Group_id", "0");
					startActivity(intent);
			
				}
				else
				{
					WellconnectedConstant.is_group_chat="1";
					
					WellconnectedConstant.Id=arrDetail.get(arg2).getGroupId();
					WellconnectedConstant.user_id=user_id;
					WellconnectedConstant.Group_Type=arrDetail.get(arg2).getGroupType();
					WellconnectedConstant.Join_status="1";
					
					//groupchat
					Intent intent=new Intent(getActivity(),GroupChatActivity.class);
					intent.putExtra("friend_id",/* arrDetail.get(arg2).getGroupId()*/"0");
					intent.putExtra("Friend_name", arrDetail.get(arg2).getFriend_name());
					intent.putExtra("Friend_image", arrDetail.get(arg2).getFriend_image());
					intent.putExtra("Group_id", arrDetail.get(arg2).getGroupId());
					intent.putExtra("Group_type", arrDetail.get(arg2).getGroupType());
					
					
					startActivity(intent);
				}
				}
		});
		SharedPreferences	pref = getActivity().getSharedPreferences("LoginInfo", getActivity().MODE_WORLD_READABLE);
		
		user_id=pref.getString("User_id", "");
		imgLoader=new ImageLoader_rounded(getActivity());
		ll_search=(LinearLayout)view.findViewById(R.id.ll_search);
		img_menu=(ImageView)view. findViewById(R.id.img_menu);
	
		return view;
   
	}
	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
	/*	
		if (WellconnectedUtills.isNetworkAvailable(getActivity())) {
			new ChatTask().execute();

		} else {
			WellconnectedUtills.customDialog(getActivity(), "Internet connection is not available");

		}
		*/
		img_menu.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
/*				// TODO Auto-generated method stub
	int width = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 40, getResources().getDisplayMetrics());
				
				SlideoutActivity.prepare(ChatActivity.this, R.id.rlmain, width);
				startActivity(new Intent(ChatActivity.this,MenuActivity.class));
				overridePendingTransition(0, 0);
	*/		
			}
		});
		
		ll_search.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				search_name=ed_search.getText().toString();
			
				new ChatTask().execute();
			}
		});
ed_search.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub

				if(s.toString().equals(""))
				{
					search_name="";
					
					new ChatTask().execute();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub
				
			}
			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				
			}
		});
	}
	
	public class ChatTask extends AsyncTask<String, Integer, String> {
		ProgressDialog progressDialog;
		JSONObject obj;
		ChatGroupBase chatbase;

		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(getActivity(), "", "Please Wait");

		}

		@Override
		protected String doInBackground(String... params) {

			// TODO Auto-generated method stub

			chatbase = WellconnectedParse.getChat(getActivity(), user_id, search_name);

			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			try {
				progressDialog.dismiss();
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}

			if (chatbase != null) {
				if (chatbase.getResponse()==null) {
					//WellconnectedUtills.customDialog(ChatActivity.this, chatbase.getResponse().getError());

				} else {
					
					unReadCount=chatbase.getResponse().getUnreadCount();
					System.out.println("unReadCount"+unReadCount);
					
					System.out.println("unreadCount" + unReadCount);
					SharedPreferences.Editor editor = pref.edit();
					editor.putString("chatCount", unReadCount);
					editor.commit();
					
					appDelegate.getChangePic().sendEmptyMessage(11);
					
					
					arrDetail=new ArrayList<ChatDetail>();
					
					arrDetail=chatbase.getResponse().getChatDetail();
					
					System.out.println("arrDetail"+arrDetail.size());
					
					list_chat.setAdapter(new ChatAdapter()); 
				}
			}

		}
	}
	class ViewHolder
	{
		ImageView img_chat_image,img_online;
		TextView txt_group_name,txt_date,txt_friend_name,txt_count;
		LinearLayout linear_images;
		ImageButton btn_logo;
	}
	class ChatAdapter extends BaseAdapter
	{

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return arrDetail.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			
			
			LayoutInflater inflater=getActivity().getLayoutInflater();
			convertView=inflater.inflate(R.layout.chat_row, null);

			ImageView  img_chat_image=(ImageView)convertView.findViewById(R.id.img_chat_image);
			TextView txt_friend_name=(TextView) convertView.findViewById(R.id.txt_friend_name);
			TextView txt_date=(TextView) convertView.findViewById(R.id.txt_date);
			  
			ImageView	 img_online=(ImageView) convertView.findViewById(R.id.img_online);
			ImageButton	btn_logo=(ImageButton) convertView.findViewById(R.id.btn_logo);
			TextView	  txt_count=(TextView) convertView.findViewById(R.id.txt_count);
				 
		
			if(arrDetail.get(position).getStatus()!=null)
			{
				if(arrDetail.get(position).getStatus().equals("read")||arrDetail.get(position).getStatus().equals("1"))
				{
							
					img_online.setVisibility(View.INVISIBLE);
				}
				else
				{
					
					 img_online.setVisibility(View.VISIBLE);
				
				}
			}
			else
			{
				
			}
			if(arrDetail.get(position).getIndividualCount().equals("0"))
			{
				txt_count.setText("");
					
			}
			else
			{
			txt_count.setText(arrDetail.get(position).getIndividualCount());
					
			}
			 
			btn_logo.setTag(position);
			btn_logo.setFocusable(false);
			btn_logo.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					int pos=(Integer) v.getTag();
					if(arrDetail.get(pos).getFriend_id()!=null)
					{
						WellconnectedConstant.is_group_chat="0";
						Intent intent=new Intent(getActivity(),GroupChatActivity.class);
						intent.putExtra("friend_id", arrDetail.get(pos).getFriend_id());
						intent.putExtra("Friend_name", arrDetail.get(pos).getFriend_name());
						intent.putExtra("Friend_image", arrDetail.get(pos).getFriend_image());
						intent.putExtra("Group_id","0");
						intent.putExtra("Group_type","0");
						startActivityForResult(intent, 0);
				
					}
					else
					{
						
						WellconnectedConstant.Id=arrDetail.get(pos).getGroupId();
						WellconnectedConstant.user_id=user_id;
						WellconnectedConstant.Group_Type=arrDetail.get(pos).getGroupType();
						WellconnectedConstant.Join_status="1";
						
						WellconnectedConstant.is_group_chat="1";
						//groupchat
						Intent intent=new Intent(getActivity(),GroupChatActivity.class);
						intent.putExtra("friend_id", "0");
						intent.putExtra("Friend_name", arrDetail.get(pos).getGroupName());
						intent.putExtra("Friend_image", arrDetail.get(pos).getGroupImage());
						intent.putExtra("Group_id",arrDetail.get(pos).getGroupId());
						intent.putExtra("Group_type","1");
						startActivityForResult(intent, 0);
							}
				}
			});
			
			if(arrDetail.get(position).getFriend_image()!=null)
			{
				
				System.out.println("URL"+WellconnectedConstant.IMAGE_URL_3+arrDetail.get(position).getFriend_image());
				
				imgLoader.DisplayImage(WellconnectedConstant.IMAGE_URL_3+arrDetail.get(position).getFriend_image(),  img_chat_image);
				
			}
			else
			{
				
				System.out.println("URL"+WellconnectedConstant.IMAGE_URL_3+arrDetail.get(position).getGroupImage());
				
				if(arrDetail.get(position).getGroupImage()==null)
				{
					img_chat_image.setBackgroundResource(R.drawable.user_pic);
				}
				else
				{
					imgLoader.DisplayImage(WellconnectedConstant.IMAGE_URL_3+arrDetail.get(position).getGroupImage(),  img_chat_image);
					
				}             
				
			}
				
		if(arrDetail.get(position).getChattype().equals("1"))
		{
			btn_logo.setBackgroundResource(R.drawable.msg_icon);
			
		}
		else if(arrDetail.get(position).getChattype().equals("2"))
		{
			btn_logo.setBackgroundResource(R.drawable.photo_icon);
			
		}	else if(arrDetail.get(position).getChattype().equals("3"))
		{
			btn_logo.setBackgroundResource(R.drawable.play_btn);
			
		}
		if(arrDetail.get(position).getFriend_name()!=null)
		{
			txt_friend_name.setText(arrDetail.get(position).getFriend_name().trim());

		}
		else
		{
			txt_friend_name.setText(arrDetail.get(position).getGroupName().trim());

		}
		
		txt_date.setText(arrDetail.get(position).getCreated().trim());
			return convertView;
		}
		
		
	}
}
